import GuideStep1Sreen from '@/screens/guide/step1';
import GuideStep2Sreen from '@/screens/guide/step2';
import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';

const HomeStack = createStackNavigator();

function HomeNavigation() {
  return (
    <HomeStack.Navigator
      mode="modal"
      headerMode="none"
      screenOptions={{cardStyle: {backgroundColor: 'transparent'}}}>
      {/* <HomeStack.Screen name="GuideStep1" component={GuideStep1Sreen} />
      <HomeStack.Screen name="GuideStep2" component={GuideStep2Sreen} /> */}
    </HomeStack.Navigator>
  );
}

export default HomeNavigation;
