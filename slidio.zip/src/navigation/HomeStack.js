import CategoriesSreen from '@/domains/caterogies';
import HomeSreen from '@/domains/home';
import {Platform} from 'react-native';
import PresetScreen from '@/domains/preset';
import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';

const HomeStack = createStackNavigator();

const options = {
  cardOverlayEnabled: true,
  gestureEnabled: true,
  gestureResponseDistance: {vertical: Platform.OS == 'ios' ? 160 : 70},
};

function HomeNavigation() {
  return (
    <HomeStack.Navigator
      mode="modal"
      headerMode="none"
      screenOptions={{
        cardStyle: {backgroundColor: 'transparent'},
      }}>
      <HomeStack.Screen name="Folders" component={HomeSreen} />
      <HomeStack.Screen
        name="Categories"
        options={options}
        component={CategoriesSreen}
      />
      <HomeStack.Screen name="Preset" component={PresetScreen} />
    </HomeStack.Navigator>
  );
}

export default HomeNavigation;
