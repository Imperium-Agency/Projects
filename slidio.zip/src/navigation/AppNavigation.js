import * as React from 'react';

import GuideStack from './GuideStack';
import GuideStep1Sreen from '@/screens/guide/step1';
import GuideStep2Sreen from '@/screens/guide/step2';
import MainStackScreen from './MainStack';
import {NavigationContainer} from '@react-navigation/native';
// import GuideScreen from '@/domains/guide';
import PrivacyPolicyScreen from '@/domains/privacy-policy';
import SubscriptionScreen from '@/domains/subscription';
import TermOfUseScreen from '@/domains/term-of-use';
import {createStackNavigator} from '@react-navigation/stack';

const RootStack = createStackNavigator();

const Modalstack = createStackNavigator();

const options = {
  cardOverlayEnabled: true,
  gestureEnabled: true,
  gestureResponseDistance: {vertical: 200},
};

function App() {
  return (
    <NavigationContainer>
      <RootStack.Navigator
        mode="modal"
        headerMode="none"
        screenOptions={{
          cardStyle: {backgroundColor: 'transparent'},
        }}>
        {/* <RootStack.Screen name="Subscription" component={SubscriptionScreen} /> */}
        <RootStack.Screen name="Main" component={MainStackScreen} />
        {/* <RootStack.Screen name="Guide" component={GuideStack} /> */}
        <RootStack.Screen
          name="Subscription"
          component={SubscriptionScreen}
          options={options}
        />
        <RootStack.Screen
          name="GuideStep1"
          component={GuideStep1Sreen}
          options={options}
        />
        <RootStack.Screen
          name="GuideStep2"
          component={GuideStep2Sreen}
          options={options}
        />

        <RootStack.Screen
          name="PrivacyPolicy"
          component={PrivacyPolicyScreen}
        />
        <RootStack.Screen name="TermOfUse" component={TermOfUseScreen} />
      </RootStack.Navigator>
    </NavigationContainer>
  );
}

export default App;
