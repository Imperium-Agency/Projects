import * as React from 'react';

import HomeScreen from '@/screens/home';

import {createStackNavigator} from '@react-navigation/stack';

const MainStack = createStackNavigator();

function MainStackScreen() {
  return (
    <MainStack.Navigator screenOptions={{headerShown: false}}>
      <MainStack.Screen name="Home" component={HomeScreen} />
    </MainStack.Navigator>
  );
}

export default MainStackScreen;
