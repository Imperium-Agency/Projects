import AsyncStorage from '@react-native-community/async-storage';
import {combineReducers} from 'redux';
import commonReducer from './modules/common/reducer';
import homeReducer from './modules/home/reducer';
import iapReducer from './modules/iap/reducer';
import {persistReducer} from 'redux-persist';
import presetReducer from './modules/preset/reducer';

const iapPersistConfig = {
  key: 'iap',
  storage: AsyncStorage,
  // whitelist: [],
  blacklist: ['processing', 'susses', 'availablePurchases'],
};

/**
 * Root reducer
 * @type {Reducer<any> | Reducer<any, AnyAction>}
 */
const rootReducers = combineReducers({
  common: commonReducer,
  preset: presetReducer,
  home: homeReducer,
  iap: persistReducer(iapPersistConfig, iapReducer),
});

export default rootReducers;
