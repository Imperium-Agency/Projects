// import {I18nextProvider, useTranslation} from 'react-i18next';
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import 'react-native-gesture-handler';
import './config-i18n';
import './config-i18n';

import React, {useEffect} from 'react';
import {StatusBar, Text} from 'react-native';

import SubscriptionContainer from './containers/Subscription';

import RootContainer from './containers/root';
import OrientationContainer from './containers/orientation';

import AppNavigation from './navigation/AppNavigation';

import Orientation from 'react-native-orientation';
import {PersistGate} from 'redux-persist/integration/react';
import {Provider} from 'react-redux';
import SplashScreen from 'react-native-splash-screen';

import configureStore from './config-store';

console.disableYellowBox = true;

const {store, persistor} = configureStore();

const App = () => {
  useEffect(() => {
    Orientation.lockToPortrait();

    SplashScreen.hide();
  }, []);

  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />

      <PersistGate loading={null} persistor={persistor}>
        <Provider store={store}>
          <RootContainer>
            <OrientationContainer>
              <SubscriptionContainer>
                <AppNavigation />
              </SubscriptionContainer>
            </OrientationContainer>
          </RootContainer>
        </Provider>
      </PersistGate>
    </>
  );
};

export default App;
