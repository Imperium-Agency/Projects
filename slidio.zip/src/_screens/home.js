import React from 'react';
import {View, Text} from 'react-native';

import Home from 'src/domains/home';

const home = () => {
  return <Home />;
};

export default home;
