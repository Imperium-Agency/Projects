import React from 'react';
import {View, Text} from 'react-native';

import PrivacyPolicy from '@/domains/privacy-policy';

const home = () => {
  return <PrivacyPolicy />;
};

export default home;
