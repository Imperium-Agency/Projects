import React from 'react';
import {View, Text} from 'react-native';

import Preset from '@/domains/preset';

const home = () => {
  return <Preset />;
};

export default home;
