import React from 'react';
import {View, Text} from 'react-native';

import TermOfUSe from '@/domains/term-of-use';

const home = () => {
  return <TermOfUSe />;
};

export default home;
