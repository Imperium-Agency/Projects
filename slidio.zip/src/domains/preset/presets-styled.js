import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

export const StyledContainer = styled.View`
  flex: 1;

  background-color: #f5f2f1;
`;

export const StyledBody = styled.View`
  flex: 1;
`;
