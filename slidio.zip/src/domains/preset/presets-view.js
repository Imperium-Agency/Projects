import {Platform, StatusBar, Text, View} from 'react-native';
import {StyledBody, StyledContainer} from './presets-styled';

import PresetsContent from './components/content';
import PresetsHeader from './components/header';
import React from 'react';

const PresetsView = ({data, priceProduct, isAccess}) => {
  return (
    <StyledContainer>
      {Platform.OS == 'ios' && <StatusBar barStyle="light-content" />}

      <StyledBody>
        <PresetsContent
          data={data.presets}
          HeaderComponent={
            <PresetsHeader
              data={data}
              priceProduct={priceProduct}
              isAccess={isAccess}
              paddingBottom={0}
            />
          }
        />
      </StyledBody>
    </StyledContainer>
  );
};

export default PresetsView;
