export {default} from './preset-slider-view';
