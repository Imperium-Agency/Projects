import PropTypes from 'prop-types';
import Carousel from 'react-native-snap-carousel';

import React, {useMemo, useState} from 'react';
import {View, Text, Image} from 'react-native';

import {StyledContainer, StyledItem, StyledImage} from './preset-slider-styled';

import {
  CONTAINER_PADDING_HORIZONTAL,
  CARD_BASE_SIZE,
} from './preset-slider-constant';

const PresetSliderView = ({data, onChangeContainerSize}) => {
  const [containerSize, setContainerSize] = useState({
    width: 0,
    height: 0,
  });

  const cardSize = useMemo(() => {
    const proportion = containerSize.height / CARD_BASE_SIZE.height;

    return {
      width: Math.floor(CARD_BASE_SIZE.width * proportion * 0.76),
      height: Math.floor(CARD_BASE_SIZE.height * proportion),
    };
  }, [containerSize.height]);

  const _renderItem = ({item}) => (
    <StyledItem>
      <StyledImage source={{uri: item.image}} resizeMode="cover" />
    </StyledItem>
  );

  return (
    <StyledContainer
      onLayout={event => setContainerSize(event.nativeEvent.layout)}>
      {!!containerSize.height && (
        <Carousel
          data={data}
          renderItem={_renderItem}
          sliderWidth={containerSize.width}
          itemWidth={cardSize.width}
          useScrollView={true}
          // firstItem={1}
          activeSlideAlignment="start"
          inactiveSlideOpacity={1}
          inactiveSlideScale={1}
          slideStyle={{paddingHorizontal: 8}}
          containerCustomStyle={{
            paddingLeft: 44,
            paddingBottom: 32,
            paddingTop: 24,
          }}
        />
      )}
    </StyledContainer>
  );
};

PresetSliderView.propTypes = {
  data: PropTypes.array,
  cardSize: PropTypes.object,
  onChangeSizeContainer: PropTypes.func,
};

PresetSliderView.defaultProps = {
  data: [],
  cardSize: {width: '100%', height: '100%'},
  onChangeSizeContainer: () => {},
};

export default PresetSliderView;
