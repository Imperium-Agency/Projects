import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';

export const CONTAINER_PADDING_HORIZONTAL = isTablet
  ? margin.big
  : margin.large;

export const CARD_BASE_SIZE = {
  width: 795,
  height: 598,
};
