import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

export const StyledContainer = styled.View`
  flex: 1;
`;

export const StyledItem = styled.View`
  width: 100%;
  height: 100%;
  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.12);
  border-radius: 8px;
`;

export const StyledImage = styled.Image`
  width: 100%;
  height: 100%;
  border-radius: 8px;
`;
