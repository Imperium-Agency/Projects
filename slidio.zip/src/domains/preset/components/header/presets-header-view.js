import {Animated, ImageBackground, View} from 'react-native';
import {Button, Icon} from '@/components';
import {Header, Search} from '@/components';
import React, {useMemo} from 'react';
import {
  StyleButton,
  StyleButtonFont,
  StyleButtonContainer,
  StyleFooter,
  StyledContainer,
  StyledContent,
  StyledDescription,
  StyledGradient,
  StyledTitle,
  StyledTopLine,
  StyledTopLineleft,
} from './presets-header-styled';

import LinearGradient from 'react-native-linear-gradient';
import {isTablet} from '@/helpers';
import {useNavigation} from '@react-navigation/native';
import {useSafeArea} from 'react-native-safe-area-context';
import {useTranslation} from 'react-i18next';

const PresetsHeaderView = ({
  data,
  priceProduct,
  isAccess,
  loading,
  active,
  progressDownload,
  isVerticalOrientation,
  onBack,
  onShare,
}) => {
  const navigation = useNavigation();

  const insets = useSafeArea();

  const {i18n, t} = useTranslation('preset');

  const handleBack = () => {
    navigation.goBack();
  };

  const buttonText = useMemo(() => {
    if (priceProduct) return `${priceProduct.price} ${priceProduct.currency}`;
    else return isAccess ? t('text_download') : t('text_receive');
  }, [priceProduct, isAccess]);

  const buttonsComponent =
    (priceProduct && !isAccess) || !isAccess ? (
      <Button
        title={buttonText}
        size="small"
        loading={loading}
        onPress={onShare}
      />
    ) : data.other ? (
      <StyleButtonContainer>
        <Button
          title={t('text_download')}
          size="small"
          loading={loading && active == 'other'}
          disabled={loading}
          progress={progressDownload}
          onPress={() => onShare('other')}
        />

        {data.font && (
          <StyleButtonFont>
            <Button
              title={t('text_font')}
              size="small"
              loading={loading && active == 'font'}
              disabled={loading}
              progress={progressDownload}
              onPress={() => onShare('font')}
            />
          </StyleButtonFont>
        )}
      </StyleButtonContainer>
    ) : (
      <StyleButtonContainer>
        {data.keynote && (
          <StyleButton>
            <Button
              title="Keynote"
              size="small"
              loading={loading && active == 'keynote'}
              disabled={loading}
              progress={progressDownload}
              onPress={() => onShare('keynote')}
            />
          </StyleButton>
        )}

        {data.powerpoint && (
          <Button
            title="PowerPoins"
            size="small"
            loading={loading && active == 'powerpoint'}
            disabled={loading}
            progress={progressDownload}
            onPress={() => onShare('powerpoint')}
          />
        )}

        {data.font && (
          <StyleButtonFont>
            <Button
              title="Font"
              size="small"
              loading={loading && active == 'font'}
              disabled={loading}
              progress={progressDownload}
              onPress={() => onShare('font')}
            />
          </StyleButtonFont>
        )}
      </StyleButtonContainer>
    );

  return (
    <StyledContainer
      as={ImageBackground}
      source={!isTablet && {uri: data.image}}>
      {isTablet ? (
        <Header
          withBack
          title={data.title}
          paddingBottom={!isVerticalOrientation ? 0 : undefined}
          paddingHorizontal={isVerticalOrientation ? 0 : undefined}
          footerComponent={
            <StyleFooter>
              <StyledDescription numberOfLines={3}>
                {data.description[i18n.language]}
              </StyledDescription>

              {/* {priceProduct.currency && (
                <StyledCurrency>{priceProduct.currency}</StyledCurrency>
              )} */}

              {buttonsComponent}
            </StyleFooter>
          }
        />
      ) : (
        <StyledGradient
          as={LinearGradient}
          locations={[0.5, 1]}
          colors={['rgba(0, 0, 0, 0.35)', 'rgba(0, 0, 0, 0.35)']}>
          <StyledGradient
            as={LinearGradient}
            locations={[0.5, 1]}
            colors={['rgba(242, 239, 237, 0)', '#EEEBE9']}>
            <StyledContent insets={insets}>
              <StyledTopLine>
                <StyledTopLineleft>
                  <Icon name="back" color="#fff" onPress={onBack} />

                  <StyledTitle numberOfLines={1}>{data.title}</StyledTitle>
                </StyledTopLineleft>
              </StyledTopLine>

              <StyledDescription numberOfLines={4}>
                {data.description[i18n.language]}
              </StyledDescription>

              <StyleFooter>{buttonsComponent}</StyleFooter>
            </StyledContent>
          </StyledGradient>
        </StyledGradient>
      )}
    </StyledContainer>
  );
};

export default PresetsHeaderView;
