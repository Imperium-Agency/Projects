import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';
import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  position: relative;
  max-height: 258px;

  box-shadow: 0px -10px 15px rgba(0, 0, 0, 0.1);
`;

export const StyledContent = styled.View`
  justify-content: space-between;
  align-items: flex-end;

  padding: 0px ${padding.large}px ${padding.small}px;
  padding-top: ${(props) => props.insets.top + padding.base}px;

  width: 100%;
  height: 100%;
`;

export const StyledTopLine = styled.View`
  width: 100%;
  flex-direction: row;
  justify-content: space-between;
`;

export const StyleFooter = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`;

export const StyleButtonContainer = styled.View`
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
`;

export const StyleButton = styled.View`
  margin-right: ${padding.small}px;
`;

export const StyleButtonFont = styled.View`
  margin-left: ${padding.small}px;
`;

export const StyledTopLineleft = styled.View`
  flex-direction: row;
`;

export const StyledTitle = styled.Text`
  margin-left: ${padding.small}px;
  width: 85%;
  max-width: 100%;

  font-size: ${(props) => (props.big ? 24 : 16)}px;
  line-height: ${padding.large}px;
  color: #ffffff;
`;

export const StyledDescription = styled.Text`
  width: ${isTablet ? '55%' : '100%'};
  margin-top: ${padding.small}px;

  font-size: ${(props) => (props.big ? 24 : 14)}px;
  color: ${isTablet ? '#313131' : '#ffffff'};
`;

export const StyledGradient = styled.Text`
  height: 100%;
  width: 100%;
  position: relative;
  align-items: center;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1;
`;
