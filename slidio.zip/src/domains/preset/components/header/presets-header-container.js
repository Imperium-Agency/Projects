import React, {useContext, useState} from 'react';
import {downloadPresetImage, sharePreset} from 'src/utils/preset';
import {useNavigation, useRoute} from '@react-navigation/native';

import {OrientationContext} from '@/context';
import PresetsHeaderView from './presets-header-view';
import RNFS from 'react-native-fs';

const PresetsHeaderContainer = (props) => {
  const {isVerticalOrientation} = useContext(OrientationContext);

  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(null);
  const [progressDownload, setProgressDownload] = useState(0);
  const navigation = useNavigation();

  const handleBack = () => {
    navigation.goBack();
  };

  const handlerSelect = (key) => {
    console.log('props.isAccess', props.isAccess);

    if (props.isAccess) handlerShare(key);
    else if (props.priceProduct)
      navigation.navigate('Subscription', {
        firstStart: false,
        buyProductData: props.priceProduct,
      });
    else navigation.navigate('Subscription', {firstStart: false});
  };

  const handlerShare = async (key) => {
    console.log('key', key);

    setLoading(true);
    setActive(key);

    downloadPresetImage({
      url: props.data[key],
      onChangeProgress: setProgressDownload,
      cb: (base64image) => {
        let urls = props.data[key].split('/');

        const imagePath = `${RNFS.CachesDirectoryPath}/${
          urls[urls.length - 1]
        }`;
        if (Platform.OS == 'ios')
          RNFS.writeFile(imagePath, base64image, 'base64').then(() => {
            console.log('Image converted to jpg and saved at ' + imagePath);
            sharePreset({
              base64image: imagePath,
              id: props.data.id,
            });
          });
        else
          sharePreset({
            base64image: 'data:image/png;base64,' + base64image,
            id: props.data.id,
            cb: () => {
              setLoading(false);
              setActive(null);
            },
          });

        setLoading(false);
        setActive(null);
      },
    });
  };
  return (
    <PresetsHeaderView
      {...props}
      loading={loading}
      active={active}
      progressDownload={progressDownload}
      isVerticalOrientation={isVerticalOrientation}
      onBack={handleBack}
      onShare={handlerSelect}
    />
  );
};

export default PresetsHeaderContainer;
