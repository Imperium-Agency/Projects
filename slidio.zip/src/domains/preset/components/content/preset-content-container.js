import React, {useContext} from 'react';
import {View, Text} from 'react-native';

import PresetContentView from './preset-content-view';

import {OrientationContext} from '@/context';

const PresetContentContainer = props => {
  const {isVerticalOrientation} = useContext(OrientationContext);

  return (
    <PresetContentView
      {...props}
      isVerticalOrientation={isVerticalOrientation}
    />
  );
};

export default PresetContentContainer;
