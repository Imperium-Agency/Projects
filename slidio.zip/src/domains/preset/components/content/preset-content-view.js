import React from 'react';
import {View, Text} from 'react-native';

import PresetSlider from '../slider';
import PresetGrid from '../grid';

import {isTablet} from '@/helpers';

const PresetContentView = props => {
  if (isTablet && !props.isVerticalOrientation) {
    return (
      <View style={{flex: 1}}>
        {props.HeaderComponent}

        <PresetSlider data={props.data} />
      </View>
    );
  }

  return <PresetGrid {...props} />;
};

export default PresetContentView;
