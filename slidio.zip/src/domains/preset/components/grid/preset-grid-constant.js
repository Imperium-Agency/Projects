import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';

export const CARD_BASE_SIZE = {
  width: 343,
  height: 195,
};

export const CARD_OFFSET = isTablet ? margin.large / 2 : margin.large;

export const CONTAINER_OFFSET = isTablet ? margin.big : 0;
