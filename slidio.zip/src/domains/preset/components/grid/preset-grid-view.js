import {
  CARD_BASE_SIZE,
  CARD_OFFSET,
  CONTAINER_OFFSET,
} from './preset-grid-constant';
import {Dimensions, FlatList, Text, View} from 'react-native';
import React, {useMemo} from 'react';
import {StyledFlatList, StyledItem} from './preset-grid-styled';
import {margin, padding} from '@theme/spacing';

import Empty from '@/containers/empty';
import PresetsGridCard from './components/card';
import {isTablet} from '@/helpers';

const PresetsGridView = ({
  data,
  isVerticalOrientation = false,
  HeaderComponent,
  onSelect,
}) => {
  // CARD_OFFSET
  // const cardSize = useMemo(() => {
  //   return {
  //     width: Math.floor(CARD_BASE_SIZE.width * proportion),
  //     height: Math.floor(CARD_BASE_SIZE.height * proportion),
  //   };
  // }, []);

  const countColumn = useMemo(() => {
    return isTablet ? 2 : 1;
  }, []);

  const cardSize = useMemo(() => {
    const proportion =
      (Dimensions.get('window').width -
        CARD_OFFSET * (countColumn * 2) -
        CONTAINER_OFFSET * countColumn) /
      CARD_BASE_SIZE.width /
      countColumn;

    return {
      width: Math.floor(CARD_BASE_SIZE.width * proportion),
      height: Math.floor(CARD_BASE_SIZE.height * proportion),
    };
  }, []);

  const _renderItem = ({item}) => (
    <StyledItem offset={CARD_OFFSET}>
      <PresetsGridCard
        data={item}
        containerStyle={cardSize}
        onSelect={() => onSelect(item)}
      />
    </StyledItem>
  );

  return (
    <StyledFlatList
      paddingHorizontal={isTablet ? CONTAINER_OFFSET : undefined}
      data={data}
      renderItem={_renderItem}
      keyExtractor={(item, index) => `${item.id}`}
      horizontal={false}
      numColumns={countColumn}
      // numColumns={2}
      key={isTablet && !isVerticalOrientation ? 'h' : 'v'}
      ListHeaderComponent={HeaderComponent}
      ListEmptyComponent={<Empty data={data} />}
    />
  );
};

export default PresetsGridView;
