import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

import {isTablet} from '@/helpers';

export const StyledFlatList = styled.FlatList.attrs({
  contentContainerStyle: {
    minHeight: '100%',
    paddingBottom: padding.large * 2,
    // justifyContent: 'space-between',

    // paddingHorizontal: padding.big,
  },
  ListHeaderComponentStyle: {
    marginBottom: margin.small,
    width: '100%',
    paddingHorizontal: isTablet ? 12 : undefined,
  },
})``;

export const StyledItem = styled.View`
  padding: 0px ${props => props.offset || 0}px;
  margin-bottom: ${margin.extraSmall}px;
`;
