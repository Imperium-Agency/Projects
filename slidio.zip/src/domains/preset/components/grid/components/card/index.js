export {default} from './categories-grid-card-view';
