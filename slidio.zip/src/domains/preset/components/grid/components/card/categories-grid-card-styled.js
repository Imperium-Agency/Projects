import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  flex: 1;

  background-color: #e0e0e0;
`;

export const StyledImageContainer = styled.ImageBackground`
  margin-bottom: ${margin.small}px;

  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.12);
  elevation: 3;
  border-radius: 8px;
`;

export const StyledImage = styled.Image.attrs({
  containerStyle: {
    borderRadius: 8,
  },
})`
  width: 343px;
  height: 258px;

  background: rgba(224, 224, 224, 0.8);
`;
