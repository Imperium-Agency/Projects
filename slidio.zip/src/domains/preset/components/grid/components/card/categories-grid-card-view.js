import React from 'react';
import {StyledImage} from './categories-grid-card-styled';

import {FastImage} from '@/components';

const CategoriesGridCardView = ({data, containerStyle}) => {
  return (
    <StyledImage
      as={FastImage}
      source={{uri: data.image}}
      style={containerStyle}
      resizeMode="cover"
    />
  );
};

export default CategoriesGridCardView;
