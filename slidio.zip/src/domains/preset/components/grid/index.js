export {default} from './preset-grid-view';
