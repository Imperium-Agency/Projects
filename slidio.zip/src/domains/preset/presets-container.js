import React, {useEffect, useMemo, useState} from 'react';
import {useNavigation, useRoute} from '@react-navigation/native';

import PresetsView from './presets-view';
import moment from 'moment';

const PresetsContainer = (props) => {
  const navigation = useNavigation();

  const route = useRoute();

  const {data} = route.params;

  const isAccess = useMemo(() => {
    return (
      data.free || props.isSubscribe || props.purchases.products[data.productId]
    );
  }, [data.free, props.isSubscribe, props.purchases.products, props.data]);

  const priceProduct = useMemo(() => {
    if (!props.productsToBuy.data) return false;

    let res = props.productsToBuy.data.filter((item) => {
      return item.productId == data.productId;
    });

    if (res.length == 0) return false;

    return {
      price: res[0].price,
      currency: res[0].currency,
      name: data.title,
      productId: data.productId,
    };
  }, [props.productsToBuy]);

  return (
    <PresetsView
      {...props}
      data={data}
      priceProduct={priceProduct}
      isAccess={isAccess}
    />
  );
};

export default PresetsContainer;
