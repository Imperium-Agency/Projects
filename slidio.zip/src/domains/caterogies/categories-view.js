import {Header, Search} from '@/components';
import {
  StyledBody,
  StyledContainer,
  StyledHeader,
  StyledSort,
} from './categories-styled';
import {Text, View} from 'react-native';

import CategoriesGrid from './components/grid';
import CategoriesHeader from './components/header';
import CategoriesSort from './components/sort';
import React from 'react';
import {isTablet} from '@/helpers';
import {useRoute} from '@react-navigation/native';
import {useTranslation} from 'react-i18next';

const CategoriesView = ({
  data,
  isSubscribe,
  purchases,
  productsToBuy,
  search,
  showSearch,
  inputRef,
  activeSort,
  setInputRef,
  isVerticalOrientation,
  onChangeShowSearch,
  onChangeSearch,
  onChangeActiveSort,
  onClearFilter,
}) => {
  const {i18n} = useTranslation();

  return (
    <StyledContainer>
      {isTablet && (
        <Header
          withBack
          title={data.name[i18n.language]}
          searchComponent={
            <Search
              data={search}
              setInputRef={setInputRef}
              onChange={onChangeSearch}
            />
          }
        />
      )}

      {!isTablet && (
        <CategoriesHeader
          data={data}
          search={search}
          inputRef={inputRef}
          setInputRef={setInputRef}
          showSearch={showSearch}
          onChangeSearch={onChangeSearch}
          onChangeShowSearch={onChangeShowSearch}
        />
      )}

      <CategoriesGrid
        data={data.categories}
        search={search}
        activeSort={activeSort}
        isSubscribe={isSubscribe}
        products={purchases.products}
        productsToBuy={productsToBuy}
        isVerticalOrientation={isVerticalOrientation}
        header={
          <StyledHeader>
            {/* {!isTablet && (
              <CategoriesHeader
                data={data}
                search={search}
                inputRef={inputRef}
                setInputRef={setInputRef}
                showSearch={showSearch}
                onChangeSearch={onChangeSearch}
                onChangeShowSearch={onChangeShowSearch}
              />
            )} */}

            <StyledSort
              as={CategoriesSort}
              activeSort={activeSort}
              onChangeActiveSort={onChangeActiveSort}
            />
          </StyledHeader>
        }
        onClearFilter={onClearFilter}
      />
    </StyledContainer>
  );
};

export default CategoriesView;
