import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';
import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  flex: 1;

  background-color: #f6f3f1;
`;

export const StyledHeader = styled.View`
  width: 100%;
`;

export const StyledSort = styled.View.attrs({
  contentContainerStyle: {
    paddingHorizontal: isTablet ? padding.base : padding.large,
    paddingTop: isTablet ? padding.small : padding.extraSmall,
    paddingBottom: isTablet ? padding.big : padding.big - padding.small,
  },

  ListHeaderComponentStyle: {
    // width: '100%',
  },
})``;

// margin: 0px ${ isTablet ? margin.base : 0 } px;z
// padding: 0px ${ isTablet ? margin.big : margin.large } px;

// margin - top: ${ isTablet ? 0 : margin.extraSmall } px;
// margin - bottom: ${ isTablet ? margin.big : margin.big - margin.small } px;
