import {
  isSubscribeSelector,
  prodsSelector,
  purchasesSelector,
} from 'src//modules/iap/selectors';

import CategoriesContainer from './categories-container';
import {connect} from 'react-redux';

const mapStateToProps = (state) => ({
  isSubscribe: isSubscribeSelector(state),
  purchases: purchasesSelector(state),
  productsToBuy: prodsSelector(state),
});

const mapDispatchToProps = {};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CategoriesContainer);
