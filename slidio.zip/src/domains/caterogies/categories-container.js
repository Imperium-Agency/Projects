import React, {useContext, useEffect, useMemo, useState} from 'react';
import {useNavigation, useRoute} from '@react-navigation/native';

import CategoriesView from './categories-view';
import {OrientationContext} from '@/context';
import moment from 'moment';

const CategoriesContainer = (props) => {
  const {isVerticalOrientation} = useContext(OrientationContext);

  const navigation = useNavigation();

  const route = useRoute();

  const {data} = route.params;

  const [showSearch, setShowSearch] = useState(false);
  const [search, setSearch] = useState(null);
  const [activeSort, setActiveSort] = useState('popular');

  useEffect(() => {
    if (data.search) setSearch(data.search);
  }, []);

  const renderData = useMemo(() => {
    let res = {...data};

    if (!res.categories.length) {
      return res;
    }

    if (activeSort === 'new') {
      res.categories = res.categories.sort((a, b) => {
        const aDate = moment(a.createdAt);
        const bDate = moment(b.createdAt);

        if (aDate < bDate) {
          return 1;
        } else if (aDate === bDate) {
          return 0;
        } else {
          return -1;
        }
      });
    } else if (activeSort === 'popular') {
      res.categories = res.categories.sort((a, b) => {
        if (a.countDownload < b.countDownload) {
          return 1;
        } else if (a.countDownload === b.countDownload) {
          return 0;
        } else {
          return -1;
        }
      });
    } else if (activeSort === 'recent') {
      res.categories = res.categories.filter((item) => {
        return item.recent;
      });
    } else if (activeSort === 'recommended') {
      res.categories = res.categories.filter((item) => {
        return item.recommended;
      });
    }

    if (!search) {
      return res;
    } else {
      res.categories = res.categories.filter((item) => {
        return (
          item.title.toLowerCase().indexOf(search.trim().toLowerCase()) !== -1
        );
      });

      return res;
    }
  }, [search, activeSort, data]);

  const handleClear = () => {
    setSearch(null);
    setShowSearch(false);
    setActiveSort('popular');
  };

  return (
    <CategoriesView
      {...props}
      data={renderData}
      search={search}
      showSearch={showSearch}
      activeSort={activeSort}
      isVerticalOrientation={isVerticalOrientation}
      onChangeSearch={setSearch}
      onClearFilter={handleClear}
      onChangeShowSearch={setShowSearch}
      onChangeActiveSort={setActiveSort}
    />
  );
};

export default CategoriesContainer;
