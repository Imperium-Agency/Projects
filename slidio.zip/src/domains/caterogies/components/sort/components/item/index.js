export {default} from './categories-sort-item-view';
