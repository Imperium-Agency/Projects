import {Animated, Text, TouchableWithoutFeedback, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import {StyledContainer, StyledName} from './categories-sort-item-styled';

const CategoriesSortView = ({name, index, active, onChangeActiveSort}) => {
  const [activeValue] = useState(new Animated.Value(active ? 1 : 0));

  useEffect(() => {
    Animated.timing(activeValue, {
      toValue: active ? 1 : 0,
      useNativeDriver: false,
    }).start();
  }, [active]);

  const backgroundColor = activeValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['#F5F2F1', '#ffffff'],
  });

  const color = activeValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['#909396', '#EF550A'],
  });

  const shadowOpacity = activeValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
  });

  return (
    <TouchableWithoutFeedback onPress={onChangeActiveSort}>
      <StyledContainer
        as={Animated.View}
        index={index}
        style={{
          backgroundColor,
          shadowOpacity,
        }}>
        <StyledName
          as={Animated.Text}
          style={{
            color,
          }}>
          {name}
        </StyledName>
      </StyledContainer>
    </TouchableWithoutFeedback>
  );
};

export default CategoriesSortView;
