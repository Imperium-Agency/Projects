import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  padding: 8px 12px;
  height: 32px;
  margin-right: ${props => (props.index != 3 ? 10 : 0)}px;

  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.05);
  border-radius: 8px;
`;

export const StyledName = styled.Text`
  font-size: 14px;
  line-height: 16px;
  font-weight: 500;

  color: #909396;
`;
