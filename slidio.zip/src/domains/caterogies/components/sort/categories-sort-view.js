import {ScrollView, Text, View} from 'react-native';

import CategoriesSortItem from './components/item';
import React from 'react';
import {StyledContainer} from './categories-sort-styled';
import {useTranslation} from 'react-i18next';

const CategoriesSortView = ({
  activeSort,
  onChangeActiveSort,
  contentContainerStyle,
}) => {
  const {t} = useTranslation('category');

  return (
    <ScrollView
      contentContainerStyle={contentContainerStyle}
      horizontal={true}
      showsHorizontalScrollIndicator={false}>
      <StyledContainer>
        <CategoriesSortItem
          name={t('text_sort_new')}
          active={activeSort === 'new'}
          index="0"
          onChangeActiveSort={() => onChangeActiveSort('new')}
        />

        <CategoriesSortItem
          name={t('text_sort_popular')}
          active={activeSort === 'popular'}
          index="1"
          onChangeActiveSort={() => onChangeActiveSort('popular')}
        />

        <CategoriesSortItem
          name={t('text_sort_recent')}
          active={activeSort === 'recent'}
          index="2"
          onChangeActiveSort={() => onChangeActiveSort('recent')}
        />

        <CategoriesSortItem
          name={t('text_sort_recommended')}
          active={activeSort === 'recommended'}
          index="3"
          onChangeActiveSort={() => onChangeActiveSort('recommended')}
        />
      </StyledContainer>
    </ScrollView>
  );
};

export default CategoriesSortView;
