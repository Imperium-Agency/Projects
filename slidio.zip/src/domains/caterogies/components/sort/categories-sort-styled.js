import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';
import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  display: flex;
  flex-direction: row;
  justify-content: ${isTablet ? 'flex-start' : 'space-between'};
`;
