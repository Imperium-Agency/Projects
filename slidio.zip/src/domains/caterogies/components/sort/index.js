export {default} from './categories-sort-view';
