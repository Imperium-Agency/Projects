import React, {useEffect, useMemo, useState} from 'react';
import {
  StyleIndicator,
  StyledContainer,
  StyledContent,
  StyledImage,
  StyledImageContainer,
  StyledLinearGradient,
  StyledName,
  StyledTitle,
  StyledTitleContainer,
} from './categories-header-styled';
import {margin, padding} from '@theme/spacing';

import {Animated} from 'react-native';
import FastImage from 'react-native-fast-image';
import HomeHeaderLeft from './components/left';
import HomeHeaderRigth from './components/right';
import {Icon} from '@/components';
import LinearGradient from 'react-native-linear-gradient';
import {ScreenWidth} from '@/helpers';
import {isTablet} from '@/helpers';
import {useSafeArea} from 'react-native-safe-area-context';
import {useTranslation} from 'react-i18next';

const CategoriesHeaderView = ({
  data,
  search,
  showSearch,
  onChangeShowSearch,
  onChangeSearch,
  onBack,
}) => {
  const insets = useSafeArea();

  const {i18n} = useTranslation();

  const [animatedValue] = useState(new Animated.Value(showSearch ? 1 : 0));

  const [inputRef, setInputRef] = useState(null);

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: showSearch ? 1 : 0,
      useNativeDriver: false,
    }).start();

    if (inputRef) {
      if (showSearch) inputRef.focus();
      else {
        inputRef.blur();
      }
    }

    if (!showSearch) onChangeSearch(null);
  }, [showSearch]);

  const name = useMemo(() => {
    let name = data.name[i18n.language];
    let names = name.split(' ');
    let description = name.slice(names[0].length + 1, name.length);

    return {
      title: names[0],
      description: description.slice(0, 1).toUpperCase() + description.slice(1),
    };
  }, [data.name, i18n.language]);

  const rotate = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '180deg'],
  });

  const translateWidth = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, ScreenWidth - padding.large * 3 - padding.small],
  });

  const translateX = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -ScreenWidth - padding.large * 3 - padding.small],
  });

  return (
    <StyledContainer insets={insets}>
      <StyledContent>
        <HomeHeaderLeft
          name={data.name[i18n.language]}
          translateX={translateX}
          onBack={onBack}
        />

        {/* <StyledName>{data.name[i18n.language]} for PowerPoint</StyledName> */}

        <HomeHeaderRigth
          search={search}
          active={showSearch}
          rotate={rotate}
          translateWidth={translateWidth}
          inputRef={inputRef}
          setInputRef={setInputRef}
          // onLayout={(event) => setWidthRigth(event.nativeEvent.layout.width)}
          onTrigger={() => onChangeShowSearch(!showSearch)}
          onChangeSearch={onChangeSearch}
        />
      </StyledContent>

      {!isTablet && (
        <StyledImageContainer>
          <StyledLinearGradient
            as={LinearGradient}
            // start={{x: 0.0, y: 0.25}}
            // end={{x: 0.5, y: 1.0}}
            locations={[0.5, 1]}
            colors={['rgba(239, 241, 243, 0)', '#F0F2F5']}>
            <StyleIndicator />

            <StyledTitleContainer>
              <StyledTitle big>{name.title}</StyledTitle>
              <StyledTitle>{name.description}</StyledTitle>
            </StyledTitleContainer>
          </StyledLinearGradient>

          <StyledImage
            as={FastImage}
            source={{uri: data.preview}}
            resizeMode={FastImage.resizeMode.cover}
          />
        </StyledImageContainer>
      )}
    </StyledContainer>
  );
};

export default CategoriesHeaderView;
