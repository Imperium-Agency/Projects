import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  flex-direction: row;
`;

export const StyledIconContainer = styled.View`
  margin-right: 12px;
`;

export const StyledName = styled.Text`
  font-size: 16px;
  line-height: 24px;

  color: #909396;
`;

export const StyledIcon = styled.Text`
  height: 24px;
  width: 24px;
`;
