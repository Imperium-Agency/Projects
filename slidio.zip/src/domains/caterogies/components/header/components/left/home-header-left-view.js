import {Animated, Platform, Text, TouchableOpacity, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  StyledContainer,
  StyledIcon,
  StyledIconContainer,
  StyledName,
} from './home-header-left-styled';

import {Icon} from '@/components';

const HomeHeaderLeftView = ({name, translateX, onLayout, onBack}) => {
  return (
    <StyledContainer
      as={Animated.View}
      onLayout={onLayout}
      style={[
        {
          transform: [
            {
              translateX: translateX,
            },
          ],
        },
      ]}>
      {Platform.OS == 'ios' && (
        <StyledIconContainer as={TouchableOpacity} onPress={onBack}>
          <StyledIcon as={Icon} name={'arrow-down'} color="#909396" />
        </StyledIconContainer>
      )}

      <StyledName>{name}</StyledName>
    </StyledContainer>
  );
};

export default HomeHeaderLeftView;
