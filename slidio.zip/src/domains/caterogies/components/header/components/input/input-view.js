import {Image, Platform, StyleSheet, TextInput, View} from 'react-native';
import React, {useContext} from 'react';
import {StyledContainer, StyledIcon, StyledInput} from './input-styled';

const Input = ({
  value = null,
  width = 0,
  placholder = '',
  isValid = true,
  autoFocus = false,
  secureTextEntry = false,
  keyboardType,
  style = {},
  setInputRef = () => {},
  onBlur = () => {},
  onChange = () => {},
}) => {
  return (
    <StyledContainer>
      <StyledInput
        as={TextInput}
        ref={(r) => setInputRef(r)}
        value={value}
        onChangeText={onChange}
        keyboardType={keyboardType}
        placeholder={placholder}
        placeholderTextColor="#9F9F9F"
        secureTextEntry={secureTextEntry}
        autoFocus={autoFocus}
        onBlur={onBlur}></StyledInput>
    </StyledContainer>
  );
};

export default Input;
