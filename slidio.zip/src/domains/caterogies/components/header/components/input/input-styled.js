import {margin, padding} from '@theme/spacing';

import {Platform} from 'react-native';
import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  width: 100%;

  margin-top: ${Platform.OS == 'ios' ? 0 : -10}px;

  flex-direction: row;
  align-items: center;

  border-bottom-width: 1px;
  border-color: #909396;
`;

export const StyledInput = styled.View`
  height: ${Platform.OS == 'ios' ? '24px' : '34px'};
  width: 100%;

  padding-bottom: 3px;

  color: #909396;
  font-size: 14px;
  line-height: 14px;

  border-radius: 8px;
`;

export const StyledIcon = styled.View`
  height: 22px;
  width: 22px;

  margin-right: 15px;
`;
