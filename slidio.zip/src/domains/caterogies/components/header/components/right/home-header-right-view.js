import {Animated, Text, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import {StyledIcon, StyledInput} from './home-header-right-styled';

import {Icon} from '@/components';
import Input from '../input';
import {useTranslation} from 'react-i18next';

const HomeHeaderRigthView = ({
  search,
  active,
  rotate,
  translateWidth,
  inputRef,
  setInputRef,
  onTrigger,
  onLayout,
  onChangeSearch,
}) => {
  const {t} = useTranslation();

  useEffect(() => {
    if (inputRef) {
      if (active) inputRef.focus();
      else {
        inputRef.blur();
        onChangeSearch(null);
      }
    }
  }, [active]);

  return (
    <>
      <StyledInput
        as={Animated.View}
        style={[
          {
            width: translateWidth,
          },
        ]}>
        <Input
          placholder={t('home:text_home_search')}
          value={search}
          autoFocus={active}
          setInputRef={setInputRef}
          onChange={onChangeSearch}
        />
      </StyledInput>

      <StyledIcon
        as={Animated.View}
        style={[
          {
            transform: [
              {
                rotateY: rotate,
              },
            ],
          },
        ]}
        onLayout={onLayout}>
        <Icon
          name={active ? 'close' : 'search'}
          color="#909396"
          onPress={onTrigger}
        />
      </StyledIcon>
    </>
  );
};

export default HomeHeaderRigthView;
