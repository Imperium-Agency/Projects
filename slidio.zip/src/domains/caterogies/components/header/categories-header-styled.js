import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  overflow: hidden;
  padding-top: ${(props) => props.insets.top + padding.base}px;
`;

export const StyledContent = styled.View`
  width: 100%;

  flex-direction: row;
  justify-content: space-between;

  padding: 0px ${padding.large}px ${padding.extraSmall}px;
`;

export const StyledName = styled.Text`
  font-size: 16px;

  color: #909396;
`;

export const StyledImageContainer = styled.View`
  position: relative;
  align-items: center;
  height: 168px;

  background-color: #f9955d;
  border-top-left-radius: 44px;
  border-top-right-radius: 44px;

  box-shadow: 0px -10px 15px rgba(0, 0, 0, 0.1);
`;

export const StyledImage = styled.Image`
  position: absolute;
  top: 35%;
  width: 100%;
  left: 0px;
  right: 0px;
  height: 340%;

  z-index: -2;
`;

export const StyleIndicator = styled.View`
  width: 53px;
  height: 5px;
  margin-top: ${padding.extraSmall}px;

  background: #909396;
  border-radius: 14px;

  opacity: 0.64;
`;

export const StyledTitleContainer = styled.View`
  margin-top: ${margin.small}px;
`;

export const StyledTitle = styled.Text`
  font-size: ${(props) => (props.big ? 24 : 18)}px;
  text-align: center;
  color: #ffffff;
  font-weight: 500;
`;

export const StyledLinearGradient = styled.View`
  height: 100%;
  width: 100%;
  position: relative;
  align-items: center;
  top: 0px;
  left: 0px;
  right: 0px;
  bottom: 0px;
  z-index: 1;
`;
