import {Text, View} from 'react-native';

import CategoriesHeaderView from './categories-header-view';
import React from 'react';
import {useNavigation} from '@react-navigation/native';

const CategoriesHeaderContainer = props => {
  const navigation = useNavigation();

  const handlerBack = () => {
    navigation.navigate('Folders');
  };

  return <CategoriesHeaderView {...props} onBack={handlerBack} />;
};

export default CategoriesHeaderContainer;
