import React, {useEffect, useMemo, useState} from 'react';
import {Dimensions} from 'react-native';

import {useNavigation, useRoute} from '@react-navigation/native';

import CategoriesGridView from './caterogies-grid-view';

import {margin, padding} from '@theme/spacing';

import {TABLET_SIDEBAR_WIDTH} from '@/constants';
import {isTablet} from '@/helpers';

// const CARD_BASE_SIZE = {width: 327, height: 168};

import {
  CONTAINER_PADDING_HORIZONTAL,
  CARD_BASE_SIZE,
  CARD_OFFSET,
} from './categories-grid-constant';

const CategoriesContainer = props => {
  // const [containerSize, setContainerSize] = useState({
  //   width: 0,
  //   height: 0,
  // });

  const countColumn = useMemo(() => {
    if (isTablet) {
      return props.isVerticalOrientation ? 3 : 3;
    }

    return 2;
  }, [props.isVerticalOrientation]);

  const cardSize = useMemo(() => {
    const offset =
      isTablet && !props.isVerticalOrientation ? TABLET_SIDEBAR_WIDTH : 0;

    const proportion =
      // containerSize.width -
      (Dimensions.get('window').width -
        offset -
        CONTAINER_PADDING_HORIZONTAL * 2 -
        countColumn * CARD_OFFSET) /
      CARD_BASE_SIZE.width /
      countColumn;

    return {
      width: Math.floor(CARD_BASE_SIZE.width * proportion),
      height: Math.floor(CARD_BASE_SIZE.height * proportion),
    };
  }, [props.isVerticalOrientation]);
  // [containerSize.width, countColumn]);

  return (
    <CategoriesGridView
      {...props}
      cardSize={cardSize}
      countColumn={countColumn}

      // onChangeContainerSize={setContainerSize}
    />
  );
};

export default CategoriesContainer;
