import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';
import styled from 'styled-components/native';

export const StyledFlatList = styled.FlatList.attrs(props => ({
  contentContainerStyle: {
    // alignItems: !isTablet ? 'center' : undefined,
    // justifyContent: 'flex-start',
    // minHeight: '100%',
    flexGrow: 1,
    paddingBottom: padding.large * 2,
    // paddingHorizontal: props.paddingHorizontal,
  },

  // ListHeaderComponentStyle: {
  //   // marginHorizontal:
  // },
}))`
  position: relative;
`;

export const StyledItem = styled.View`
  padding: 0px ${props => props.paddingHorizontal}px;
  margin-bottom: ${isTablet ? margin.big : margin.base}px;
`;

export const StyledKeyboardWatch = styled.View`
  flex: 1;

  justify-content: center;
`;
