import {
  CARD_OFFSET,
  CONTAINER_PADDING_HORIZONTAL,
} from './categories-grid-constant';
import {Dimensions, Text, View} from 'react-native';
import React, {useMemo, useState} from 'react';
import {
  StyledFlatList,
  StyledItem,
  StyledKeyboardWatch,
} from './caterogies-grid-styled';

import CategoriesGridCard from './components/card';
import Empty from '@/containers/empty';
import KeyboardWatch from '@/containers/KeyboardWatch';
import {isTablet} from '@/helpers';

const CaterogiesGridView = ({
  header,
  data,
  search,
  activeSort,
  cardSize,
  countColumn,
  isSubscribe,
  isVerticalOrientation,
  products,
  productsToBuy,
  onSelect,
  onClearFilter,
  onChangeContainerSize,
}) => {
  const _renderItem = ({item, index}) => (
    <StyledItem
      paddingHorizontal={CARD_OFFSET / 2}
      style={{
        transform: [{translateY: index % 2 !== 0 && !isTablet ? 48 : 0}],
      }}>
      <CategoriesGridCard
        data={item}
        imageStyle={cardSize}
        isSubscribe={isSubscribe}
        products={products}
        productsToBuy={productsToBuy}
      />
    </StyledItem>
  );

  return (
    <StyledKeyboardWatch
      as={KeyboardWatch}
      onlyIOS
      watchShow={(search || activeSort) && !data.length}>
      <StyledFlatList
        paddingHorizontal={CONTAINER_PADDING_HORIZONTAL}
        data={data}
        renderItem={_renderItem}
        keyExtractor={(item, index) => `${item.id}`}
        horizontal={false}
        numColumns={countColumn}
        // numColumns={2}
        key={isTablet && !isVerticalOrientation ? 'h' : 'v'}
        ListHeaderComponent={header}
        ListEmptyComponent={
          <Empty
            data={data}
            search={search}
            activeSort={activeSort}
            onClearFilter={onClearFilter}
          />
        }
        // onLayout={(event) => onChangeContainerSize(event.nativeEvent.layout)}
      />
    </StyledKeyboardWatch>
  );
};

export default CaterogiesGridView;
