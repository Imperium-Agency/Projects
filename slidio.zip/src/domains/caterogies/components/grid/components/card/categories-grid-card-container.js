import React, {useMemo} from 'react';

import CategoriesGridCardView from './categories-grid-card-view';
import {useNavigation} from '@react-navigation/native';
import {useRoute} from '@react-navigation/native';

const PresetContainer = (props) => {
  const navigation = useNavigation();

  const isAccess = useMemo(() => {
    return (
      // props.data.free ||
      props.isSubscribe || !!props.products[props.data.productId]
    );
  }, [props.isSubscribe, props.products, props.data]);

  const priceProduct = useMemo(() => {
    if (!props.productsToBuy.data) return false;

    let res = props.productsToBuy.data.filter((item) => {
      return item.productId == props.data.productId;
    });

    if (res.length == 0) return false;

    return {
      price: res[0].price,
      currency: res[0].currency,
      name: props.data.title,
      productId: props.data.productId,
    };
  }, [props.productsToBuy]);

  const handlerSelect = () => {
    navigation.navigate('Preset', {
      data: props.data,
    });
    // if (isAccess) navigation.navigate('Preset', {data: props.data});
    // else if (priceProduct)
    //   navigation.navigate('Subscription', {
    //     firstStart: false,
    //     buyProductData: priceProduct,
    //   });
    // else navigation.navigate('Subscription', {firstStart: false});
  };

  return (
    <CategoriesGridCardView
      {...props}
      onSelect={handlerSelect}
      priceProduct={priceProduct}
      isAccess={isAccess}
    />
  );
};

export default PresetContainer;
