import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  flex: 1;
  padding-top: 94px;
`;

export const StyledImageContainer = styled.ImageBackground`
  margin-bottom: ${margin.small}px;

  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.12);
  elevation: 3;
  border-radius: 8px;

  background-color: #e0e0e0;
`;

export const StyledImage = styled.Image.attrs({
  containerStyle: {
    borderRadius: 8,
  },
})`
  width: 327px;
  height: 168px;

  background: rgba(224, 224, 224, 0.8);
`;

export const StyledDescription = styled.Text`
  font-size: 12px;

  color: #909396;
`;

export const StyledPriceContainer = styled.View`
  margin-top: 4px;

  flex-direction: row;
`;

export const StyledPrice = styled.Text`
  font-weight: 900;
  font-size: 14px;

  color: #ef550a;
`;

export const StyledCurrency = styled.Text`
  margin-left: 4px;

  font-size: 10px;
  line-height: 12px;

  color: #909396;
`;
