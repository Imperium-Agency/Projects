import React, {useMemo} from 'react';
import {
  Platform,
  Text,
  TouchableNativeFeedback,
  TouchableOpacity,
  View,
} from 'react-native';

// import FastImage from 'react-native-fast-image';

import {FastImage} from '@/components';

import {
  StyledCurrency,
  StyledCurrencyContainer,
  StyledDescription,
  StyledImage,
  StyledImageContainer,
  StyledPrice,
  StyledPriceContainer,
} from './categories-grid-card-styled';

import {useTranslation} from 'react-i18next';

const CategoriesGridCardView = ({
  data,
  isAccess,
  priceProduct,
  imageStyle,
  onSelect,
}) => {
  const {i18n, t} = useTranslation('category');

  const TouchableFeedback =
    Platform.OS == 'ios' ? TouchableOpacity : TouchableNativeFeedback;

  return (
    <View style={{width: imageStyle.width}}>
      <StyledImageContainer>
        <TouchableFeedback onPress={onSelect}>
          <StyledImage
            as={FastImage}
            source={{uri: data.image}}
            style={imageStyle}
            // resizeMode={FastImage.resizeMode.cover}
            fallback={Platform.OS === 'android'}
          />
        </TouchableFeedback>
      </StyledImageContainer>

      <StyledDescription numberOfLines={2} ellipsizeMode="clip">
        {data.title}
      </StyledDescription>

      {!isAccess && (data.free || priceProduct) && (
        <StyledPriceContainer>
          <StyledPrice>
            {data.free ? t('text_free') : priceProduct.price}
          </StyledPrice>

          {!data.free && priceProduct.currency && (
            <StyledCurrency>{priceProduct.currency}</StyledCurrency>
          )}
        </StyledPriceContainer>
      )}
    </View>
  );
};

export default CategoriesGridCardView;
