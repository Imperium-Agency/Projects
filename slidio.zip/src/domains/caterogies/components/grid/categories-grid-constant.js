import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';

export const CONTAINER_PADDING_HORIZONTAL = isTablet
  ? margin.big
  : margin.large / 2;

export const CARD_BASE_SIZE = {width: 327, height: 581};

export const CARD_OFFSET = isTablet ? margin.big : margin.large;
