import React from 'react';
import {Linking} from 'react-native';

import PrivacyPolicyView from './term-of-use-view';

import {useNavigation} from '@react-navigation/native';

const PrivacyPolicyContainer = props => {
  const navigation = useNavigation();

  const _handlerOpenLink = href => {
    navigation.navigate(href);
  };

  return <PrivacyPolicyView {...props} onOpenLink={_handlerOpenLink} />;
};

export default PrivacyPolicyContainer;
