export {default} from './term-of-use-view';
