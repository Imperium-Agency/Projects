export {default} from './guide-view';
