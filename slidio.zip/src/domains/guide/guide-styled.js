import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';

export const StyledContainer = styled.View`
  flex: 1;
`;

// export const StyledContent = styled.View`
//   flex: 1;

//   max-width: ${isTablet ? '620px' : '100%'};
//   align-self: center;
// `;

export const StyledImage = styled.Image`
  max-height: 45%;
  width: 100%;
  align-items: center;
  padding-bottom: ${margin.large}px;
  margin-top: ${isTablet ? 'auto' : '0px'};
  margin-bottom: auto;
`;

// export const StyledHeader = styled.View`
//   width: 100%;
//   height: ${props => props.height}px;

//   align-items: center;
// `;

export const StyledBody = styled.View`
  align-items: center;
  justify-content: flex-end;
  margin-bottom: auto;
  padding-horizontal: 39px;
`;

export const StyledTitle = styled.Text`
  margin-bottom: ${margin.large}px;

  font-weight: 600;
  font-size: 18px;
  line-height: 21px;
  text-align: center;
  letter-spacing: -0.3px;
  text-transform: uppercase;
  text-align: center;
  color: ${props => (props.painted ? '#fff' : '#313131')};
`;

export const StyledDescription = styled.Text`
  font-size: 16px;
  line-height: 19px;
  text-align: center;
  letter-spacing: -0.3px;

  color: ${props => (props.painted ? '#fff' : '#313131')};

  opacity: 0.5;
`;

export const StyledFooter = styled.View`
  align-items: center;
  max-width: ${isTablet ? '620px' : '100%'};
  width: 100%;
  padding: 0px ${padding.big}px;
  margin-left: auto;
  margin-right: auto;
  margin-top: ${margin.large * 2}px;
  margin-bottom: ${props => props.insets.bottom + margin.large}px;
`;

export const StyledButton = styled.View`
  height: 67px;
  width: 100%;
  justify-content: center;
  align-items: center;

  background: ${props => (props.painted ? '#fff' : '#EF550A')};
  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.05);
  border-radius: 12px;
`;

export const StyledDots = styled.View`
  width: 100%;
  margin-top: 48px;

  justify-content: center;
  align-items: center;
`;

export const StyledButtonText = styled.Text`
  font-weight: 500;
  font-size: 16px;

  text-align: center;

  color: ${props => (props.painted ? '#EF550A' : '#fff')};
`;
