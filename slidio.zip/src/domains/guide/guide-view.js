import {
  Animated,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import React, {useEffect, useMemo, useState} from 'react';
import {
  StyledBody,
  StyledButton,
  StyledButtonText,
  StyledContainer,
  StyledDescription,
  StyledDots,
  StyledFooter,
  StyledHeader,
  StyledContent,
  StyledImage,
  StyledTitle,
} from './guide-styled';

import {Dots} from '@/components';
import PropTypes from 'prop-types';
import {useSafeArea} from 'react-native-safe-area-context';
import {useTranslation} from 'react-i18next';

// import {margin} from '@theme/spacing';

// import {ScreenWidth} from '@/helpers';

// const IMAGE_BASE_SIZE = {
//   height: 278,
//   width: 278,
// };

const Item = ({
  painted,
  title,
  description,
  source,
  index,

  onNext,
}) => {
  const {t} = useTranslation('gide');

  const insets = useSafeArea();

  return (
    <StyledContainer insets={insets}>
      <StyledImage source={source} resizeMode="contain" />
      {/* <StyledImage height={headerHeight}>{HeaderComponent}</StyledImage> */}

      <StyledBody>
        <StyledTitle as={Animated.Text} painted={painted}>
          {title}
        </StyledTitle>

        <StyledDescription as={Animated.Text} painted={painted}>
          {description}
        </StyledDescription>
      </StyledBody>

      <StyledFooter insets={insets}>
        <TouchableNativeFeedback onPress={onNext}>
          <StyledButton painted={painted}>
            <StyledButtonText painted={painted}>
              {t('text_next')}
            </StyledButtonText>
          </StyledButton>
        </TouchableNativeFeedback>

        <StyledDots>
          <Dots count={3} active={index} color={painted ? '#fff' : '#EF550A'} />
        </StyledDots>
      </StyledFooter>
    </StyledContainer>
  );
};

Item.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  active: PropTypes.bool,
};

Item.defaultProps = {
  active: false,
};

export default Item;
