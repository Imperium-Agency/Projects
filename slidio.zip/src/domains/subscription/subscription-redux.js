import {
  availablePurchasesSelector,
  isSubscribeSelector,
  purchasesSelector,
  subscribeSelector,
  subscriptionsSelector,
} from 'src/modules/iap/selectors';
import {
  changeSubscriptionProcessing,
  changeSubscriptionSussces,
  getAvailablePurchases,
  getSubscriptions,
} from 'src/modules/iap/actions';

import SubscriptionContainer from './subscription-container';
import {connect} from 'react-redux';

const mapStateToProps = (state) => ({
  isSubscribe: isSubscribeSelector(state),
  subscriptions: subscriptionsSelector(state),
  purchases: purchasesSelector(state),
  availablePurchases: availablePurchasesSelector(state),
  subscribe: subscribeSelector(state),
});

const mapDispatchToProps = {
  getAvailablePurchases: getAvailablePurchases,
  getSubscriptions: getSubscriptions,
  changeSubscriptionProcessing: changeSubscriptionProcessing,
  changeSubscriptionSussces: changeSubscriptionSussces,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(SubscriptionContainer);
