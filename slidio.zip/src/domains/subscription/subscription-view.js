import {Animated, ScrollView, Text} from 'react-native';
import {
  StyledBody,
  StyledContainer,
  StyledFooter,
  StyledImage,
  StyledScrollView,
  StyledTitle,
} from './subscription-styled';

import {Modal} from '@/components';
import React from 'react';
import SubscriptionPolicy from './components/policy';
import SubscriptionTariff from './components/tariff';
import {useSafeArea} from 'react-native-safe-area-context';
import {useTranslation} from 'react-i18next';

const SubscriptionView = ({
  firstStart,
  purchases,
  onClose,
  onAvailablePurchases,
}) => {
  const {t} = useTranslation('subscription');

  const insets = useSafeArea();

  return (
    <Modal
      background="#F6F3F1"
      offset={firstStart ? (Platform.OS == 'ios' ? 108 : 78) : 0}>
      <StyledScrollView insets={insets}>
        <StyledImage
          source={require('./images/image.png')}
          resizeMode="contain"
        />

        <StyledBody>
          {/* <Text>{JSON.stringify(purchases)}</Text> */}
          <StyledTitle as={Animated.Text}>{t('text_title')}</StyledTitle>

          <SubscriptionTariff onAvailablePurchases={onAvailablePurchases} />
        </StyledBody>

        <StyledFooter insets={insets}>
          <SubscriptionPolicy />

          {/* {withSteps && (
            <StyledDots>
              <Dots
                count={3}
                active={index}
                color={painted ? '#fff' : '#EF550A'}
              />
            </StyledDots>
          )} */}
        </StyledFooter>
      </StyledScrollView>
    </Modal>
  );
};

export default SubscriptionView;
