import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';

export const StyledScrollView = styled.ScrollView.attrs(props => ({
  contentContainerStyle: {
    flexGrow: 1,
    // minHeight: '100%',
    // paddingTop: props.insets.top,
    // paddingHorizontal: padding.large,
    justifyContent: isTablet ? 'center' : 'flex-start',
    // alignItems: 'center',
  },
}))`
  position: relative;
  height: 100%;
`;

export const StyledImage = styled.Image`
  max-height: 45%;
  width: 100%;
  align-items: center;
  margin-top: ${margin.extraSmall}px;
  margin-bottom: ${margin.large}px;
`;

export const StyledBody = styled.View`
  max-width: ${isTablet ? '620px' : '100%'};
  width: 100%;
  align-items: center;
  align-self: center;
  justify-content: flex-end;

  padding-horizontal: 39px;
  margin-vertical: ${isTablet ? margin.big : 0}px;
`;
// margin - bottom: auto;

export const StyledTitle = styled.Text`
  margin-bottom: 18px;

  font-weight: 600;
  font-size: 16px;
  line-height: 19px;
  text-align: center;
  letter-spacing: -0.3px;
  text-transform: uppercase;
  text-align: center;
  color: #313131;
`;

export const StyledFooter = styled.View`
  max-width: ${isTablet ? '620px' : '100%'};
  width: 100%;
  align-items: center;
  align-self: center;
  padding: 0px ${padding.big}px;
  margin-top: ${margin.big}px;
  margin-bottom: ${props => props.insets.bottom + margin.large}px;
`;
