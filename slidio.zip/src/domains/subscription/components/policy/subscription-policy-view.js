import {
  StyledContainer,
  StyledInfo,
  StyledInfoItem,
  StyledTerms,
} from './subscription-policy-styled';

import React from 'react';
import {TouchableOpacity} from 'react-native';
import {useTranslation} from 'react-i18next';

const SubscriptionPolicyView = ({onNavigate}) => {
  const {t} = useTranslation('subscription');

  return (
    <StyledContainer>
      <StyledTerms>{t('text_terms')}</StyledTerms>

      <StyledInfo>
        <TouchableOpacity onPress={() => onNavigate('TermOfUse')}>
          <StyledInfoItem>{t('text_terms_of_use')}</StyledInfoItem>
        </TouchableOpacity>

        <StyledInfoItem> | </StyledInfoItem>

        <TouchableOpacity onPress={() => onNavigate('PrivacyPolicy')}>
          <StyledInfoItem>{t('text_privacy_policy')}</StyledInfoItem>
        </TouchableOpacity>
      </StyledInfo>
    </StyledContainer>
  );
};

export default SubscriptionPolicyView;
