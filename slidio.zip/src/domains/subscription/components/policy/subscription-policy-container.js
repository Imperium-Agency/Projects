import React from 'react';

import SubscriptionPolicyView from './subscription-policy-view';

import {useNavigation} from '@react-navigation/native';

const SubscriptionPolicyContainer = () => {
  const navigation = useNavigation();

  const onNavigate = route => {
    navigation.navigate(route);
  };

  return <SubscriptionPolicyView onNavigate={onNavigate} />;
};

export default SubscriptionPolicyContainer;
