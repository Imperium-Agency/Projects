import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  align-items: center;
`;

export const StyledTerms = styled.Text`
  margin-bottom: 18px;
  text-align: center;
  font-size: 10px;
  color: rgba(0, 0, 0, 0.5);
`;

export const StyledInfo = styled.View`
  width: 100%;
  flex-direction: row;
`;

export const StyledInfoItem = styled.Text`
  padding-vertical: 5px;
  font-size: 12px;
`;
