import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  width: 100%;
`;

export const StyledContent = styled.View``;

export const StyledItem = styled.View`
  margin-bottom: ${(props) => (props.first ? margin.large : 0)}px;
`;

export const StyledButton = styled.View`
margin-top: 28px;

  height: 67px;
  width: 100%;
  justify-content: center;
  align-items: center;

  background: #EF550A';
  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.05);
  border-radius: 12px;
`;

export const StyledButtonText = styled.Text`
  font-weight: 500;
  font-size: 16px;

  text-align: center;

  color: #fff;
`;

export const StyledCancellation = styled.Text`
  margin-top: 11px;
  color: rgba(0, 0, 0, 0.5);
  font-size: 14px;
  text-align: center;
`;

export const StyledRestore = styled.Text`
  margin-top: ${margin.small}px;
  margin-left: auto;
  margin-right: auto;
  padding-vertical: 5px;
`;
