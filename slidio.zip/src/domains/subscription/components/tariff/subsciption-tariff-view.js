import {ActivityIndicator, Text, TouchableNativeFeedback} from 'react-native';
import {
  StyledButton,
  StyledButtonText,
  StyledCancellation,
  StyledContainer,
  StyledContent,
  StyledItem,
  StyledRestore,
} from './subsciption-tariff-styled';

import {Button} from '@/components';
import React from 'react';
import SubsciptionTariffItem from './components/item';
import {useTranslation} from 'react-i18next';

const SubscriptionTariffView = ({
  activeTariff,
  loading,
  data,
  buyProductData,
  onSelectTariff,
  onBuy,
  onAvailablePurchases,
}) => {
  const {t} = useTranslation(['subscription', 'gide']);

  return (
    <StyledContainer>
      {loading && !data ? (
        <ActivityIndicator size="small" color="#313131" />
      ) : (
        <>
          <StyledContent>
            {/* <Text>{JSON.stringify(data)}</Text> */}
            {data && (
              <>
                {buyProductData && (
                  <StyledItem first>
                    <SubsciptionTariffItem
                      active={activeTariff === 'product'}
                      price={`${buyProductData.price} ${buyProductData.currency}`}
                      name={buyProductData.name}
                      onPress={() => onSelectTariff('product')}
                    />
                  </StyledItem>
                )}

                {!buyProductData && (
                  <StyledItem first>
                    <SubsciptionTariffItem
                      active={activeTariff === 'monthly'}
                      price={data.monthly.year}
                      period={t('text_tariff_period_monthly')}
                      name={t('text_tariff_name_monthly')}
                      description={t('text_tariff_description_monthly', {
                        cost: data.monthly.year,
                      })}
                      onPress={() => onSelectTariff('monthly')}
                    />
                  </StyledItem>
                )}

                <StyledItem>
                  <SubsciptionTariffItem
                    active={activeTariff === 'yearly'}
                    price={data.yearly.year}
                    period={t('text_tariff_period_annual')}
                    name={t('text_tariff_name_annual')}
                    description={t('text_tariff_description_annual', {
                      cost: data.yearly.month,
                    })}
                    onPress={() => onSelectTariff('yearly')}
                  />
                </StyledItem>
              </>
            )}
          </StyledContent>

          <StyledRestore onPress={onAvailablePurchases}>
            <Text>{t('text_restore')}</Text>
          </StyledRestore>

          <TouchableNativeFeedback onPress={onBuy}>
            <StyledButton>
              <StyledButtonText>{t('gide:text_next')}</StyledButtonText>
            </StyledButton>
          </TouchableNativeFeedback>

          <StyledCancellation>{t('text_cancellation')}</StyledCancellation>
        </>
      )}
    </StyledContainer>
  );
};

export default SubscriptionTariffView;
