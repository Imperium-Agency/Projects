import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  padding: 12px;

  background: #ffffff;

  box-shadow: ${(props) =>
    props.active
      ? '0px 10px 20px rgba(239, 85, 10, 0.2)'
      : '0px 10px 20px rgba(0, 0, 0, 0.12)'};

  border-radius: 12px;

  border: 2px solid #fff;
`;

// border: 2px solid ${(props) => (props.active ? '#ef550a' : '#fff')};

export const StyledHeader = styled.View`
  flex-direction: row;
  justify-content: space-between;

  margin-bottom: 5px;
`;

export const StyledFooter = styled.View`
  flex-direction: row;
  justify-content: space-between;
`;

export const StyledName = styled.Text`
  max-width: 70%;
  font-size: 16px;
  line-height: 19px;

  color: #313131;
`;

export const StyledPrice = styled.Text`
  font-weight: 500;

  font-size: 16px;
  line-height: 19px;

  color: #313131;
`;

export const StyledText = styled.Text`
  opacity: 0.5;
  font-weight: 300;
  font-size: 16px;
  line-height: 19px;

  color: #313131;
`;
