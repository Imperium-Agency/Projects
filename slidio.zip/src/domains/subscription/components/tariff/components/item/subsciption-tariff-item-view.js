import {
  Animated,
  StyleSheet,
  Text,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  StyledContainer,
  StyledFooter,
  StyledHeader,
  StyledName,
  StyledPrice,
  StyledText,
} from './subsciption-tariff-item-styled';

import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';

const Item = ({name, price, description, period, active, onPress}) => {
  const [activeValue] = useState(new Animated.Value(active ? 1 : 0));

  useEffect(() => {
    Animated.timing(activeValue, {
      toValue: active ? 1 : 0,
      useNativeDriver: false,
      duration: 400,
    }).start();
  }, [active]);

  const borderColor = activeValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['#fff', '#ef550a'],
  });

  const textColor = activeValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['#FA7268', '#FFFFFF'],
  });

  return (
    <TouchableWithoutFeedback onPress={onPress}>
      <StyledContainer as={Animated.View} style={{borderColor}} active={active}>
        <StyledHeader>
          <StyledName numberOfLines={1}>{name}</StyledName>
          <StyledPrice>{price}</StyledPrice>
        </StyledHeader>

        <StyledFooter>
          {description && <StyledText>{description}</StyledText>}
          {period && <StyledText>{period}</StyledText>}
        </StyledFooter>
      </StyledContainer>
    </TouchableWithoutFeedback>
  );
};

Item.defaultProps = {
  active: false,
  onPress: () => {},
};

const styles = StyleSheet.create({
  container: {
    paddingVertical: 12,

    backgroundColor: '#FA7268',

    borderRadius: 12,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 16,
    paddingRight: 11,
    marginBottom: 4,
  },

  name: {
    color: '#fff',
    fontSize: 16,
  },

  price: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
    // transform: [{translateX: 5}],
  },

  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },

  fullPrice: {
    fontSize: 16,
    fontWeight: '300',
    color: '#fff',
    opacity: 0.5,
    // color: 'rgba(255, 255, 255, 0.6)',
  },

  period: {
    fontSize: 16,
    fontWeight: '300',
    color: '#fff',
    opacity: 0.5,
    // color: 'rgba(255, 255, 255, 0.6)',
  },
});

export default Item;
