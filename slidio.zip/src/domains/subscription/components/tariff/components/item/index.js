export {default} from './subsciption-tariff-item-view';
