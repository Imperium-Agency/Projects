import {Alert, Platform} from 'react-native';
import React, {useMemo, useState} from 'react';

import RNIap from 'react-native-iap';
import SubscriptionTariffView from './subsciption-tariff-view';
import invert from 'lodash/invert';
import {items} from 'src/config/iap';
import {useNavigation} from '@react-navigation/native';
import {useRoute} from '@react-navigation/native';

const SubscriptionContainer = ({
  subscriptions,
  getAvailablePurchases,
  changeSubscriptionProcessing,
  changeSubscriptionSussces,
}) => {
  const route = useRoute();

  const navigation = useNavigation();

  const [activeTariff, setActiveTariff] = useState('yearly');

  const firstStart = (route.params && route.params.firstStart) || false;

  const buyProductData = (route.params && route.params.buyProductData) || false;

  const data = useMemo(() => {
    console.log('subscriptions', subscriptions);

    if (!subscriptions.data || !subscriptions.data.length) return null;

    const _items = invert(items);

    let res = {};

    subscriptions.data.map((item) => {
      const key = _items[item.productId.split('_start')[0]];

      if (
        item.productId.indexOf(route.params.firstStart ? '_start' : '') != -1
      ) {
        // let localizedPrices = item.localizedPrice.split(' ');

        res[key] = {
          year: item.price + ` ${item.currency}`,
          month: (item.price / 12).toFixed(2) + ` ${item.currency}`,
        };
      }
    });

    return res;
  }, [subscriptions.data]);

  const handlerequestSubscription = () => {
    changeSubscriptionProcessing(true);
    changeSubscriptionSussces(null);

    // console.log('items', items);
    if (activeTariff == 'product') requestPurchase(buyProductData.productId);
    else
      requestSubscription(items[activeTariff] + (firstStart ? '_start' : ''));
  };

  const requestSubscription = async (sku) => {
    try {
      await RNIap.requestSubscription(sku, false);
    } catch (err) {
      changeSubscriptionProcessing(false);
      changeSubscriptionSussces(false);

      if (err.code != 'E_USER_CANCELLED') Alert.alert(err.message);
    }
  };

  const requestPurchase = async (sku) => {
    console.log('requestPurchase', sku);

    try {
      await RNIap.requestPurchase(sku, false);
    } catch (err) {
      changeSubscriptionProcessing(false);
      changeSubscriptionSussces(false);

      if (err.code != 'E_USER_CANCELLED') Alert.alert(err.message);
    }
  };

  return (
    <SubscriptionTariffView
      data={data}
      buyProductData={buyProductData}
      loading={subscriptions.loading}
      activeTariff={activeTariff}
      onSelectTariff={setActiveTariff}
      onBuy={handlerequestSubscription}
      onAvailablePurchases={getAvailablePurchases}
    />
  );
};

export default SubscriptionContainer;
