import {
  changeSubscriptionProcessing,
  changeSubscriptionSussces,
  getAvailablePurchases,
} from 'src/modules/iap/actions';

import SubscriptionTarifContainer from './subsciption-tariff-container';
import {connect} from 'react-redux';
import {subscriptionsSelector} from 'src/modules/iap/selectors';

const mapStateToProps = (state) => ({
  subscriptions: subscriptionsSelector(state),
});

const mapDispatchToProps = {
  getAvailablePurchases: getAvailablePurchases,
  changeSubscriptionProcessing: changeSubscriptionProcessing,
  changeSubscriptionSussces: changeSubscriptionSussces,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(SubscriptionTarifContainer);
