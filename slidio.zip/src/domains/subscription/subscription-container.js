import React, {useEffect} from 'react';
import {useNavigation, useRoute} from '@react-navigation/native';

import SubscriptionView from './subscription-view';

const SubscriptionContainer = ({
  isSubscribe,
  subscribe,
  purchases,
  availablePurchases,
  getAvailablePurchases,
  changeSubscriptionSussces,
}) => {
  const route = useRoute();
  const navigation = useNavigation();

  useEffect(() => {
    if (isSubscribe && (availablePurchases.susses || subscribe.susses)) {
      navigation.navigate('Home');
    }
  }, [availablePurchases.susses, subscribe.susses]);

  const firstStart = (route.params && route.params.firstStart) || false;

  const handlerClose = () => {
    if (firstStart) {
      navigation.navigate('Home');
    } else {
      navigation.goBack();
    }
  };

  return (
    <SubscriptionView
      firstStart={firstStart}
      purchases={purchases}
      onClose={handlerClose}
      onAvailablePurchases={getAvailablePurchases}
    />
  );
};

export default SubscriptionContainer;
