import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.View`
  flex: 1;
  background-color: #f8f8f8;
`;

export const StyledScrollView = styled.ScrollView.attrs({
  contentContainerStyle: {
    paddingVertical: padding.large,
    paddingHorizontal: padding.big,
  },
})``;
