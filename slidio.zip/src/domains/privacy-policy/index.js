export {default} from './privacy-policy-view';
