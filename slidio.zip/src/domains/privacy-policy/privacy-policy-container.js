import React from 'react';
import {Linking} from 'react-native';

import PrivacyPolicyView from './privacy-policy-view';

const PrivacyPolicyContainer = props => {
  const _handlerOpenLink = href => {
    Linking.openURL(href);
  };

  return <PrivacyPolicyView {...props} onOpenLink={_handlerOpenLink} />;
};

export default PrivacyPolicyContainer;
