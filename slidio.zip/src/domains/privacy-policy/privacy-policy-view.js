import {StyledContainer, StyledScrollView} from './privacy-policy-styled';

import {Dimensions} from 'react-native';
import HTML from 'react-native-render-html';
import {Header} from '@/components';
import MarkdownIt from 'markdown-it';
import React from 'react';
import {content} from './privacy-policy-config';

const md = new MarkdownIt();

const PrivacyPolicy = ({onOpenLink}) => {
  return (
    <StyledContainer>
      <Header title="Privacy Policy" withBack />

      <StyledScrollView>
        <HTML
          html={md.render(content)}
          imagesMaxWidth={Dimensions.get('window').width}
          onLinkPress={(evt, href) => onOpenLink(href)}
          tagsStyles={{
            p: {
              lineHeight: 22,
              marginBottom: 20,
            },
            h4: {
              marginBottom: 15,

              fontSize: 19,
              fontWeight: '700',
            },
            strong: {fontSize: 15},
            ul: {paddingLeft: 10, marginBottom: 0},
            li: {
              marginBottom: 0,
              paddingBottom: 0,
            },
          }}
        />
      </StyledScrollView>
    </StyledContainer>
  );
};

export default PrivacyPolicy;
