import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledFlatList = styled.FlatList.attrs({
  contentContainerStyle: {
    paddingHorizontal: padding.large,
  },
})``;

export const StyledItem = styled.TouchableOpacity`
  min-width: 78px;
  padding: ${padding.extraSmall}px;
  margin-right: ${props => (!props.last ? margin.extraSmall : 0)}px;

  background-color: #fff;
  border-radius: 6px;
  border: ${props => (props.selected ? '1px solid #53BDF9' : '1px solid #fff')};
`;

export const StyledItemText = styled.Text`
  margin-top: 3px;

  font-size: 15px;
  color: #313131;

  opacity: 0.7;
`;
