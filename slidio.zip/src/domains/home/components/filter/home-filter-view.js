import React, {useMemo} from 'react';
import {StyledFlatList, StyledItem, StyledItemText} from './home-filter-styled';
import {Text, TouchableOpacity, View} from 'react-native';

import {Icon} from '@/components';

import {useTranslation} from 'react-i18next';

const itemsDefault = [
  {
    // name: 'Free',
    key: 'free',
    icon: require('./images/party.png'),
    color: '#53BDF9',
  },
  {
    // name: 'VSCO Pro',
    key: 'pro',
    icon: require('./images/achievements.png'),
    color: '#F95361',
  },
];

const HomeFilterView = ({activeFilter, items, onChangeActiveFilter}) => {
  const {t} = useTranslation();

  const handleChange = data => {
    let res = [...activeFilter];

    let index = activeFilter.indexOf(data.key);

    if (index == -1) res.push(data.key);
    else res.splice(index, 1);

    onChangeActiveFilter(res);
  };

  const data = useMemo(() => {
    const _itemsDefault = itemsDefault.map(item => ({
      ...item,
      name: t(`common:text_tag_${item.key}`),
    }));
    return [..._itemsDefault, ...items];
  }, [items, t]);

  return (
    <StyledFlatList
      data={data}
      horizontal={true}
      keyExtractor={(item, index) => `${item.id}`}
      showsHorizontalScrollIndicator={false}
      renderItem={({item, index}) => (
        <StyledItem
          as={TouchableOpacity}
          selected={activeFilter.indexOf(item.key) != -1}
          last={index === data.length - 1}
          onPress={() => handleChange(item)}>
          <Icon source={item.icon} color={item.color} />

          <StyledItemText>{item.name}</StyledItemText>
        </StyledItem>
      )}
    />
  );
};

export default HomeFilterView;
