import React, {useEffect, useMemo, useState} from 'react';

import HomeFilterView from './home-filter-view';

const HomeFilterContainer = (props) => {
  const items = useMemo(() => {
    let res = [];

    const filterIcon = require('./images/camera.png');

    for (let item of props.presetsData) {
      let filtered = res.filter((el) => el.key == item.filter.name);

      if (filtered.length == 0) {
        res.push({
          ...item.filter,
          ...{
            key: item.filter.name,
            icon: filterIcon,
          },
        });
      }
    }

    return res;
  }, [props.presetsData]);

  return <HomeFilterView {...props} items={items} />;
};

export default HomeFilterContainer;
