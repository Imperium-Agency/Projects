import {
  StyledContainer,
  StyledIcon,
  StyledIconBack,
  StyledSearch,
  StyledTitle,
} from './home-header-styled';
import {Text, View} from 'react-native';
import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';

import {Icon} from '@/components';
import React from 'react';
import {isTablet} from '@/helpers';
import {useSafeArea} from 'react-native-safe-area-context';

const HomeHeaderView = ({
  title,
  isVerticalOrientation,
  searchComponent,
  onShowMenu,
  onBack,
}) => {
  const insets = useSafeArea();

  return (
    <StyledContainer
      insets={insets}
      paddingHorizontal={
        isTablet ? padding.big * (isVerticalOrientation ? 1 : 2) : padding.large
      }
      paddingTop={isTablet ? padding.large : padding.small}
      paddingBottom={isTablet ? padding.big : padding.large}>
      <StyledIconBack>
        <Icon name="back" color="#313131" size="32" onPress={onBack} />
      </StyledIconBack>

      <StyledTitle>{title}</StyledTitle>

      <StyledSearch>{searchComponent}</StyledSearch>

      {(isVerticalOrientation || !isTablet) && (
        <StyledIcon>
          <Icon name="menu" onPress={onShowMenu} />
        </StyledIcon>
      )}
    </StyledContainer>
  );
};

export default HomeHeaderView;
