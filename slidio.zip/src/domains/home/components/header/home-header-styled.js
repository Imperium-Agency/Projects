import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  margin-top: ${(props) => props.insets.top}px;

  padding: ${(props) => props.paddingTop}px
    ${(props) => props.paddingHorizontal}px ${(props) => props.paddingBottom}px;
`;

export const StyledTitle = styled.Text`
  margin-right: auto;
  font-weight: 500;
  font-size: 24px;

  color: #313131;
`;

export const StyledSearch = styled.View`
  flex-basis: 40%;
`;

export const StyledIcon = styled.View`
  margin-left: ${margin.large}px;
`;

export const StyledIconBack = styled.View`
  margin-right: ${margin.small}px;
`;
