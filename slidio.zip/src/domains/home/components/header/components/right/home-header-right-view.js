import {Animated, Text, View} from 'react-native';
import {Icon, Input} from '@/components';
import React, {useEffect, useState} from 'react';
import {StyledIcon, StyledInput} from './home-header-right-styled';

const HomeHeaderRigthView = ({
  search,
  active,
  rotate,
  translateWidth,
  inputRef,
  setInputRef,
  onTrigger,
  onLayout,
  onChangeSearch,
}) => {
  useEffect(() => {
    if (inputRef) {
      if (active) inputRef.focus();
      else {
        inputRef.blur();
        onChangeSearch(null);
      }
    }
  }, [active]);

  return (
    <>
      <StyledInput
        as={Animated.View}
        style={[
          {
            width: translateWidth,
          },
        ]}>
        <Input
          value={search}
          autoFocus={active}
          setInputRef={setInputRef}
          onChange={onChangeSearch}
        />
      </StyledInput>

      <StyledIcon
        as={Animated.View}
        style={[
          {
            transform: [
              {
                rotateY: rotate,
              },
            ],
          },
        ]}
        onLayout={onLayout}>
        <Icon name={active ? 'close' : 'search'} onPress={onTrigger} />
      </StyledIcon>
    </>
  );
};

export default HomeHeaderRigthView;
