import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledIcon = styled.View`
  margin-left: ${margin.small}px;
`;

export const StyledInput = styled.View`
  margin-left: auto;
  overflow: hidden;
`;
