import {Animated, Text, View} from 'react-native';
import React, {useEffect, useState} from 'react';

import {Icon} from '@/components';

const HomeHeaderLeftView = ({active, onTrigger, onLayout}) => {
  return (
    <View onLayout={onLayout}>
      {!active ? (
        <Icon name="menu" onPress={onTrigger} />
      ) : (
        <Icon name="close" onPress={onTrigger} />
      )}
    </View>
  );
};

export default HomeHeaderLeftView;
