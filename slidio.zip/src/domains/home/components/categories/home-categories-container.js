import React, {useContext, useMemo} from 'react';
import {Text, View} from 'react-native';

import HomeCategories from './home-categories-view';
import {OrientationContext} from '@/context';
import {useNavigation} from '@react-navigation/native';

const HomeCategoriesContainer = ({data, onSelect, ...props}) => {
  const {isVerticalOrientation} = useContext(OrientationContext);

  const navigation = useNavigation();

  const renderData = useMemo(() => {
    const middleCount = Math.ceil(data.length / 2);

    return [data.slice(0, middleCount), data.slice(middleCount, data.length)];
  }, [data]);

  // const handlerSelect = data => {
  //   navigation.navigate('Categories', {data});
  // };

  return (
    <HomeCategories
      {...props}
      data={renderData}
      isVerticalOrientation={isVerticalOrientation}
      // onSelect={handlerSelect}
      onSelect={onSelect}
    />
  );
};

export default HomeCategoriesContainer;
