import {isTablet} from '@/helpers';
import {margin, padding} from '@theme/spacing';

export const CARD_BASE_SIZE = {
  big: isTablet
    ? {
        width: 363,
        height: 248,
      }
    : {
        width: 154,
        height: 224,
      },

  small: isTablet
    ? {
        width: 363,
        height: 248,
      }
    : {
        width: 154,
        height: 184,
      },
};

export const CARD_OFFSET = isTablet ? margin.large / 2 : margin.small / 2;
