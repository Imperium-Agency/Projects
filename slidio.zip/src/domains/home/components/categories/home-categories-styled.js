import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';
import {isTablet} from '@/helpers';

export const StyledContainer = styled.View`
  flex: 1;
  padding: 0px ${props => props.offset.right}px 0px
    ${props => props.offset.left}px;
`;

export const StyledContent = styled.View`
  flex: 1;
`;

export const StyledTitle = styled.Text`
  margin-bottom: ${margin.large}px;
  padding: 0 ${props => props.paddingHorizontal}px;

  font-size: 14px;
  color: #909396;
`;

export const StyledBody = styled.View`
  flex: 1;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-between;
`;

export const StyledRow = styled.View``;

export const StyledItem = styled.View`
  margin-bottom: ${isTablet ? padding.big : padding.large}px;
  padding: 0 ${props => props.paddingHorizontal}px;
`;

export const StyledEmpty = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
`;
