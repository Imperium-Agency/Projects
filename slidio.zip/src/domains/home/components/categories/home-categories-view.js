import {CARD_BASE_SIZE, CARD_OFFSET} from './home-categories-constant';
import {Dimensions, Text, View} from 'react-native';
import React, {useMemo, useState} from 'react';
import {
  StyledBody,
  StyledContainer,
  StyledContent,
  StyledEmpty,
  StyledItem,
  StyledRow,
  StyledTitle,
} from './home-categories-styled';
import {margin, padding} from '@theme/spacing';

import HomeCategoriesCard from './components/card';
import {isTablet} from '@/helpers';
import {useTranslation} from 'react-i18next';

const HomeCategoriesView = ({
  data,
  isVerticalOrientation,
  EmptyComponent,
  onSelect,
}) => {
  const {t} = useTranslation('home');

  const [contentWidth, setContentWidth] = useState(0);

  const cardOffset = useMemo(() => {
    return isTablet && !isVerticalOrientation ? CARD_OFFSET * 2 : CARD_OFFSET;
  }, [isVerticalOrientation]);

  const containerOffset = useMemo(() => {
    const tabletOffset =
      padding.big * (!isVerticalOrientation ? 2 : 1) - cardOffset;

    return {
      left: isTablet ? tabletOffset : padding.base,
      right: isTablet
        ? isVerticalOrientation
          ? tabletOffset
          : tabletOffset + 77
        : padding.base,
    };
  }, [cardOffset, isVerticalOrientation]);

  const cardSize = useMemo(() => {
    const propportion =
      (contentWidth -
        CARD_OFFSET * (isTablet && !isVerticalOrientation ? 8 : 4)) /
      CARD_BASE_SIZE.big.width /
      2;

    return {
      big: {
        width: CARD_BASE_SIZE.big.width * propportion,
        height: CARD_BASE_SIZE.big.height * propportion,
      },
      small: {
        width: CARD_BASE_SIZE.small.width * propportion,
        height: CARD_BASE_SIZE.small.height * propportion,
      },
    };
  }, [contentWidth]);

  return (
    <StyledContainer offset={containerOffset}>
      <StyledContent
        onLayout={event => setContentWidth(event.nativeEvent.layout.width)}>
        <StyledTitle paddingHorizontal={cardOffset}>
          {t('text_categories')}
        </StyledTitle>

        <StyledBody>
          {data[0].length ? (
            data.map((row, indexRow) => (
              <StyledRow>
                {row.map((item, index) => (
                  <StyledItem paddingHorizontal={cardOffset}>
                    <HomeCategoriesCard
                      data={item}
                      contnetStyle={
                        cardSize[(index + indexRow) % 2 === 0 ? 'big' : 'small']
                      }
                      reverse={!isTablet && (index + indexRow) % 2 !== 0}
                      onSelect={onSelect}
                    />
                  </StyledItem>
                ))}
              </StyledRow>
            ))
          ) : (
            <StyledEmpty>{EmptyComponent}</StyledEmpty>
          )}
        </StyledBody>
      </StyledContent>
    </StyledContainer>
  );
};

export default HomeCategoriesView;
