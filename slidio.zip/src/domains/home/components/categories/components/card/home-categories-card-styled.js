import {margin, padding} from '@theme/spacing';

import {isTable} from '@/helpers';
import styled from 'styled-components/native';

export const StyledContainer = styled.View``;

export const StyledContent = styled.View`
  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.12);
  elevation: 3;
  border-radius: 15px;
  background: #f9955d;
`;

export const StyledWrapper = styled.View`
  flex-direction: ${props => (props.reverse ? 'column-reverse' : 'column')};
  flex: 1;
  border-radius: 15px;

  overflow: hidden;
`;

export const StyledDescription = styled.Text`
  margin-top: ${isTable ? margin.large : margin.base}px;

  font-size: ${isTable ? 16 : 12}px;
  color: #a9a9b0;
`;

export const StyledTitleContainer = styled.View`
  padding-horizontal: ${padding.base}px;
  padding-top: ${props => (props.reverse ? padding.small : padding.base)}px;
  padding-bottom: ${props => (props.reverse ? padding.base : padding.small)}px;
`;

export const StyledTitle = styled.Text`
  font-size: ${props => (props.big ? 24 : 18)}px;
  text-align: center;
  color: #ffffff;
  font-weight: 500;
`;

export const StyledImage = styled.Image.attrs(props => ({
  indicatorStyle: {
    marginTop: props.reverse ? '65%' : '42%',
  },
}))`
  width: 100%;
  height: 95%;
`;
