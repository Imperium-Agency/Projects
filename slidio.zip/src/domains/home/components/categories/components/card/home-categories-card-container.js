import React, {useMemo} from 'react';
import {View, Text} from 'react-native';

import HomeCategoriesCardView from './home-categories-card-view';

import {useTranslation} from 'react-i18next';

const HomeCategoriesCardContainer = props => {
  const {i18n} = useTranslation();

  const meta = useMemo(() => {
    let name = props.data.name[i18n.language];
    let names = name.split(' ');
    let description = name.slice(names[0].length + 1, name.length);

    return {
      title: names[0],
      description: description.slice(0, 1).toUpperCase() + description.slice(1),
    };
  }, [props.data.name, i18n.language]);

  return (
    <HomeCategoriesCardView
      {...props}
      {...meta}
      name={props.data.name[i18n.language]}
    />
  );
};

export default HomeCategoriesCardContainer;
