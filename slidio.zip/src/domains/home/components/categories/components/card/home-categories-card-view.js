import {
  Image,
  Platform,
  TouchableNativeFeedback,
  TouchableOpacity,
} from 'react-native';
import React, {useMemo} from 'react';

import {FastImage} from '@/components';

import {
  StyledContainer,
  StyledContent,
  StyledDescription,
  StyledImage,
  StyledTitle,
  StyledTitleContainer,
  StyledWrapper,
} from './home-categories-card-styled';

// import FastImage from 'react-native-fast-image';

const HomeCategoriesCardView = ({
  data,
  title,
  name,
  description,
  reverse,
  contnetStyle,
  onSelect,
}) => {
  const TouchableFeedback =
    Platform.OS == 'ios' ? TouchableOpacity : TouchableNativeFeedback;

  return (
    <StyledContainer>
      <TouchableFeedback onPress={() => onSelect(data)}>
        <StyledContent style={contnetStyle}>
          <StyledWrapper reverse={reverse}>
            <StyledTitleContainer reverse={reverse}>
              <StyledTitle big> {title} </StyledTitle>
              <StyledTitle> {description} </StyledTitle>
            </StyledTitleContainer>

            <StyledImage
              as={FastImage}
              indicator
              indicatorProps={{color: '#fff'}}
              source={{uri: data.image}}
              fallback={Platform.OS === 'android'}
              reverse={reverse}
            />
          </StyledWrapper>
        </StyledContent>
      </TouchableFeedback>

      <StyledDescription numberOfLines={1}>{name}</StyledDescription>
    </StyledContainer>
  );
};

export default HomeCategoriesCardView;
