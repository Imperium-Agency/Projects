import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

// export const StyledContainer = styled.View`
//   width: 100%;
// `;

export const StyledImageContainer = styled.View`
  margin-bottom: ${margin.large}px;
  padding-top: ${margin.large}px;

  box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.12);
  elevation: 3;
  border-radius: 8px;
`;

export const StyledImage = styled.Image.attrs({
  containerStyle: {
    borderRadius: 8,
  },
})`
  width: ${props => props.width};
  height: ${props => props.height};

  background: rgba(224, 224, 224, 0.8);
`;
