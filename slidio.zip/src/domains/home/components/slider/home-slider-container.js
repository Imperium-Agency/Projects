import React, {useMemo} from 'react';

import HomeSliderView from './home-slider-view';
import {useNavigation} from '@react-navigation/native';

const HomeSliderContainer = ({data, isVerticalOrientation, onSelect}) => {
  const navigation = useNavigation();

  const renderData = useMemo(() => {
    let res = [];

    data.forEach(item => {
      item.categories.forEach(el => {
        if (el.showInSlider) {
          res.push({...el, categoryId: item.id});
        }
      });
      // let filtered = item.categories.filter(el => ({
      //   ...el.showInSlider,
      //   categoryId: 1,
      // }));

      // res.push(...filtered);
    });

    return res.sort((a, b) => b.countDownload - a.countDownload);
  }, [data]);

  return (
    <HomeSliderView
      items={renderData}
      isVerticalOrientation={isVerticalOrientation}
      onSelect={onSelect}
    />
  );
};

export default HomeSliderContainer;
