import {
  Dimensions,
  Platform,
  TouchableNativeFeedback,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
  Text,
} from 'react-native';
import React, {useMemo, useState} from 'react';

import {FastImage} from '@/components';

// import FastImage from 'react-native-fast-image';

import {
  StyledContainer,
  StyledImage,
  StyledImageContainer,
} from './home-slider-styled';

import {margin, padding} from '@theme/spacing';

import {CARD_BASE_SIZE} from './home-slider-constant';
import Carousel from 'react-native-snap-carousel';
// import FastImage from 'react-native-fast-image';
import {TABLET_SIDEBAR_WIDTH} from '@/constants';
import {isTablet} from '@/helpers';

const HomeSliderView = ({items, isVerticalOrientation, styled, onSelect}) => {
  // const [containerSize, setContainerSize] = useState(0);

  const offset = useMemo(() => {
    return isTablet && !isVerticalOrientation ? TABLET_SIDEBAR_WIDTH : 0;
  }, [isVerticalOrientation]);

  const cardSize = useMemo(() => {
    const size = CARD_BASE_SIZE;
    const proportion =
      (Dimensions.get('window').width - offset - margin.large * 2) /
      size.width /
      (isTablet ? 2 : 1);

    return {
      width: Math.floor(size.width * proportion),
      height: Math.floor(size.height * proportion),
    };
  }, [isVerticalOrientation]);

  const _renderItem = ({item}) => (
    <TouchableWithoutFeedback onPress={() => onSelect(item)}>
      <StyledImageContainer>
        <StyledImage as={FastImage} source={{uri: item.image}} {...cardSize} />
      </StyledImageContainer>
    </TouchableWithoutFeedback>
  );

  return (
    // <StyledContainer
    // // onLayout={event => {
    // //   setContainerSize(event.nativeEvent.layout.width);
    // // }}
    // >
    // {/* <Text>{JSON.stringify(items)}</Text> */}
    <Carousel
      data={items}
      renderItem={_renderItem}
      sliderWidth={Dimensions.get('window').width - offset}
      itemWidth={cardSize.width}
      firstItem={isTablet ? 1 : 0}
      contentContainerStyle={styled}
      inactiveSlideOpacity={isTablet ? 1 : 0.8}
      inactiveSlideScale={isTablet ? 0.82 : 0.9}
    />
    // </StyledContainer>
  );
};

export default HomeSliderView;
