export {default} from './home-slider-container';
