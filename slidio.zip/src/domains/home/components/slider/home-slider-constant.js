import {isTable} from '@/helpers';

export const CARD_BASE_SIZE = isTable
  ? {
      width: 455,
      height: 234,
    }
  : {
      width: 327,
      height: 168,
    };
