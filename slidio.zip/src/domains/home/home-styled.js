import {margin, padding} from '@theme/spacing';

import {isTablet} from '@/helpers';
import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  position: relative;
  flex: 1;

  background-color: #f6f3f1;
`;

export const StyledSearch = styled.View`
  padding: 0px ${padding.large}px 0px;
`;

export const StyledSlider = styled.View`
  padding-top: ${padding.large}px;
`;

export const StyledBody = styled.ScrollView.attrs({
  contentContainerStyle: {
    flexGrow: 1,
    paddingBottom: padding.big,
    paddingTop: isTablet ? padding.small : 0,
  },
})`
  flex: 1;
`;

export const StyledKeyboardWatch = styled.View`
  flex: 1;

  justify-content: center;
`;

export const StyledTitle = styled.Text`
  margin-bottom: ${margin.large}px;
  padding: 0px ${isTablet ? padding.big + padding.base : padding.large}px;

  font-size: 14px;
  color: #909396;
`;

// margin - left: 239px;
