import {Header, Search} from '@/components';
import {
  StyledBody,
  StyledContainer,
  StyledKeyboardWatch,
  StyledSearch,
  StyledTitle,
  StyledSlider,
} from './home-styled';
import {margin, padding} from '@theme/spacing';

import Empty from '@/containers/empty';
// import HomeCategories from './components/categories';
import CategoriesGrid from '../caterogies/components/grid';

import HomeSlider from './components/slider';
import KeyboardWatch from '@/containers/KeyboardWatch';
// import * as Animatable from 'react-native-animatable';
import React from 'react';
import {Text} from 'react-native';
import {isTablet} from '@/helpers';
import {useTranslation} from 'react-i18next';

const HomeView = ({
  presetsData,
  renderItems,
  search,
  loading,
  isVerticalOrientation,
  isSubscribe,
  purchases,
  productsToBuy,
  setInputRef,
  onChangeSearch,
  onClearFilter,
  onSelectCategory,
  onSelectCollection,
  onShowDrawer,
}) => {
  const {t} = useTranslation('home');

  return (
    // <PageMenu showMenu={showMenu} onChangeShowMenu={onChangeShowMenu}>
    <StyledContainer>
      <Header
        title={t('text_title')}
        onShowMenu={onShowDrawer}
        paddingHorizontal={
          isTablet
            ? padding.big * (isVerticalOrientation ? 1 : 2)
            : padding.large
        }
        searchComponent={
          isTablet && (
            <Search
              placholder={t('text_home_search')}
              data={search}
              setInputRef={setInputRef}
              onChange={onChangeSearch}
            />
          )
        }
      />

      <StyledBody>
        {!isTablet && (
          <StyledSearch>
            <Search
              placholder={t('text_home_search')}
              data={search}
              setInputRef={setInputRef}
              onChange={onChangeSearch}
            />
          </StyledSearch>
        )}

        {/* <Animatable.View animation="fadeIn"> */}
        {/* onSelectCategory */}
        <StyledSlider
          as={HomeSlider}
          data={presetsData}
          isVerticalOrientation={isVerticalOrientation}
          onSelect={onSelectCollection}
        />
        {/* </Animatable.View> */}

        <StyledKeyboardWatch
          as={KeyboardWatch}
          onlyIOS
          watchShow={search && !presetsData.length}>
          <StyledTitle>{t('text_categories')}</StyledTitle>

          <CategoriesGrid
            data={renderItems}
            // search={search}
            // activeSort={activeSort}
            isSubscribe={isSubscribe}
            products={purchases.products}
            productsToBuy={productsToBuy}
            isVerticalOrientation={isVerticalOrientation}
            onClearFilter={onClearFilter}
          />
        </StyledKeyboardWatch>

        {/* <HomeCategories
            data={presetsData}
            onSelect={onSelectCategory}
            EmptyComponent={
              <Empty
                data={presetsData}
                search={search}
                loading={loading}
                onClearFilter={onClearFilter}
              />
            }
          /> */}
      </StyledBody>
    </StyledContainer>
  );
};

export default HomeView;
