import {
  loadingPresetSelector,
  presetDataSelector,
} from 'src/modules/preset/selectors';

import HomeContainer from './home-container';

import {connect} from 'react-redux';
import {compose, withProps} from 'recompose';

import {fetchPresets} from 'src/modules/preset/actions';
import {saveActiveCategory, changeShowDrawer} from 'src/modules/home/actions';
import {
  isSubscribeSelector,
  prodsSelector,
  purchasesSelector,
} from 'src//modules/iap/selectors';

const mapStateToProps = state => {
  return {
    presetsData: presetDataSelector(state),
    loading: loadingPresetSelector(state),
    // isGettingStart: isGettingStartSelector(state),
    isSubscribe: isSubscribeSelector(state),

    purchases: purchasesSelector(state),
    productsToBuy: prodsSelector(state),
    // isShowModalBeforeSharePreset: isShowModalBeforeSharePresetSelector(state),
    // purchases: purchasesSelector(state),
  };
};

const mapDispatchToProps = {
  saveActiveCategory,
  changeShowDrawer,
};

export default compose(
  withProps(),
  connect(
    mapStateToProps,
    mapDispatchToProps,
  ),
)(HomeContainer);
