import React, {useContext, useEffect, useMemo, useState} from 'react';

import HomeView from './home-view';
import {OrientationContext} from '@/context';
import {useNavigation} from '@react-navigation/native';

import {sortBy} from 'lodash';

const HomeContainer = ({
  presetsData,
  loading,
  purchases,
  productsToBuy,
  isSubscribe,
  saveActiveCategory,
  changeShowDrawer,
}) => {
  const {isVerticalOrientation} = useContext(OrientationContext);
  const navigation = useNavigation();

  const [showMenu, setShowMenu] = useState(false);
  const [search, setSearch] = useState(null);

  // const renderData = useMemo(() => {
  //   if (!presetsData.length || !search) {
  //     return [...presetsData];
  //   }

  //   let res = presetsData.filter((item, index) => {
  //     for (let name of Object.values(item.name)) {
  //       if (name.toLowerCase().indexOf(search.trim().toLowerCase()) !== -1)
  //         return true;
  //     }

  //     let filteredCategory = item.categories.filter(item => {
  //       return (
  //         item.title.toLowerCase().indexOf(search.trim().toLowerCase()) !== -1
  //       );
  //     });

  //     if (filteredCategory.length > 0) {
  //       console.log('filteredCategory', filteredCategory);
  //       console.log('index', index);

  //       presetsData[index].search = search.trim().toLowerCase();

  //       return true;
  //     }

  //     return false;
  //     // return (
  //     //   item.name.en.toLowerCase().indexOf(search.trim().toLowerCase()) !== -1
  //     // );
  //   });

  //   return res;
  // }, [search, presetsData]);

  const renderData = useMemo(() => {
    if (!presetsData.length || !search) {
      return [...presetsData];
    }

    let res = presetsData.filter((item, index) => {
      for (let name of Object.values(item.name)) {
        if (name.toLowerCase().indexOf(search.trim().toLowerCase()) !== -1)
          return true;
      }

      let filteredCategory = item.categories.filter(item => {
        return (
          item.title.toLowerCase().indexOf(search.trim().toLowerCase()) !== -1
        );
      });

      if (filteredCategory.length > 0) {
        presetsData[index].search = search.trim().toLowerCase();

        return true;
      }

      return false;
      // return (
      //   item.name.en.toLowerCase().indexOf(search.trim().toLowerCase()) !== -1
      // );
    });

    return res;
  }, [search, presetsData]);

  const renderItems = useMemo(() => {
    const items = [];

    renderData.forEach(item => {
      items.push(...item.categories);
    });

    return sortBy(items, 'createdAt');
  }, [renderData]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      saveActiveCategory('home');
    });

    return unsubscribe;
  }, [navigation]);

  const handleClearFilter = () => {
    setSearch(null);
  };

  const handlerSelectCategory = data => {
    saveActiveCategory(data.id);

    navigation.navigate('Categories', {data});
  };

  const handlerSelectCollection = data => {
    saveActiveCategory(data.categoryId);

    navigation.navigate('Preset', {data});
  };

  const handlerShowDrawer = () => {
    changeShowDrawer(true);
  };

  return (
    <HomeView
      presetsData={presetsData}
      renderItems={renderItems}
      search={search}
      loading={loading}
      isVerticalOrientation={isVerticalOrientation}
      purchases={purchases}
      isSubscribev={isSubscribe}
      productsToBuy={productsToBuy}
      onClearFilter={handleClearFilter}
      onChangeSearch={setSearch}
      onShowDrawer={handlerShowDrawer}
      onSelectCategory={handlerSelectCategory}
      onSelectCollection={handlerSelectCollection}
    />
  );
};

export default HomeContainer;
