import * as Animatable from 'react-native-animatable';

import {
  StyledContent,
  StyledEllipse,
  StyledFooter,
  StyledItem,
  StyledScrollView,
} from './guide-styled';

import GuideControl from './components/control';
import GuideEllipse from './components/ellipse';
import GuideSlide1 from './components/slide1';
import GuideSlide2 from './components/slide2';
import GuideSlide3 from './components/slide3';
import React from 'react';
import {useSafeArea} from 'react-native-safe-area-context';

const GuideView = ({activeIndex, onPrev, onNext}) => {
  const insets = useSafeArea();

  return (
    <StyledScrollView>
      <StyledContent>
        <StyledEllipse as={Animatable.View} delay={500} animation="zoomIn">
          <GuideEllipse activeIndex={activeIndex} />
        </StyledEllipse>

        <GuideSlide1 active={activeIndex === 0} />

        <StyledItem>
          <GuideSlide2 active={activeIndex === 1} />
        </StyledItem>

        <StyledItem>
          <GuideSlide3 active={activeIndex === 2} />
        </StyledItem>
      </StyledContent>

      <StyledFooter insets={insets}>
        <GuideControl
          activeIndex={activeIndex}
          onPrev={onPrev}
          onNext={onNext}
        />
      </StyledFooter>
    </StyledScrollView>
  );
};

export default GuideView;
