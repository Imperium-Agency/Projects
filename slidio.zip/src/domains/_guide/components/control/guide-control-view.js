import * as Animatable from 'react-native-animatable';

import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';

import {Dots} from '@/components';

import {useTranslation} from 'react-i18next';

import {
  StyledContainer,
  StyledDots,
  StyledButton,
} from './guide-control-styled';

const GuideControlView = ({activeIndex, onNext, onPrev}) => {
  const {t} = useTranslation('gide');

  return (
    <StyledContainer>
      <View>
        {activeIndex > 0 && (
          <Animatable.View animation="fadeInRightBig" duration={300}>
            <TouchableOpacity onPress={onPrev}>
              <StyledButton>{t('text_prev')}</StyledButton>
            </TouchableOpacity>
          </Animatable.View>
        )}
      </View>

      <StyledDots>
        <Dots count={3} activeIndex={activeIndex} />
      </StyledDots>

      <TouchableOpacity onPress={onNext}>
        <StyledButton>{t('text_next')}</StyledButton>
      </TouchableOpacity>
    </StyledContainer>
  );
};

export default GuideControlView;
