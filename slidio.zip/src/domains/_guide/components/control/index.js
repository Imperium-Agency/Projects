export {default} from './guide-control-view';
