import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

export const StyledContainer = styled.View`
  position: relative;
  justify-content: space-between;
  flex-direction: row;
  align-items: center;
  padding: 0px ${padding.large}px;
`;

export const StyledDots = styled.View`
  position: absolute;
  left: 0px;
  right: 0px;
  align-items: center;

  z-index: -1;
`;

export const StyledButton = styled.Text`
  padding: ${padding.base}px;

  font-weight: 500;
  font-size: 17px;
  color: #262f47;

  opacity: ${props => props.opacity || 1};
`;
