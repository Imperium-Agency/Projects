import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

export const StyledContainer = styled.Image`
  height: 1002px;
  width: 1002px;
  border-radius: 501px;
`;
