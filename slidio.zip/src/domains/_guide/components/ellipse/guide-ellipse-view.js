import React, {useState, useEffect} from 'react';
import {Animated} from 'react-native';

import {StyledContainer} from './guide-ellipse-styled';

const GuideEllipseView = ({activeIndex, style}) => {
  const [activeValue] = useState(new Animated.Value(activeIndex));

  useEffect(() => {
    Animated.timing(activeValue, {
      toValue: activeIndex,
      useNativeDriver: false,
    }).start();
  }, [activeIndex]);

  const backgroundColor = activeValue.interpolate({
    inputRange: [0, 1, 2],
    outputRange: ['#E5DBFE', '#FEDEDF', '#CCF2FF'],
  });

  return (
    <StyledContainer as={Animated.View} style={[style, {backgroundColor}]} />
  );
};

export default GuideEllipseView;
