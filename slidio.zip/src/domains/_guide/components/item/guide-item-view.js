import PropTypes from 'prop-types';
import React, {useState, useEffect, useMemo} from 'react';
import {Image, StyleSheet, Text, View, Animated} from 'react-native';

import {
  StyledContainer,
  StyledHeader,
  StyledBody,
  StyledTitle,
  StyledDescription,
} from './guide-item-styled';

import {useSafeArea} from 'react-native-safe-area-context';

import {margin} from '@theme/spacing';

import {ScreenWidth} from '@/helpers';

const IMAGE_BASE_SIZE = {
  height: 458,
  width: 375,
};

const Item = ({title, description, active, HeaderComponent}) => {
  const [activeValue] = useState(new Animated.Value(+active));

  const insets = useSafeArea();

  const headerHeight = useMemo(() => {
    return IMAGE_BASE_SIZE.height * (ScreenWidth / IMAGE_BASE_SIZE.width);
  }, []);

  useEffect(() => {
    Animated.timing(activeValue, {
      toValue: active ? 1 : 0,
      useNativeDriver: false,
      duration: active ? 800 : 400,
    }).start();
  }, [active]);

  return (
    <StyledContainer insets={insets}>
      <StyledHeader height={headerHeight}>{HeaderComponent}</StyledHeader>

      <StyledBody>
        <StyledTitle as={Animated.Text} style={{opacity: activeValue}}>
          {title}
        </StyledTitle>

        <StyledDescription as={Animated.Text} style={{opacity: activeValue}}>
          {description}
        </StyledDescription>
      </StyledBody>
    </StyledContainer>
  );
};

Item.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  active: PropTypes.bool,
};

Item.defaultProps = {
  active: false,
};

export default Item;
