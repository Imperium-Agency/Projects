import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

export const StyledContainer = styled.View`
  flex: 1;
  width: 100%;
  padding-top: ${props => props.insets.top}px;
`;

export const StyledHeader = styled.View`
  width: 100%;
  height: ${props => props.height}px;

  align-items: center;

  justify-content: flex-end;
`;

export const StyledBody = styled.View`
  flex: 1;
  align-items: center;
  justify-content: center;
  margin-bottom: auto;
  padding-horizontal: 39px;

  margin-top: -15%;
`;

export const StyledTitle = styled.Text`
  margin-bottom: ${margin.small}px;

  font-size: 25px;
  font-weight: 600;
  text-align: center;
`;

export const StyledDescription = styled.Text`
  font-size: 17px;
  color: #9497a2;
  text-align: center;
`;
