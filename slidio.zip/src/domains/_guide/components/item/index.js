export {default} from './guide-item-view';
