export {default} from './guide-slide1-view';
