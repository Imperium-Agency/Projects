import * as Animatable from 'react-native-animatable';

import Item from '../item';
import React from 'react';
import {ScreenWidth} from '@/helpers';
import {StyledImage} from './guide-slide1-styled';
import {withTranslation} from 'react-i18next';

class Slide1View extends React.Component {
  imageRef = React.createRef();

  UNSAFE_componentWillUpdate(nextProps, nextState) {
    if (nextProps.active !== this.props.active) {
      if (nextProps.active) {
        this.imageRef.current.animate(
          {
            0: {opacity: 0, translate: [{translateX: 0}]},
            1: {
              opacity: 1,
              translate: [{translateX: 0}],
            },
          },
          500,
        );
      } else {
        this.imageRef.current.animate(
          {
            0: [{translateX: 0}],
            1: {
              transform: [{translateX: -ScreenWidth}],
            },
          },
          500,
        );
      }
    }
  }

  render() {
    const {active, t} = this.props;

    return (
      <Item
        title={t('text_choose_title')}
        description={t('text_choose_description')}
        active={active}
        HeaderComponent={
          <StyledImage
            as={Animatable.Image}
            source={require('./image/image.png')}
            resizeMode="contain"
            ref={this.imageRef}
          />
        }
      />
    );
  }
}

export default withTranslation('gide')(Slide1View);
