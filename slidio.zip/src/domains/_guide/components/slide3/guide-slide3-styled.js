import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

export const StyledContainer = styled.Image`
  height: 100%;
  width: 100%;
  opacity: 0;
`;

export const StyledImage = styled.Image`
  height: 100%;
  width: 100%;
`;
