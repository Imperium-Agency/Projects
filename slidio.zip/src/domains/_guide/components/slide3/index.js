export {default} from './guide-slide3-view';
