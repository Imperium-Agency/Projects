import * as Animatable from 'react-native-animatable';

import {ScreenHeight, ScreenWidth} from '@/helpers';
import {StyledContainer, StyledImage} from './guide-slide3-styled';

import Item from '../item';
import React from 'react';
import {withTranslation} from 'react-i18next';

class Slide1View extends React.Component {
  containerRef = React.createRef();

  UNSAFE_componentWillUpdate(nextProps, nextState) {
    if (nextProps.active !== this.props.active) {
      if (nextProps.active) {
        this.containerRef.current.animate(
          {
            0: {
              opacity: 0,
              transform: [{rotate: '0deg'}, {translateY: 0}],
            },
            1: {
              opacity: 1,
              transform: [{rotate: '0deg'}, {translateY: 0}],
            },
          },
          900,
        );
      } else {
        this.containerRef.current.animate(
          {
            0: {opacity: 1, transform: [{rotate: '0deg'}, {translateY: 0}]},
            1: {
              opacity: 1,
              transform: [{rotate: '-30deg'}, {translateY: -ScreenHeight}],
            },
          },
          900,
        );
      }
    }
  }

  render() {
    const {active, t} = this.props;

    return (
      <Item
        title={t('text_use_title')}
        description={t('text_use_description')}
        active={active}
        HeaderComponent={
          <StyledContainer as={Animatable.View} ref={this.containerRef}>
            <StyledImage
              source={require('./image/image.png')}
              resizeMode="contain"
            />
          </StyledContainer>
        }
      />
    );
  }
}

export default withTranslation('gide')(Slide1View);
