export {default} from './guide-slide2-view';
