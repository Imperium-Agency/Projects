import * as Animatable from 'react-native-animatable';

import {StyledContainer, StyledImage} from './guide-slide2-styled';

import Item from '../item';
import React from 'react';
import {ScreenWidth} from '@/helpers';
import {withTranslation} from 'react-i18next';

class Slide1View extends React.Component {
  imageRef = React.createRef();
  containerRef = React.createRef();

  UNSAFE_componentWillUpdate(nextProps, nextState) {
    if (nextProps.active !== this.props.active) {
      if (nextProps.active) {
        this.imageRef.current.animate(
          {
            0: {opacity: 0, transform: [{rotate: '0deg'}]},
            1: {opacity: 1, transform: [{rotate: '0deg'}]},
          },
          800,
        );

        this.containerRef.current.animate(
          {
            0: {transform: [{translateX: 0}]},
            1: {transform: [{translateX: 0}]},
          },
          900,
        );
      } else {
        this.imageRef.current.animate(
          {
            0: {opacity: 1, transform: [{rotate: '0deg'}]},
            1: {opacity: 1, transform: [{rotate: '-110deg'}]},
          },
          900,
        );

        this.containerRef.current.animate(
          {
            0: {transform: [{translateX: 0}]},
            1: {transform: [{translateX: -ScreenWidth * 2}]},
          },
          900,
        );
      }
    }
  }

  render() {
    const {active, t} = this.props;

    return (
      <Item
        title={t('text_copy_title')}
        description={t('text_copy_description')}
        active={active}
        HeaderComponent={
          <StyledContainer as={Animatable.View} ref={this.containerRef}>
            <StyledImage
              as={Animatable.Image}
              source={require('./image/image.png')}
              resizeMode="contain"
              ref={this.imageRef}
            />
          </StyledContainer>
        }
      />
    );
  }
}

export default withTranslation('gide')(Slide1View);
