import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledScrollView = styled.ScrollView.attrs({
  contentContainerStyle: {
    minHeight: '100%',
    justifyContent: 'flex-end',
  },
})`
  background-color: #fff;
`;

export const StyledContent = styled.View`
  align-items: center;
  justify-content: center;
  position: relative;
`;

export const StyledItem = styled.View`
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
  bottom: 0px;
  justify-content: center;
  align-items: center;
`;

export const StyledEllipse = styled.View`
  position: absolute;
  top: -625px;
`;

export const StyledFooter = styled.View`
  flex: 1;
  justify-content: center;
  margin-top: ${margin.small}px;
  margin-bottom: ${(props) => props.insets.bottom}px;
`;
