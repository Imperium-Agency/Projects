import React, {useState} from 'react';

import GuideView from './guide-view';

import {useNavigation} from '@react-navigation/native';

const GuideContainer = () => {
  const navigation = useNavigation();

  const [activeIndex, setActiveIndex] = useState(0);

  const _handlerNext = () => {
    if (activeIndex <= 1) {
      setActiveIndex(activeIndex + 1);
    } else {
      // navigation.goBack();
      navigation.navigate('Subscription', {firstStart: true});
    }
  };

  const _handlerPrev = () => {
    setActiveIndex(activeIndex - 1);
  };

  return (
    <GuideView
      onPrev={_handlerPrev}
      onNext={_handlerNext}
      activeIndex={activeIndex}
    />
  );
};

export default GuideContainer;
