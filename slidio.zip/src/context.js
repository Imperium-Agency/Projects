import React from 'react';

export const OrientationContext = React.createContext({});
// export const TableContext = React.createContext({});
