import * as Actions from './constants';

export const initState = {
  activeCategory: 'home',

  showDrawer: false,
};

/**
 * Home reducer
 * @param state
 * @param action
 * @returns {*}
 */
function homeReducer(state = initState, action = {}) {
  const {type, payload} = action;

  switch (type) {
    case Actions.SAVE_ACTIVE_CATEGORY:
      return {...state, activeCategory: payload};

    case Actions.CHANGE_ACTIVE_CATEGORY:
      return {...state, showDrawer: payload};

    default:
      return state;
  }
}

export default homeReducer;
