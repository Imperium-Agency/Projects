import {createSelector} from 'reselect';

export const rootHome = state => state.home;

export const activeCategorySelector = createSelector(
  rootHome,
  data => data.activeCategory,
);

export const showDrawerSelector = createSelector(
  rootHome,
  data => data.showDrawer,
);
