import * as Actions from './constants';

/**
 * change active category
 * @returns {{type: string}}
 */
export function saveActiveCategory(payload) {
  return {
    type: Actions.SAVE_ACTIVE_CATEGORY,
    payload: payload,
  };
}

export function changeShowDrawer(payload) {
  return {
    type: Actions.CHANGE_ACTIVE_CATEGORY,
    payload: payload,
  };
}
