import {API_VALIDATE_RECEPT, IS_DEV, PASSWORD} from 'src/config/iap';
import {itemProds, itemSubs} from 'src/config/iap';

import {Platform} from 'react-native';
import RNIap from 'react-native-iap';
import queryString from 'query-string';
import request from 'src/utils/request';

/**
 * Fetch presets
 * @param id : product id
 * @returns {*}
 */
export const getSubscriptions = () => RNIap.getSubscriptions(itemSubs);
export const getProds = () => RNIap.getProducts(itemProds);

export const getAvailablePurchases = () => RNIap.getAvailablePurchases();

export const checkSubscribe = async (subscriptions) => {
  console.log('checkSubscribeSaga', subscriptions);

  if (subscriptions.length == 0) return false;

  for (let item of subscriptions) {
    // const receiptBody = {
    //   'receipt-data': item.transactionReceipt,
    //   password: PASSWORD,
    // };

    const result = await validateReceipt(item.transactionReceipt);

    console.log('status', result.status);

    if (result.status == '0') {
      return true;
    }
  }

  return false;
};

export const validateReceipt = async (purchase) => {
  if (Platform.OS == 'ios') {
    const receiptBody = {
      'receipt-data': purchase.transactionReceipt,
      password: PASSWORD,
    };

    let res = await RNIap.validateReceiptIos(receiptBody, IS_DEV);

    return res.status == '0';
  } else {
    let res = await request.get(API_VALIDATE_RECEPT);

    if (!res && !res.token) return false;

    let transactionReceipt = JSON.parse(purchase.transactionReceipt);

    let validateRes = await RNIap.validateReceiptAndroid(
      transactionReceipt.packageName,
      transactionReceipt.productId,
      transactionReceipt.purchaseToken,
      res.token,
      itemSubs.indexOf(transactionReceipt.productId) != -1,
    );

    return (
      (validateRes.paymentState == 1 || validateRes.paymentState == 2) &&
      validateRes.cancelReason == null
    );
  }
};
// {
//   // try {
//   // let res = await RNIap.getSubscriptions(itemSubs);

//   // console.log(res);

//   return
//   // } catch (err) {
//   //   console.warn(err.code, err.message);
//   // }
// };
