import {createSelector} from 'reselect';

export const rootIap = (state) => state.iap;

// Select iap data
export const dataSelector = createSelector(rootIap, (data) => data.data);

export const subscriptionsSelector = createSelector(
  rootIap,
  (data) => data.subscriptions,
);

export const prodsSelector = createSelector(rootIap, (data) => data.prods);

export const purchasesSelector = createSelector(
  rootIap,
  (data) => data.purchases,
);

export const availablePurchasesSelector = createSelector(rootIap, (data) => {
  return data.availablePurchases;
});

export const processingSelector = createSelector(rootIap, (data) => {
  return data.processing;
});

export const subscribeSelector = createSelector(rootIap, (data) => {
  return {processing: data.processing, susses: data.susses};
});

export const isSubscribeSelector = createSelector(
  rootIap,
  (data) => data.isSubscribe,
);
