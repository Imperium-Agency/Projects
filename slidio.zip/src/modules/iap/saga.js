import * as Actions from './constants';

import {call, put, select, takeEvery, all} from 'redux-saga/effects';
import {
  checkSubscribe,
  getAvailablePurchases,
  getProds,
  getSubscriptions,
  validateReceipt,
} from './service';

import {Platform} from 'react-native';
import {itemSubs} from 'src/config/iap';
import {purchasesSelector} from './selectors';

// import {languageSelector} from '../common/selectors';

/**
 * Fetch data saga
 * @returns {IterableIterator<*>}
 */
function* getSubscriptionsSaga() {
  try {
    const res = yield call(getSubscriptions);

    yield put({type: Actions.GET_SUBSCRIPTIONS_SUCCESS, payload: res});
  } catch (e) {
    yield put({type: Actions.GET_SUBSCRIPTIONS_ERROR, error: e});
  }
}

function* getProdsSaga() {
  try {
    const res = yield call(getProds);

    console.log('res', res);

    yield put({type: Actions.GET_PRODS_SUCCESS, payload: res});
  } catch (e) {
    yield put({type: Actions.GET_PRODS_ERROR, error: e});
  }
}

function* getAvailablePurchasesSaga() {
  try {
    const res = yield call(getAvailablePurchases);

    if (res) {
      let availablePurchases = {
        subscriptions: {},
        products: {},
      };

      try {
        const result = yield all(res.map(item => call(validateReceipt, item)));

        result.forEach((item, index) => {
          // console.log(item.status);
          if (item) {
            const recept = res[index];

            // console.log(recept.productId);
            if (itemSubs.indexOf(recept.productId) !== -1) {
              availablePurchases.subscriptions[recept.productId] = recept;
            } else {
              availablePurchases.products[recept.productId] = recept;
            }
          }
        });

        console.log(availablePurchases);

        yield put({
          type: Actions.GET_AVAILABLE_PURCHASE_SUCCESS,
          payload: availablePurchases,
        });
      } catch (e) {
        console.log(e);

        yield put({type: Actions.GET_AVAILABLE_PURCHASE_ERROR, error: e});
      }
    }
  } catch (e) {
    if (e.code === 'E_USER_CANCELLED') {
      yield put({type: Actions.GET_AVAILABLE_PURCHASE_CANCELLED, error: e});
    } else {
      yield put({type: Actions.GET_AVAILABLE_PURCHASE_ERROR, error: e});
    }
  }
}

function* checkSubscribeSaga() {
  try {
    const purchases = yield select(purchasesSelector);

    const res = yield call(
      checkSubscribe(Object.values(purchases.subscriptions)),
    );

    yield put({type: Actions.CHECK_SUBSCRIBE_SUCCESS, payload: res});
  } catch (e) {
    // yield put({ type: Actions.GET_SUBSCRIPTIONS_ERROR, error: e });
  }
}

export default function* iapSaga() {
  yield takeEvery(Actions.GET_SUBSCRIPTIONS, getSubscriptionsSaga);
  yield takeEvery(Actions.GET_PRODS, getProdsSaga);
  yield takeEvery(Actions.CHECK_SUBSCRIBE, checkSubscribeSaga);
  yield takeEvery(Actions.GET_AVAILABLE_PURCHASE, getAvailablePurchasesSaga);
}
