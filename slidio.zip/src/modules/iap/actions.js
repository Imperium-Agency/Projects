import * as Actions from './constants';

/**
 * Save iap data
 * @returns {{type: string}}
 */
export function savePurchase(payload) {
  return {
    type: Actions.SAVE_PURCHASE,
    payload: payload,
  };
}

export function getSubscriptions() {
  return {
    type: Actions.GET_SUBSCRIPTIONS,
  };
}

export function getProds() {
  return {
    type: Actions.GET_PRODS,
  };
}

export function getAvailablePurchases() {
  return {
    type: Actions.GET_AVAILABLE_PURCHASE,
  };
}

export function cangeAvailablePurchasesSussces(payload) {
  return {
    type: Actions.CANGE_AVAILABLE_PURCHASE_SUSSCES,
    payload,
  };
}

export function changeSubscriptionProcessing(payload) {
  return {
    type: Actions.CHANGE_SUBSCRIPTION_PROCESSING,
    payload,
  };
}

export function changeSubscriptionSussces(payload) {
  return {
    type: Actions.CHANGE_SUBSCRIPTION_SUSSCES,
    payload,
  };
}

export function checkSubscribe() {
  console.log('checkSubscribe');
  return {
    type: Actions.CHECK_SUBSCRIBE,
  };
}
