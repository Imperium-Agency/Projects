import * as Actions from './constants';

import {List, Map, Set, fromJS} from 'immutable';

import {itemSubs} from 'src/config/iap';

// import {REHYDRATE} from 'redux-persist/lib/constants';
// import {DEFAULT_LANGUAGE_CODE} from './constants';

export const initState = {
  processing: false,
  susses: null,
  isSubscribe: false,

  purchases: {
    subscriptions: {},
    products: {},
  },

  availablePurchases: {
    loading: false,
    susses: null,
  },

  subscriptions: {
    loading: false,
    data: [],
  },

  prods: {
    loading: false,
    data: [],
  },
};

/**
 * Common reducer
 * @param state
 * @param action
 * @returns {*}
 */
function iapReducer(state = initState, action = {}) {
  const {type, payload} = action;

  switch (type) {
    case Actions.SAVE_PURCHASE:
      let isSubs = itemSubs.indexOf(payload.productId) != -1;

      return {
        ...state,
        purchases: {
          ...state.purchases,
          [isSubs ? 'subscriptions' : 'products']: {
            ...state.purchases[isSubc ? 'subscriptions' : 'products'],
            [payload.productId]: payload,
          },
        },
        isSubscribe: isSubs || state.isSubscribe,
      };

    case Actions.GET_SUBSCRIPTIONS:
      return {
        ...state,
        subscriptions: {
          ...state.subscriptions,
          loading: true,
        },
      };
    case Actions.GET_SUBSCRIPTIONS_SUCCESS:
      return {
        ...state,
        subscriptions: {
          ...state.subscriptions,
          ...{loading: false, data: payload},
        },
      };
    case Actions.GET_SUBSCRIPTIONS_ERROR:
      return {
        ...state,
        subscriptions: {
          ...state.subscriptions,
          loading: false,
        },
      };

    case Actions.GET_PRODS:
      console.log('Actions.GET_PRODS:');

      return {
        ...state,
        prods: {
          ...state.GET_PRODS,
          loading: true,
        },
      };
    case Actions.GET_PRODS_SUCCESS:
      return {
        ...state,
        prods: {
          ...state.prods,
          ...{loading: false, data: payload},
        },
      };
    case Actions.GET_PRODS_ERROR:
      return {
        ...state,
        prods: {
          ...state.prods,
          loading: false,
        },
      };

    case Actions.GET_AVAILABLE_PURCHASE:
      return {
        ...state,
        availablePurchases: {
          ...state.availablePurchases,
          ...{loading: true, susses: null},
        },
      };
    case Actions.GET_AVAILABLE_PURCHASE_SUCCESS:
      console.log('GET_AVAILABLE_PURCHASE_SUCCESS');
      return {
        ...state,
        availablePurchases: {
          ...state.availablePurchases,
          ...{loading: false, susses: true},
        },
        isSubscribe: !!Object.values(payload.subscriptions).length,
        purchases: {
          ...state.purchases,
          ...{subscriptions: payload.subscriptions, products: payload.products},
        },
      };
    case Actions.GET_AVAILABLE_PURCHASE_ERROR:
      console.log('GET_AVAILABLE_PURCHASE_ERROR');
      return {
        ...state,
        availablePurchases: {
          ...state.availablePurchases,
          ...{loading: false, susses: false},
        },
      };
    case Actions.GET_AVAILABLE_PURCHASE_CANCELLED:
      return {
        ...state,
        availablePurchases: {
          ...state.availablePurchases,
          ...{loading: false, susses: null},
        },
      };
    case Actions.CANGE_AVAILABLE_PURCHASE_SUSSCES:
      return {
        ...state,
        availablePurchases: {
          ...state.availablePurchases,
          susses: payload,
        },
      };

    case Actions.CHANGE_SUBSCRIPTION_PROCESSING:
      return {...state, processing: payload};
    case Actions.CHANGE_SUBSCRIPTION_SUSSCES:
      return {...state, susses: payload};

    case Actions.CHECK_SUBSCRIBE:
      return state;
    case Actions.CHECK_SUBSCRIBE_SUCCESS:
      return {...state, isSubscribe: payload};

    default:
      return state;
  }
}

export default iapReducer;
