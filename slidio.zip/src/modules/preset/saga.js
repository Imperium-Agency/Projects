import {put, call, takeEvery, select} from 'redux-saga/effects';
import * as Actions from './constants';

import {getPresets} from './service';
// import {languageSelector} from '../common/selectors';

/**
 * Fetch data saga
 * @returns {IterableIterator<*>}
 */
function* fetchPresetsSaga() {
  try {
    const res = yield call(getPresets);

    yield put({type: Actions.GET_PRESETS_SUCCESS, payload: res.data});
  } catch (e) {
    // console.log(e);
    yield put({type: Actions.GET_PRESETS_ERROR});
  }
}

export default function* categorySaga() {
  yield takeEvery(Actions.GET_PRESETS, fetchPresetsSaga);
}
