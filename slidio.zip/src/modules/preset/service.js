import queryString from 'query-string';
import request from 'src/utils/request';

/**
 * Fetch presets
 * @param id : product id
 * @returns {*}
 */
export const getPresets = () => request.get(`/get/collection/all`);
