import * as Actions from './constants';

/**
 * Fetch presets
 * @param data
 * @returns {{type: string, payload: {data: array}}}
 */
export function fetchPresets() {
  return {
    type: Actions.GET_PRESETS,
  };
}
