import * as Actions from './constants';

import {Set, fromJS} from 'immutable';

const initState = {
  data: [],
  isLoaging: false,
};

/**
 * Common reducer
 * @param state
 * @param action
 * @returns {*}
 */
function presetReducer(state = initState, action = {}) {
  const {type, payload} = action;
  switch (type) {
    case Actions.GET_PRESETS:
      return {...state, loading: true};
    case Actions.GET_PRESETS_SUCCESS:
      return {...state, ...{loading: false, data: payload}};
    case Actions.GET_PRESETS_ERROR:
      return {...state, loading: false};
    case 'UPDATE_DEMO_CONFIG_SUCCESS':
      return initState;
    default:
      return state;
  }
}

export default presetReducer;
