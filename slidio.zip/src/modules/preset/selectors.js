import {createSelector} from 'reselect';

export const preset = state => state.preset;

export const loadingPresetSelector = createSelector(
  preset,
  data => data.loading,
);

export const presetDataSelector = createSelector(
  preset,
  data => data.data.filter(group => group.categories.length > 0),
);
