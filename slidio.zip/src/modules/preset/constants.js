export const GET_PRESETS = 'preset/GET_PRESETS';
export const GET_PRESETS_SUCCESS = 'preset/GET_PRESETS_SUCCESS';
export const GET_PRESETS_ERROR = 'preset/GET_PRESETS_ERROR';
