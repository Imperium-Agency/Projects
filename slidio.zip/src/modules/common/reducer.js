import * as Actions from './constants';

import {deviceLanguage} from '@/helpers';

export const initState = {
  defaultLanguage: Actions.DEFAULT_LANGUAGE_CODE,
  language: deviceLanguage,
  languages: ['ru', 'de', 'fr', 'es', 'it', 'en'],

  isGettingStarted: true,
  isShowModalBeforeSharePreset: true,
};

/**
 * Common reducer
 * @param state
 * @param action
 * @returns {*}
 */
function commonReducer(state = initState, action = {}) {
  const {type, payload} = action;
  switch (type) {
    case Actions.CHANGE_LANGUAGE:
      return {...state, language: payload};

    // Close getting started
    case Actions.CLOSE_GETTING_STARTED:
      return {...state, isGettingStarted: false};

    case Actions.CANGE_IS_SHOW_MODAL_BEFORE_SHARE_PRESET:
      return {...state, isShowModalBeforeSharePreset: payload};

    default:
      return state;
  }
}

export default commonReducer;
