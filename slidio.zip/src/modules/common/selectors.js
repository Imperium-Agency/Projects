import {createSelector} from 'reselect';
import * as Actions from './constants';

export const rootCommon = state => state.common;

export const isGettingStartSelector = createSelector(
  rootCommon,
  data => data.isGettingStarted,
);

export const isShowModalBeforeSharePresetSelector = createSelector(
  rootCommon,
  data => data.isShowModalBeforeSharePreset,
);

// Select active language
export const languageSelector = createSelector(
  rootCommon,
  data => data.language || Actions.DEFAULT_LANGUAGE_CODE,
);

// Select active language
export const defaultLanguageSelector = createSelector(
  rootCommon,
  data => data.defaultLanguage || Actions.DEFAULT_LANGUAGE_CODE,
);

// Select list languages
export const listLanguageSelector = createSelector(
  rootCommon,
  data => data.languages,
);
