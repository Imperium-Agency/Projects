import * as Actions from './constants';

/**
 * Action change language
 * @param code
 * @returns {{type: string, payload: string}}
 */
export function changeLanguage(code: string) {
  return {
    type: Actions.CHANGE_LANGUAGE,
    payload: code,
  };
}

/**
 * Close Getting Stated
 * @returns {{type: string}}
 */
export function closeGettingStarted() {
  return {
    type: Actions.CLOSE_GETTING_STARTED,
  };
}

/**
 * Close Getting Stated
 * @returns {{type: string}}
 */
export function changeIsShowModalBeforeSharePreset(payload) {
  return {
    type: Actions.CANGE_IS_SHOW_MODAL_BEFORE_SHARE_PRESET,
    payload,
  };
}
