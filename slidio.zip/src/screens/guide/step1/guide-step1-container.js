import React from 'react';
import {View, Text} from 'react-native';

import GuideStep1View from './guide-step1-view';

import {useNavigation} from '@react-navigation/native';

const GuideStep1Container = props => {
  const navigation = useNavigation();

  const handlerNext = () => {
    navigation.navigate('GuideStep2');
  };

  return <GuideStep1View {...props} onNext={handlerNext} />;
};

export default GuideStep1Container;
