import {Image, Text, View} from 'react-native';

import Guide from '@/domains/guide';
import {Modal} from '@/components';
import React from 'react';
import {useTranslation} from 'react-i18next';

const GuideStep1View = ({onNext}) => {
  const {t} = useTranslation('gide');

  return (
    <Modal background="#F6F3F1">
      <Guide
        title={t('text_step1_title')}
        description={t('text_step1_description')}
        source={require('./images/image.png')}
        index={0}
        onNext={onNext}
      />
    </Modal>
  );
};

export default GuideStep1View;
