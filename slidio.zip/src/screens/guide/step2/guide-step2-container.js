import {Text, View} from 'react-native';

import GuideStep2View from './guide-step2-view';
import React from 'react';
import {useNavigation} from '@react-navigation/native';

const GuideStep2Container = (props) => {
  const navigation = useNavigation();

  const handlerNext = () => {
    navigation.navigate('Subscription', {firstStart: true});
  };

  return <GuideStep2View {...props} onNext={handlerNext} />;
};

export default GuideStep2Container;
