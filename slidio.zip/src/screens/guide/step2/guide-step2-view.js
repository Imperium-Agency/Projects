import {Image, Platform, Text, View} from 'react-native';

import Guide from '@/domains/guide';
import {Modal} from '@/components';
import React from 'react';
import {useTranslation} from 'react-i18next';

const GuideStep2View = ({onNext}) => {
  const {t} = useTranslation('gide');

  return (
    <Modal background="#F5854F" offset={Platform.OS == 'ios' ? 54 : 44}>
      <Guide
        painted
        title={t('text_step2_title')}
        description={t('text_step2_description')}
        source={require('./images/image.png')}
        index={1}
        onNext={onNext}
      />
    </Modal>
  );
};

export default GuideStep2View;
