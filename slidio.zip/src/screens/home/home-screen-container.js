import React, {useEffect, useMemo} from 'react';

import HomeScreenView from './home-screen-view';
import find from 'lodash/find';
import {useNavigation} from '@react-navigation/native';

const HomeScreenContainer = ({
  showDrawer,
  presetsData,
  activeCategory,
  isSubscribe,
  fetchPresets,
  saveActiveCategory,
  changeShowDrawer,
}) => {
  const navigation = useNavigation();

  const categories = useMemo(() => {
    const res = [{value: 'home', lable: 'Home'}];

    presetsData.forEach((item, index) => {
      res.push({value: item.id, lable: `${item.name.en}`});
    });

    return res;
  }, [presetsData]);

  useEffect(() => {
    fetchPresets();

    if (!isSubscribe) {
      navigation.navigate('GuideStep1');
    }
  }, [fetchPresets]);

  const handlerSelectCategory = value => {
    const data = find(presetsData, ['id', value]);
    saveActiveCategory(value);

    if (value === 'home') {
      navigation.navigate('Folders');
    } else {
      navigation.navigate('Categories', {data});
    }
  };

  const handlerChangeShowDrawer = value => {
    changeShowDrawer(value);
  };

  return (
    <HomeScreenView
      categories={categories}
      showDrawer={showDrawer}
      selectedCategory={activeCategory}
      onSelectCategory={handlerSelectCategory}
      onChangeShowDrawer={handlerChangeShowDrawer}
    />
  );
};

export default HomeScreenContainer;
