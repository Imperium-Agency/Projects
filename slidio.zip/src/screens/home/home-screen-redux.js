import HomeScreenContainer from './home-screen-container';

import {connect} from 'react-redux';
import {compose, withProps} from 'recompose';

import {presetDataSelector} from 'src/modules/preset/selectors';

import {fetchPresets} from 'src/modules/preset/actions';
import {saveActiveCategory, changeShowDrawer} from 'src/modules/home/actions';
import {isSubscribeSelector} from 'src/modules/iap/selectors';
import {
  activeCategorySelector,
  showDrawerSelector,
} from 'src/modules/home/selectors';

const mapStateToProps = state => {
  return {
    presetsData: presetDataSelector(state),
    isSubscribe: isSubscribeSelector(state),
    activeCategory: activeCategorySelector(state),
    showDrawer: showDrawerSelector(state),
  };
};

const mapDispatchToProps = {
  fetchPresets,
  saveActiveCategory,
  changeShowDrawer,
};

export default compose(
  withProps(),
  connect(
    mapStateToProps,
    mapDispatchToProps,
  ),
)(HomeScreenContainer);
