import React from 'react';
import {View, Text} from 'react-native';

import HomeStack from '@/navigation/HomeStack';

import {PageMenu} from '@/components';

const HomeScreenView = ({
  categories,
  selectedCategory,
  showDrawer,
  onSelectCategory,
  onChangeShowDrawer,
}) => {
  return (
    <PageMenu
      items={categories}
      title="Categories"
      activedItem={selectedCategory}
      showDrawer={showDrawer}
      onSelect={onSelectCategory}
      onChangeShowDrawer={onChangeShowDrawer}>
      <HomeStack />
    </PageMenu>
  );
};

export default HomeScreenView;
