import de from './de';
import en from './en';
import es from './es';
import fr from './fr';
import it from './it';
import ru from './ru';

export default {
  de,
  en,
  ru,
  fr,
  es,
  it,
};
