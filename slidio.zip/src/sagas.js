import {all} from 'redux-saga/effects';
import iapSaga from './modules/iap/saga';
import presetSaga from './modules/preset/saga';

/**
 * Root saga
 * @returns {IterableIterator<AllEffect | GenericAllEffect<any> | *>}
 */
export default function* rootSagas() {
  yield all([presetSaga(), iapSaga()]);
}
