import {Image, StyleSheet, Text, View} from 'react-native';

import {Button} from 'src/components';
// @flow
import React from 'react';
import {withTranslation} from 'react-i18next';

// import Button from './Button';
// import {padding, margin} from 'src/components/config/spacing';

type Props = {
  icon: string,
  titleButton?: string,
  clickButton?: void => {},
  title: string,
  subTitle: string,
  avatarProps?: object,
};

const Empty = (props: Props) => {
  const {titleButton, clickButton, buttonProps, title, subTitle, t} = props;

  const buttonStyle =
    buttonProps && buttonProps.buttonStyle ? buttonProps.buttonStyle : {};
  const containerStyle =
    buttonProps && buttonProps.containerStyle ? buttonProps.containerStyle : {};

  return (
    <View style={styles.container}>
      {/* <Image
        source={require('../assets/images/logo.png')}
        style={{height: 120}}
        resizeMode="contain"
      /> */}

      <Text style={styles.textTitle}>{title}</Text>
      <Text style={styles.textSubtitle}>{subTitle}</Text>
      {titleButton && (
        <Button
          type="outline"
          {...buttonProps}
          title={titleButton}
          onPress={clickButton}
          style={[styles.button, buttonStyle && buttonStyle]}
          styleContainer={[
            styles.containerButton,
            containerStyle && containerStyle,
          ]}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  box: {
    marginBottom: 30,
  },
  textTitle: {
    marginBottom: 12,
    textAlign: 'center',
    fontSize: 24,
    fontWeight: '600',
  },
  textSubtitle: {
    marginBottom: 20,
    textAlign: 'center',
    color: '#383838',
  },
  containerButton: {
    minWidth: 160,
  },
  button: {
    paddingHorizontal: 30,
  },
});

Empty.defaultProps = {};

export default withTranslation()(Empty);
