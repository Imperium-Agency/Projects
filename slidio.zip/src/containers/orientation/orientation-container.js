import React, {useState, useEffect, useCallback} from 'react';
import {Dimensions} from 'react-native';

import {OrientationContext} from '@/context';

import {ScreenWidth, ScreenHeight} from '@/helpers';

const OrientationContainer = ({children}) => {
  const [isVertical, setIsVertical] = useState(true);

  useEffect(() => {
    _getIsVertical(Dimensions.get('window'));

    Dimensions.addEventListener('change', _handlerChangeDimensions);

    return () => {
      Dimensions.removeEventListener('change', _handlerChangeDimensions);
    };
  }, []);

  const _handlerChangeDimensions = useCallback(e => {
    _getIsVertical(e.window);
  }, []);

  const _getIsVertical = size => {
    const maxValue = ScreenHeight > ScreenWidth ? ScreenHeight : ScreenWidth;

    setIsVertical(size.width !== maxValue);
  };

  return (
    <OrientationContext.Provider
      value={{
        orientation: isVertical ? 'vertical' : 'horizoltal',
        isVerticalOrientation: isVertical,
      }}>
      {children}
    </OrientationContext.Provider>
  );
};

export default OrientationContainer;
