import * as Animatable from 'react-native-animatable';

import {ActivityIndicator, View} from 'react-native';

import {Empty} from 'src/components';
import React from 'react';
import {StyledContainer} from './empty-styled';
import {useTranslation} from 'react-i18next';

const EmptyView = ({data, search, activeSort, loading, onClearFilter}) => {
  const {t} = useTranslation();

  return (
    <StyledContainer>
      {!!loading && !data.length ? (
        <ActivityIndicator size="large" />
      ) : (
        <Animatable.View animation="tada" useNativeDriver={true}>
          {!!((search || activeSort) && !data.length) ? (
            <Empty
              title={t('empty:text_title_preset_filter')}
              subTitle={t('empty:text_description_preset_filter')}
              titleButton={t('empty:text_button_preset_filter')}
              clickButton={onClearFilter}
            />
          ) : (
            <Empty
              title={t('empty:text_title_preset')}
              subTitle={t('empty:text_description_preset')}
            />
          )}
        </Animatable.View>
      )}
    </StyledContainer>
  );
};

export default EmptyView;
