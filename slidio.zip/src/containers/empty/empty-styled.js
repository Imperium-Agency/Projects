import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  flex: 1;

  justify-content: center;
`;
