import {Alert, AsyncStorage} from 'react-native';
import {NativeEventEmitter, NativeModules, Platform} from 'react-native';
import RNIap, {
  InAppPurchase,
  PurchaseError,
  SubscriptionPurchase,
  finishTransaction,
  finishTransactionIOS,
  initConnection,
  purchaseErrorListener,
  purchaseUpdatedListener,
} from 'react-native-iap';
import React, {useEffect, useState} from 'react';
import {
  availablePurchasesSelector,
  processingSelector,
} from 'src/modules/iap/selectors';
import {
  cangeAvailablePurchasesSussces,
  changeSubscriptionProcessing,
  checkSubscribe,
  getProds,
  getSubscriptions,
  savePurchase,
} from 'src/modules/iap/actions';

import {Spinner} from '@/components';
import {connect} from 'react-redux';
import {useTranslation} from 'react-i18next';
import {validateReceipt} from 'src/modules/iap/service';

const {RNIapIos} = NativeModules;
const IAPEmitter = new NativeEventEmitter(RNIapIos);

// import {dataSelector} from 'src/modules/iap/selectors';

export const IAPManagerWrapped = ({
  children,
  processing,
  availablePurchases,
  savePurchase,
  getProds,
  getSubscriptions,
  checkSubscribe,
  cangeAvailablePurchasesSussces,
  changeSubscriptionProcessing,
}) => {
  const {t} = useTranslation('subscription');

  // const [processing, setProcessing] = useState(false);

  // let purchaseUpdateSubscription = null;
  // let purchaseErrorSubscription = null;

  const checkReceipt = async (purchase) => {
    console.log('checkReceipt');

    const result = await validateReceipt(purchase);

    console.log('checkReceipt', result);

    if (result) {
      savePurchase(purchase);

      await finishTransaction(purchase);
    }

    changeSubscriptionProcessing(false);
  };

  useEffect(() => {
    console.log('availablePurchases.susses', availablePurchases.susses);

    if (availablePurchases.susses !== null) {
      Alert.alert(
        '',
        availablePurchases.susses
          ? t('text_available_purchases_susses')
          : t('text_available_purchases_error'),
        [
          {
            text: 'Ok',
            onPress: () => {
              cangeAvailablePurchasesSussces(null);
            },
          },
        ],
        // {cancelable: false},
      );
    }
  }, [availablePurchases.susses]);

  useEffect(() => {
    let purchaseUpdateSubscription = purchaseUpdatedListener(
      async (
        purchase: InAppPurchase | SubscriptionPurchase | ProductPurchase,
      ) => {
        const receipt = purchase.transactionReceipt;
        if (receipt) {
          console.log('receipt', receipt);

          try {
            //
            checkReceipt(purchase);
          } catch (ackErr) {
            changeSubscriptionProcessing(false);

            console.log('ackErr', ackErr);
          }
        }
      },
    );

    let purchaseErrorSubscription = purchaseErrorListener(
      (error: PurchaseError) => {
        console.log('purchaseErrorListener', error);

        // Alert.alert(error.message);
      },
    );

    if (Platform.OS === 'ios')
      IAPEmitter.addListener('iap-promoted-product', async () => {
        // Check if there's a persisted promoted product
        const productId = await RNIap.getPromotedProductIOS();
        if (productId !== null) {
          // You may want to validate the product ID against your own SKUs
          try {
            await RNIap.buyPromotedProductIOS(); // This will trigger the App Store purchase process
          } catch (error) {
            console.warn(error);
          }
        }
      });

    getSubscriptions();

    getProds();

    checkSubscribe();

    return () => {
      if (purchaseUpdateSubscription) {
        purchaseUpdateSubscription.remove();
        purchaseUpdateSubscription = null;
      }
      if (purchaseErrorSubscription) {
        purchaseErrorSubscription.remove();
        purchaseErrorSubscription = null;
      }
    };
  }, []);

  return (
    <>
      <Spinner
        visible={availablePurchases.loading || processing}
        textContent={t(
          availablePurchases.loading
            ? 'text_available_purchases_loading'
            : 'text_subscription_loading',
        )}
      />
      {children}
    </>
  );
};

const mapStateToProps = (state) => ({
  availablePurchases: availablePurchasesSelector(state),
  processing: processingSelector(state),
});

const mapDispatchToProps = {
  savePurchase: savePurchase,
  getSubscriptions: getSubscriptions,
  getProds: getProds,
  checkSubscribe: checkSubscribe,
  cangeAvailablePurchasesSussces: cangeAvailablePurchasesSussces,
  changeSubscriptionProcessing: changeSubscriptionProcessing,
};

export default connect(mapStateToProps, mapDispatchToProps)(IAPManagerWrapped);
