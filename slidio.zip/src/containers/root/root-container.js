import React, {useLayoutEffect} from 'react';

import RootView from './root-view';

import {useTranslation} from 'react-i18next';

const RootContainer = ({language, children}) => {
  const {t, i18n} = useTranslation();

  useLayoutEffect(() => {
    i18n.changeLanguage(language);
  }, [language, i18n]);

  return <RootView children={children} />;
};

export default RootContainer;
