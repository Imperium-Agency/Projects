import React from 'react';
import {View, Text, StatusBar} from 'react-native';

import {StyledContainer} from './root-styled';

const RootView = ({children}) => {
  return (
    <StyledContainer>
      <StatusBar barStyle="dark-content" />

      {children}
    </StyledContainer>
  );
};

export default RootView;
