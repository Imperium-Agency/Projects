import RootContainer from './root-container';

import {withProps} from 'recompose';
import {connect} from 'react-redux';
import {compose} from 'redux';

import {languageSelector} from '@/modules/common/selectors';

const mapStateToProps = state => {
  return {
    language: languageSelector(state),
  };
};

export default compose(
  withProps(),
  connect(mapStateToProps),
)(RootContainer);
