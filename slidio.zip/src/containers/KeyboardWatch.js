import * as Animatable from 'react-native-animatable';

import {Animated, Keyboard, StyleSheet, View, Platform} from 'react-native';
import React, {createRef, useContext, useEffect, useState} from 'react';

import {getBottomSpace} from 'react-native-iphone-x-helper';

const KeyboardWatch = ({children, style, onlyIOS, watchShow}) => {
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const [currentKeyboardHeight, setCurrentKeyboardHeight] = useState(null);

  const contentRef = createRef();

  useEffect(() => {
    if (Platform.OS !== 'ios' && onlyIOS) return;

    let keyboardWillShowListener = Keyboard.addListener(
      'keyboardWillShow',
      event => {
        console.log('keyboardWillShow');

        setCurrentKeyboardHeight(event.endCoordinates.height);
      },
    );
    let keyboardWillHideListener = Keyboard.addListener(
      'keyboardWillHide',
      () => {
        console.log('keyboardDidHide');
        setCurrentKeyboardHeight(0);
      },
    );

    return () => {
      // keyboardWillShowListener.remove();
      keyboardWillHideListener.remove();
      keyboardWillShowListener.remove();
    };
  }, []);

  useEffect(() => {
    if (currentKeyboardHeight !== null) {
      handleAnimale();
    }
  }, [currentKeyboardHeight]);

  const handleAnimale = () => {
    console.log('currentKeyboardHeight', currentKeyboardHeight);
    if (currentKeyboardHeight != 0) {
      setKeyboardHeight(currentKeyboardHeight);
      contentRef.current.animate(
        {
          0: {
            marginBottom: 0,
          },
          1: {
            marginBottom: currentKeyboardHeight - getBottomSpace() + 15,
          },
        },
        300,
      );
    } else {
      contentRef.current.animate(
        {
          0: {
            marginBottom: keyboardHeight - getBottomSpace() + 15,
          },
          1: {
            marginBottom: 0,
          },
        },
        300,
      );
    }
  };

  return (
    <Animatable.View style={[style, styles.container]} ref={contentRef}>
      {children}
    </Animatable.View>
  );
};

export default KeyboardWatch;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
