import {
  Animated,
  Dimensions,
  Keyboard,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  UIManager,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';

// import {ScreenOrientation} from 'expo';

const {State: TextInputState} = TextInput;

const ProfileHeaderFrom = ({
  children,
  topPaidding = 30,
  duration = 250,
  onlyIOS = false,
  style = {},
}) => {
  const [shift, setShift] = useState(new Animated.Value(0));

  const [keyboardDidShowSub, setKeyboardDidShowSub] = useState(
    new Animated.Value(null),
  );
  const [keyboardDidHideSub, setKeyboardDidHideSub] = useState(
    new Animated.Value(null),
  );

  const handleKeyboardDidShow = event => {
    // ScreenOrientation.getOrientationLockAsync().then(value => {
    //   if (value == 'DEFAULT') return;
    // dd
    const {height: windowHeight} = Dimensions.get('window');
    const keyboardHeight = event.endCoordinates.height;
    const currentlyFocusedField = TextInputState.currentlyFocusedField();
    if (currentlyFocusedField)
      UIManager.measure(
        currentlyFocusedField,
        (originX, originY, width, height, pageX, pageY) => {
          const fieldHeight = height;
          const fieldTop = pageY;
          const gap = windowHeight - keyboardHeight - (fieldTop + fieldHeight);
          if (gap >= 0) {
            return;
          }
          Animated.timing(shift, {
            toValue: gap - topPaidding,
            duration,
            useNativeDriver: true,
          }).start();
        },
      );
    // });
  };

  const handleKeyboardDidHide = () => {
    Animated.timing(shift, {
      toValue: 0,
      duration,
      useNativeDriver: true,
    }).start();
  };

  useEffect(() => {
    // if (Platform.OS !== 'ios') return;
    if (Platform.OS !== 'ios' && onlyIOS) return;

    let keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      handleKeyboardDidShow,
    );
    let keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      handleKeyboardDidHide,
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  // useEffect(() => {
  //   try {
  //     setKeyboardDidShowSub();
  //     Keyboard.addListener("keyboardDidShow", handleKeyboardDidShow);
  //     setKeyboardDidHideSub();
  //     Keyboard.addListener("keyboardDidHide", handleKeyboardDidHide);
  //   } catch (e) {
  //     console.log(e);
  //   }

  //   return () => {
  //     keyboardDidShowSub.remove();
  //     keyboardDidHideSub.remove();
  //   };
  // }, []);

  return (
    <Animated.View
      style={[styles.container, {transform: [{translateY: shift}]}, style]}>
      {children}
    </Animated.View>
  );
};

export default ProfileHeaderFrom;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // minHeight: 400,
    width: '100%',
  },
});
