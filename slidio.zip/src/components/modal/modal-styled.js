import {margin, padding} from '@theme/spacing';

import {Platform} from 'react-native';
import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  flex: 1;
  margin-top: ${(props) => props.insets.top + 7 + (props.offset || 0)}px;
  background: ${(props) => props.background || '#F6F3F1'};
  border-top-left-radius: 32px;
  border-top-right-radius: 32px;
  box-shadow: 0px -10px 30px rgba(0, 0, 0, 0.08);
`;

export const StyledIndicator = styled.View`
  margin: ${margin.small}px auto;
  width: 53px;
  height: 5px;

  background: #cecece;
  opacity: 0.64;
  border-radius: 14px;
`;
