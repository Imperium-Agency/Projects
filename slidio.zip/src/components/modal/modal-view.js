import PropTypes from 'prop-types';

import {StyledContainer, StyledIndicator} from './modal-styled';
import {Text, View} from 'react-native';

import React from 'react';
import {useSafeArea} from 'react-native-safe-area-context';

const ModalView = ({children, background, offset}) => {
  const insets = useSafeArea();

  console.log('insets', insets);

  return (
    <StyledContainer background={background} offset={offset} insets={insets}>
      <StyledIndicator />

      {children}
    </StyledContainer>
  );
};

ModalView.propTypes = {
  offset: PropTypes.number,
};

ModalView.defaultProps = {
  offset: 0,
};

export default ModalView;
