import {
  StyledContainer,
  StyledFooter,
  StyledIcon,
  StyledIconBack,
  StyledSearch,
  StyledTitle,
  StyledTopline,
} from './header-styled';
import {Text, View} from 'react-native';
import {margin, padding} from '@theme/spacing';

import Icon from '@/components/icon';
import PropTypes from 'prop-types';
import React from 'react';
import {isTablet} from '@/helpers';
import {useSafeArea} from 'react-native-safe-area-context';

const HeaderView = ({
  title,
  withBack = false,
  isVerticalOrientation,
  paddingBottom,
  paddingHorizontal,
  searchComponent,
  footerComponent,
  onShowMenu,
  onBack,
  onShare,
}) => {
  const insets = useSafeArea();

  return (
    <StyledContainer
      insets={insets}
      paddingHorizontal={paddingHorizontal}
      paddingTop={isTablet ? padding.large : padding.small}
      paddingBottom={paddingBottom}>
      <StyledTopline>
        {withBack && (
          <StyledIconBack>
            <Icon name="back" color="#313131" size="32" onPress={onBack} />
          </StyledIconBack>
        )}

        <StyledTitle>{title}</StyledTitle>

        {searchComponent && <StyledSearch>{searchComponent}</StyledSearch>}

        {isTablet && onShare && (
          <StyledIcon>
            <Icon name="share" onPress={onShare} />
          </StyledIcon>
        )}

        {onShowMenu && (isVerticalOrientation || !isTablet) && (
          <StyledIcon>
            <Icon name="menu" onPress={onShowMenu} />
          </StyledIcon>
        )}
      </StyledTopline>

      {footerComponent && <StyledFooter>{footerComponent}</StyledFooter>}
    </StyledContainer>
  );
};

HeaderView.propTypes = {
  paddingBottom: PropTypes.number,
};

HeaderView.defaultProps = {
  paddingBottom: padding.small,
  paddingHorizontal: isTablet ? padding.large * 2 : padding.large,
};

export default HeaderView;
