import React, {useContext} from 'react';
import {Text, View} from 'react-native';

import HeaderView from './header-view';
import {OrientationContext} from '@/context';
import {useNavigation} from '@react-navigation/native';

const HeaderContainer = (props) => {
  const {isVerticalOrientation} = useContext(OrientationContext);

  const navigation = useNavigation();

  const handleBack = () => {
    navigation.goBack();
  };

  return (
    <HeaderView
      {...props}
      isVerticalOrientation={isVerticalOrientation}
      onBack={handleBack}
    />
  );
};

export default HeaderContainer;
