import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

export const StyledContainer = styled.View`
  flex-direction: row;
  align-items: center;
`;
