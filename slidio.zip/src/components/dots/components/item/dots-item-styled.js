import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';

export const StyledContainer = styled.View`
  align-items: center;
  width: 13px;
  height: 6px;
  margin-right: 2px;
`;

export const StyledDot = styled.View`
  width: ${props => (props.active ? 13 : 5)}px;
  height: 5px;
  border-radius: 32px;

  opacity: ${props => (props.active ? 1 : 0.5)};
`;
