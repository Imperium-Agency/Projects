import React, {useState, useEffect} from 'react';
import {View, Text, Animated} from 'react-native';

import {StyledContainer, StyledDot} from './dots-item-styled';

const DotsItemView = ({active, backgroundColor}) => {
  return (
    <StyledContainer>
      <StyledDot as={Animated.View} active={active} style={{backgroundColor}} />
    </StyledContainer>
  );
};

export default DotsItemView;
