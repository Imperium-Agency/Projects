export {default} from './dots-item-view';
