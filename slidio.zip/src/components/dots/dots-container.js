import React, {useMemo} from 'react';

import DotsView from './dots-view';

const DotsContainer = props => {
  const items = useMemo(() => {
    let res = [];

    for (let i = 1; i <= props.count; i++) {
      res.push(i - 1);
    }

    return res;
  }, [props.count]);

  return <DotsView {...props} items={items} />;
};

export default DotsContainer;
