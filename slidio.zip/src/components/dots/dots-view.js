import PropTypes from 'prop-types';
import React from 'react';
import {View, Text} from 'react-native';

import DotsItem from './components/item';

import {StyledContainer} from './dots-styled';

const DotsView = ({items, active, color}) => {
  return (
    <StyledContainer>
      {items.map((item, index) => (
        <DotsItem backgroundColor={color} active={index === active} />
      ))}
    </StyledContainer>
  );
};

DotsView.propTypes = {
  count: PropTypes.number,
  active: PropTypes.number,
};

DotsView.defaultProps = {
  active: 1,
};

export default DotsView;
