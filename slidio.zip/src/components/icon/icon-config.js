import ArrowDown from './images/arrow-down.png';
import ArrowLeft from './images/arrow-left.png';
import ArrowRight from './images/arrow-right.png';
import ArrowUp from './images/arrow-up.png';
import Back from './images/back.png';
import Close from './images/close.png';
import Menu from './images/menu.png';
import Search from './images/search.png';
import Share from './images/share.png';
import Snape from './images/snape.png';

export const icons = {
  'arror-right': ArrowRight,
  'arror-left': ArrowLeft,
  'arror-up': ArrowUp,
  'arrow-down': ArrowDown,
  close: Close,
  menu: Menu,
  search: Search,
  snape: Snape,
  share: Share,
  back: Back,
};
