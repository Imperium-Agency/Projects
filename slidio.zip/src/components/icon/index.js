export {default} from './icon-view';
