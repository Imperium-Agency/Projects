import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledImage = styled.Image`
  width: ${props => props.size}px;
  height: ${props => props.size}px;
  tint-color: ${props => props.color};
`;
