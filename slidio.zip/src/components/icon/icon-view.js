import {Text, TouchableOpacity, View} from 'react-native';

import PropTypes from 'prop-types';
import React from 'react';
import {StyledImage} from './icon-styled';
import {icons} from './icon-config';

const Icon = ({name, source, size, color, onPress}) => {
  const content = (
    <StyledImage source={source || icons[name]} size={size} color={color} />
  );

  return (
    (!!source || icons[name]) && (
      // disabled={!onPress}
      <>
        {onPress ? (
          <TouchableOpacity onPress={onPress}>{content}</TouchableOpacity>
        ) : (
          content
        )}
      </>
    )
  );
};

Icon.propTypes = {
  name: PropTypes.string,
  size: PropTypes.number,
  color: PropTypes.string,
};

Icon.defaultProps = {
  size: 24,
  color: '#313131',
};

export default Icon;
