import PropTypes from 'prop-types';
import FastImage from 'react-native-fast-image';

import React from 'react';
import {View, Text, ActivityIndicator} from 'react-native';

import Preloader from '@/components/preloader';

import {
  StyledPreloader,
  StyledContainer,
  StyledActivityIndicator,
} from './fast-image-styled';

const FastImageView = props => {
  return (
    <StyledContainer style={props.containerStyle}>
      {props.loading && (
        <StyledPreloader>
          {props.indicator ? (
            <StyledActivityIndicator
              size="large"
              style={props.indicatorStyle}
              {...props.indicatorProps}
            />
          ) : (
            <Preloader />
          )}
        </StyledPreloader>
      )}
      {/* <Text>{JSON.stringify(props.style)}</Text> */}
      <FastImage
        {...props}
        resizeMode={FastImage.resizeMode[props.resizeMode]}
        onLoadStart={() => props.onChangeLoading(true)}
        onLoad={() => props.onChangeLoading(false)}
      />
    </StyledContainer>
  );
};

export default FastImageView;
