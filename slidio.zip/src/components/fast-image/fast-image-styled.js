import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.View`
  overflow: hidden;
`;

export const StyledPreloader = styled.View`
  position: absolute;
  top: 0px;
  right: 0px;
  bottom: 0px;
  left: 0px;
`;

export const StyledActivityIndicator = styled.ActivityIndicator`
  margin: auto;
`;

export const StyledFastImage = styled.Image`
  width: 100%;
  height: 100%;

  z-index: 1;
  elevation: 1;
`;
