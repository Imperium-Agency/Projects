import React, {useState} from 'react';
import {View, Text} from 'react-native';

import FastImageView from './fast-image-view';

const FastImageContainer = props => {
  const [loading, setLoading] = useState(true);

  const handlerChangeLoading = value => {
    setLoading(value);
  };

  return (
    <FastImageView
      {...props}
      loading={loading}
      onChangeLoading={handlerChangeLoading}
    />
  );
};

export default FastImageContainer;
