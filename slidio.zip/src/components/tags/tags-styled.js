import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.View`
  flex-direction: row;
  align-items: center;
`;

export const StyledTag = styled.Text`
  padding: 3px 8px;
  margin-right: ${props => (props.first ? 8 : 0)}px;

  font-size: 15px;
  color: ${props => props.color};

  border-width: 1px;
  border-color: ${props => props.color};
  border-radius: 15px;
`;
