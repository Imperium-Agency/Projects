export {default} from './tags-view';
