import React from 'react';
import {View, Text} from 'react-native';

import {StyledContainer, StyledTag} from './tags-styled';

import {useTranslation} from 'react-i18next';

const TagsView = ({items}) => {
  const {t} = useTranslation('common');

  return (
    <StyledContainer>
      {items.indexOf('free') !== -1 && (
        <StyledTag first color="#53BDF9">
          {t('text_tag_free')}
        </StyledTag>
      )}

      {items.indexOf('pro') !== -1 && (
        <StyledTag color="#F95361">{t('text_tag_pro')}</StyledTag>
      )}
    </StyledContainer>
  );
};

TagsView.defaultProps = {
  items: [],
};

export default TagsView;
