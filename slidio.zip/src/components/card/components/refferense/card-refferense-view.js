import {Dimensions, StyleSheet, Text, View} from 'react-native';
import {PanGestureHandler, State} from 'react-native-gesture-handler';
import React, {memo, useRef, useState} from 'react';

import Animated from 'react-native-reanimated';
import FastImage from 'react-native-fast-image';
import Icon from '../../../icon';
import {compose} from 'recompose';
import {margin} from '@theme/spacing';
import {withTranslation} from 'react-i18next';

const {
  cond,
  eq,
  add,
  set,
  Value,
  event,
  max,
  min,
  interpolate,
  Extrapolate,
} = Animated;

const CardRefferense = memo(({image, t}) => {
  const [containerSize, setContainerSize] = useState({width: 0, height: 0});

  const dragX = useRef(new Value(0));

  const offsetX = useRef(new Value(0));
  const gestureState = useRef(new Value(-1));

  const onGestureEvent = event([
    {
      nativeEvent: {
        translationX: dragX.current,
        state: gestureState.current,
      },
    },
    {useNativeDriver: false},
  ]);

  const transX = cond(
    eq(gestureState.current, State.ACTIVE),
    add(offsetX.current, dragX.current),
    set(offsetX.current, add(offsetX.current, dragX.current)),
  );

  const translateX = interpolate(transX, {
    inputRange: [0, containerSize.width],
    outputRange: [0, containerSize.width],
    extrapolateRight: 'clamp',
    extrapolateLeft: 'clamp',
  });

  return (
    <View
      style={styles.container}
      onLayout={event => {
        if (!containerSize.width) {
          setContainerSize(event.nativeEvent.layout);
          offsetX.current.setValue(event.nativeEvent.layout.width / 3);
        }
      }}>
      <Animated.View style={[styles.content, {width: translateX}]}>
        {/* <View style={{flex: 1, position: 'relative'}}> */}
        <View style={styles.line}></View>

        <FastImage
          source={{uri: image}}
          resizeMode={FastImage.resizeMode.cover}
          style={{
            width: containerSize.width,
            height: containerSize.height,
          }}
        />
        {/* </View> */}
      </Animated.View>

      <PanGestureHandler
        maxPointers={1}
        onGestureEvent={onGestureEvent}
        onHandlerStateChange={onGestureEvent}>
        <Animated.View
          style={[
            styles.box,
            {
              transform: [
                {
                  translateX: translateX,
                },
              ],
            },
          ]}>
          <Icon name="arror-left" color="#FE805C" />
          <Icon name="arror-right" color="#FE805C" />
        </Animated.View>
      </PanGestureHandler>

      <View
        animation="slideInLeft"
        duration={500}
        useNativeDriver={true}
        style={styles.order(true)}>
        <Text style={styles.orderText}>
          {t('home:text_card_before').toUpperCase()}
        </Text>
      </View>

      <View
        animation="slideInRight"
        duration={500}
        useNativeDriver={true}
        style={styles.order(false)}>
        <Text style={styles.orderText}>
          {t('home:text_card_after').toUpperCase()}
        </Text>
      </View>
    </View>
  );
});

const CIRCLE_SIZE = 55;

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    flex: 1,
    justifyContent: 'center',

    overflow: 'hidden',
  },
  box: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: CIRCLE_SIZE,
    height: CIRCLE_SIZE,
    padding: 5,
    marginLeft: -(CIRCLE_SIZE / 2),

    borderRadius: CIRCLE_SIZE / 2,
    backgroundColor: '#fff',

    opacity: 0.9,
  },

  content: {
    position: 'absolute',
    left: 0,
    top: 0,
    // backgroundColor: 'green',
    height: '100%',

    // borderLeftColor: '#CABFAD',

    overflow: 'hidden',
  },

  order: before => ({
    alignItems: 'center',
    justifyContent: 'center',

    position: 'absolute',
    top: margin.large,
    left: before ? margin.large : undefined,
    right: !before ? margin.large : undefined,
    zIndex: 3,
    elevation: 3,
    paddingHorizontal: 15,
    paddingVertical: 5,

    borderRadius: 15,

    backgroundColor: '#CABFAD',

    opacity: 0.95,
  }),

  orderText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#fff',
  },

  line: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 1,
    height: '100%',
    backgroundColor: '#CABFAD',
    zIndex: 1,
    elevation: 1,
  },
});

export default compose(withTranslation())(CardRefferense);
