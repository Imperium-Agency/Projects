import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

import {isTablet} from '@/helpers';
// width: 251px;
// height: 213px;

export const StyledContainer = styled.View`
  width: 100%;
  height: 278px;

  justify-content: flex-start;
`;

export const StyledBody = styled.View`
  flex: 1;
  position: relative;

  border-radius: ${isTablet ? 24 : 16}px;

  overflow: hidden;
`;

export const StyledRefferense = styled.View`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;

  z-index: 2;
  elevation: 2;
`;
