import PropTypes from 'prop-types';
import React from 'react';
import {ActivityIndicator, TouchableWithoutFeedback, View} from 'react-native';

import FastImage from 'react-native-fast-image';

import CardRefferense from './components/refferense';

import {StyledContainer, StyledBody, StyledRefferense} from './card-styled';

const CardView = ({
  data,
  showRefference,
  width,
  height,
  children,
  containerStyle,
  onChoose,
}) => {
  if (data) {
    return (
      <TouchableWithoutFeedback onPress={onChoose}>
        <StyledContainer style={containerStyle}>
          <StyledBody>
            <FastImage
              source={{uri: data.image || data.reference}}
              resizeMode={FastImage.resizeMode.cover}
              style={{flex: 1}}
              PlaceholderContent={<ActivityIndicator size="small" />}
            />

            {showRefference && (
              <StyledRefferense>
                <CardRefferense image={data.reference} />
              </StyledRefferense>
            )}
          </StyledBody>
        </StyledContainer>
      </TouchableWithoutFeedback>
    );
  }
};

CardView.propTypes = {
  containerStyle: PropTypes.object,
};

export default CardView;
