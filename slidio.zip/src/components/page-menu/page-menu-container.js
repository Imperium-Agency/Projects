import React, {useContext} from 'react';
import {View, Text} from 'react-native';

import PageMenuView from './page-menu-view';

import {OrientationContext} from '@/context';

const PageMenuContainer = props => {
  const {isVerticalOrientation} = useContext(OrientationContext);

  return (
    <PageMenuView {...props} isVerticalOrientation={isVerticalOrientation} />
  );
};

export default PageMenuContainer;
