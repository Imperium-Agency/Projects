import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.View`
  flex: 1;

  background-color: #efeae8;
`;

export const StyledScrollView = styled.ScrollView.attrs(props => ({
  contentContainerStyle: {
    paddingTop: props.insets.top + 34,
  },
}))``;

export const StyledContant = styled.View`
  flex: 1;
  flex-direction: row;
  shadow-color: #000;
  shadow-offset: {width: -10px, height: 0px};
  shadow-opacity: 0.05;
  shadow-radius: 20;
  elevation: 3;
`;

export const StyledHeader = styled.View`
  padding: 27px;
`;
