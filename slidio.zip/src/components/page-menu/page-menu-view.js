import {ScrollView, Text, View} from 'react-native';
import {
  StyledContainer,
  StyledContant,
  StyledScrollView,
} from './page-menu-styled';

import PageMenuContent from './components/content';
import PageMenuDrawer from './components/drawer';
import React from 'react';
import {TABLET_SIDEBAR_WIDTH} from '@/constants';
import {isTablet} from '@/helpers';
import {useSafeArea} from 'react-native-safe-area-context';

const PageMenuView = ({
  children,
  items,
  title,
  activedItem,
  showDrawer,
  isVerticalOrientation,
  onChangeShowDrawer,
  onSelect,
}) => {
  const insets = useSafeArea();

  console.log(insets.top);

  return (
    <StyledContainer>
      <PageMenuDrawer
        showDrawer={showDrawer}
        onChangeShowDrawer={onChangeShowDrawer}>
        <StyledContant>
          {isTablet && !isVerticalOrientation && (
            <View style={{width: TABLET_SIDEBAR_WIDTH}}>
              <StyledScrollView insets={insets}>
                <PageMenuContent
                  page
                  items={items}
                  title={title}
                  activedItem={activedItem}
                  onSelect={onSelect}
                />
              </StyledScrollView>
            </View>
          )}

          {children}
        </StyledContant>
      </PageMenuDrawer>
    </StyledContainer>
  );
};

export default PageMenuView;
