import PropTypes from 'prop-types';

import React from 'react';
import {View, Text} from 'react-native';

import PageMenuItem from '../item';
import PageMenuSubscription from '../subscription';
import PageMenuLanguages from '../languages';

import {
  StyledContainer,
  StyledTitle,
  StyledBody,
  StyledHr,
  StyledFooter,
  StyledLanguages,
  StyledSubscription,
  StyledList,
} from './page-menu-content-styled';

import {useTranslation} from 'react-i18next';

const PageMenuContentView = ({
  isSubscribe,
  staticItems,
  items,
  title,
  page,
  activedItem,
  onSelect,

  onSelectStatic,
}) => {
  const {t} = useTranslation('home');

  return (
    <StyledContainer>
      <StyledBody>
        {/* {!!items.length && (
          <>
            <StyledList>
              {title && <StyledTitle>{title}</StyledTitle>}

              {items.map(item => (
                <PageMenuItem
                  text={item.lable}
                  icon={!page && item.icon}
                  page={page}
                  active={activedItem === item.value}
                  key={item.value}
                  onPress={() => onSelect(item.value)}
                />
              ))}
            </StyledList>

            <StyledHr />
          </>
        )} */}

        <StyledList>
          {staticItems.map(item => (
            <PageMenuItem
              text={t(`text_menu_${item.name}`)}
              icon={!page && item.icon}
              page={page}
              key={item.name}
              onPress={() => onSelectStatic(item.name)}
            />
          ))}
        </StyledList>
      </StyledBody>

      {/* <StyledHr /> */}
      {!isSubscribe && (
        <StyledSubscription>
          <PageMenuSubscription />
        </StyledSubscription>
      )}

      <StyledHr />

      <StyledFooter>
        <StyledLanguages>
          <PageMenuLanguages />
        </StyledLanguages>
      </StyledFooter>
    </StyledContainer>
  );
};

PageMenuContentView.propTypes = {
  staticItems: PropTypes.array,
  items: PropTypes.array,
  onSelect: PropTypes.func,
};

PageMenuContentView.defaultProps = {
  staticItems: [],
  items: [],
  onSelect: () => {},
};

export default PageMenuContentView;
