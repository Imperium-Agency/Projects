import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

import {isTablet} from '@/helpers';

export const StyledContainer = styled.View`
  flex: 1;
`;
// margin - top: 62px;

export const StyledTitle = styled.Text`
  margin-bottom: ${margin.small}px;

  font-weight: 500;
  font-size: 14px;
  text-transform: uppercase;

  color: #909396;
`;

// ${ padding.extraSmall } px

export const StyledBody = styled.View``;

export const StyledList = styled.View`
  padding: 0 ${padding.big - padding.small}px;
`;

// border - bottom - width: 0.5px;
// border - bottom - color: #e1e7ea;

// margin: ${ margin.small } px 0px 0px ${ margin.big } px;
export const StyledHr = styled.View`
  margin-vertical: ${margin.extraSmall + margin.small}px;
  margin-left: ${isTablet ? margin.big : 0}px;

  height: ${isTablet ? 1 : 0.5}px;
  background-color: ${isTablet ? 'rgba(144, 147, 150, 0.1)' : '#E1E7EA'};
`;

export const StyledFooter = styled.View``;

// margin - top: ${ margin.small } px;
export const StyledLanguages = styled.View`
  margin-top: ${margin.small}px;
  padding: 0px ${padding.large}px;
`;

export const StyledSubscription = styled.View`
  margin-top: ${margin.base}px;
  padding: 0px ${padding.big}px;
`;
