export {default} from './page-menu-content-redux';
