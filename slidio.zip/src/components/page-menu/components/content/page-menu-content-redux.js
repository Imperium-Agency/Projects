import PageMenuContentContainer from './page-menu-content-container';

import {connect} from 'react-redux';
import {compose, withProps} from 'recompose';

import {getAvailablePurchases} from 'src/modules/iap/actions';
import {isSubscribeSelector} from 'src//modules/iap/selectors';

const mapStateToProps = state => {
  return {
    isSubscribe: isSubscribeSelector(state),
  };
};

const mapDispatchToProps = {
  getAvailablePurchases: getAvailablePurchases,
};

export default compose(
  withProps(),
  connect(
    mapStateToProps,
    mapDispatchToProps,
  ),
)(PageMenuContentContainer);
