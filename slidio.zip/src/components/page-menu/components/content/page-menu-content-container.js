import PropTypes from 'prop-types';

import React from 'react';
import {View, Text, Linking} from 'react-native';

import PageMenuContentView from './page-menu-content-view';

import {useNavigation} from '@react-navigation/native';

const staticItems = [
  {name: 'contact', icon: require('./images/contact.png')},
  {name: 'terms_of_use', icon: require('./images/terms_of_use.png')},
  {name: 'privacy_policy', icon: require('./images/privacy_policy.png')},
  {name: 'restore_purchases', icon: require('./images/restore_purchases.png')},
];

const PageMenuContentContainer = props => {
  const navigation = useNavigation();

  const _handleNavigate = route => {
    navigation.navigate(route);

    props.onClose();
  };

  const _handlerSelectItem = name => {
    switch (name) {
      case 'contact':
        Linking.openURL('https://m.me/106762567699626');
        break;
      case 'terms_of_use':
        _handleNavigate('TermOfUse');
        break;
      case 'privacy_policy':
        _handleNavigate('PrivacyPolicy');
        break;
      case 'restore_purchases':
        props.getAvailablePurchases();
        break;
      default:
        break;
    }
  };

  return (
    <PageMenuContentView
      {...props}
      staticItems={staticItems}
      onSelectStatic={_handlerSelectItem}
    />
  );
};

PageMenuContentContainer.propTypes = {
  onClose: PropTypes.func,
};

PageMenuContentContainer.defaultProps = {
  onClose: () => {},
};

export default PageMenuContentContainer;
