import {Dimensions, Text, View} from 'react-native';
import {
  StyledBody,
  StyledHeader,
  StyledScrollView,
} from './page-menu-drawer-styled';

import Drawer from 'react-native-drawer';
import Icon from '@/components/icon';
import PageMenuContent from '../content';
import PropTypes from 'prop-types';
import React from 'react';
import {useSafeArea} from 'react-native-safe-area-context';

const PageMenuDrawerView = ({children, showDrawer, onChangeShowDrawer}) => {
  const insets = useSafeArea();

  return (
    <Drawer
      open={showDrawer}
      type="overlay"
      tapToClose={true}
      openDrawerOffset={Dimensions.get('window').width - 290} // 20% gap on the right side of drawer
      tweenDuration={300}
      negotiatePan={true}
      side={'right'}
      content={
        <StyledScrollView insets={insets}>
          <StyledHeader>
            <Icon name="close" onPress={() => onChangeShowDrawer(false)} />
          </StyledHeader>

          <PageMenuContent />
        </StyledScrollView>
      }
      tweenHandler={ratio => ({
        main: {opacity: 2 - ratio},
      })}
      onOpen={() => {
        !showDrawer && onChangeShowDrawer(true);
      }}
      onClose={() => {
        showDrawer && onChangeShowDrawer(false);
      }}>
      <StyledBody>{children}</StyledBody>
    </Drawer>
  );
};

export default PageMenuDrawerView;
