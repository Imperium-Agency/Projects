export {default} from './page-menu-drawer-view';
