import styled from 'styled-components/native';

import {margin, padding} from '@theme/spacing';
import {isTablet} from '@/helpers';

export const StyledScrollView = styled.ScrollView.attrs(props => ({
  minHeight: '100%',

  paddingTop: props.insets.top,
  paddingBottom: props.insets.bottom,
}))`
  flex: 1;
  background-color: #fff;
`;

export const StyledHeader = styled.View`
  padding: ${margin.base}px 27px 27px;
`;

export const StyledBody = styled.View`
  flex: 1;
`;
