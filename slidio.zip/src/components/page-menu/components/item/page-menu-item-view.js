import PropTypes from 'prop-types';

import React, {useState, useEffect} from 'react';
import {
  Animated,
  TouchableOpacity,
  TouchableWithoutFeedback,
} from 'react-native';

import Icon from '@/components/icon';

import {
  StyledContainer,
  StyledContent,
  StyledText,
  StyledArrow,
  StyledIcon,
  StyledActive,
} from './page-menu-item-styled';

import {isTablet} from '@/helpers';

const PageMenuItem = ({text, icon, page, active, onPress}) => {
  const [activeValue] = useState(new Animated.Value(active ? 1 : 0));

  useEffect(() => {
    Animated.timing(activeValue, {
      toValue: active ? 1 : 0,
      useNativeDriver: false,
    }).start();
  }, [active]);

  // const backgroundColor = activeValue.interpolate({
  //   inputRange: [0, 1],
  //   outputRange: ['#EFEAE8', '#ef550a'],
  // });

  const color = activeValue.interpolate({
    inputRange: [0, 1],
    outputRange: [isTablet ? '#909396' : '#141719', '#fff'],
  });

  return (
    <TouchableWithoutFeedback onPress={onPress}>
      <StyledContainer>
        <StyledContent>
          {icon && (
            <StyledIcon>
              <Icon source={icon} />
            </StyledIcon>
          )}

          <StyledText as={Animated.Text} style={{color}}>
            {text}
          </StyledText>

          <StyledActive
            as={Animated.View}
            style={{transform: [{scale: activeValue}], opacity: activeValue}}
          />
        </StyledContent>
      </StyledContainer>
    </TouchableWithoutFeedback>
  );
};

PageMenuItem.propTypes = {
  text: PropTypes.string,
  page: PropTypes.bool,
  onPress: PropTypes.func,
};

PageMenuItem.defaultProps = {
  page: false,
  onPress: () => {},
};

export default PageMenuItem;
