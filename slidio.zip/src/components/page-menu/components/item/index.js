export {default} from './page-menu-item-view';
