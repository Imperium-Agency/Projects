import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.View`
  width: 100%;
`;

export const StyledContent = styled.View`
  position: relative;
  padding: ${padding.extraSmall}px ${padding.small}px;
  margin-vertical: ${padding.small - padding.extraSmall}px;
  margin-right: auto;
  flex-direction: row;
  align-items: center;
`;

export const StyledActive = styled.View`
position: absolute;
top: 0;
bottom: 0;
left: 0;
right: 0;

background: #ef550a;
border-radius: 8px;

shadow-color: #000;
shadow-offset: {width:0px, height: 0px};
shadow-opacity: 0;
shadow-radius: 20;

z-index: -1;
`;

// box - shadow: 0px 10px 20px rgba(239, 85, 10, 0.2);

export const StyledText = styled.Text`
  max-width: 95%;
  flex-wrap: wrap;
  font-size: 16px;

  color: #fff;
`;
// color: #909396;

export const StyledIcon = styled.View`
  margin-right: ${margin.base}px;
`;

export const StyledBody = styled.View`
  margin: 40px 0;
`;
