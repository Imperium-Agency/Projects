import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.View`
  position: relative;
  flex-direction: row;
  justify-content: space-between;
`;

export const StyledItem = styled.View`
  flex: 1;
  padding-horizontal: 5px;
  padding-vertical: 3px;
  max-width: 40px;
  align-items: center;

  border-radius: 26px;
  border-width: 1px;
  border-color: ${props => (props.active ? '#F5854F' : 'transparent')};
  background-color: ${props => (props.active ? '#F5854F' : 'transparent')};

  opacity: 0.7;
`;
// '#313131'
export const StyledText = styled.Text`
  color: ${props => (props.active ? '#fff' : '#909396')};

  font-weight: 600;
  font-size: 13px;
`;
