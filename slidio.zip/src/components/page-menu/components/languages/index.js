export {default} from './page-menu-languages-redux';
