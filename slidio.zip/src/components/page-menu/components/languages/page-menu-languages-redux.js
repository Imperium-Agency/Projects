import PageMenuLanguagesView from './page-menu-languages-view';

import {connect} from 'react-redux';

import {changeLanguage} from 'src/modules/common/actions';

import {
  languageSelector,
  listLanguageSelector,
} from 'src/modules/common/selectors';

const mapStateToProps = state => {
  return {
    language: languageSelector(state),
    listLanguage: listLanguageSelector(state),
  };
};

const mapDispatchToProps = {
  onChangeLanguage: changeLanguage,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(PageMenuLanguagesView);
