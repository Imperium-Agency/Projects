import React from 'react';
import {TouchableOpacity} from 'react-native';

import {
  StyledContainer,
  StyledItem,
  StyledText,
} from './page-menu-languages-styled';

const PageMenuLanguagesView = ({language, listLanguage, onChangeLanguage}) => {
  return (
    <StyledContainer>
      {listLanguage.map(item => (
        <StyledItem
          as={TouchableOpacity}
          active={item === language}
          key={item}
          onPress={() => onChangeLanguage(item)}>
          <StyledText active={item === language}>
            {item.toUpperCase()}
          </StyledText>
        </StyledItem>
      ))}
    </StyledContainer>
  );
};

export default PageMenuLanguagesView;
