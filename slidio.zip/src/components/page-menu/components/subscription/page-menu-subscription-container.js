import React from 'react';

import PageMenuSubscriptionView from './page-menu-subscription-view';

import {useNavigation} from '@react-navigation/native';

const PageMenuSubscriptionContainer = () => {
  const navigation = useNavigation();

  const onSubscribe = () => {
    console.log('ddd');
    navigation.navigate('Subscription', {firstStart: false});
  };

  return <PageMenuSubscriptionView onSubscribe={onSubscribe} />;
};

export default PageMenuSubscriptionContainer;
