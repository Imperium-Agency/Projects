import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.ImageBackground`
  border-radius: 12px;

  shadow-color: #000;
  shadow-offset: {width: 0px, height: 10px};
  shadow-opacity: 0.15;
  shadow-radius: 30px;
`;

export const StyledImageBackground = styled.ImageBackground`
  padding: ${padding.base}px 13px ${padding.base}px;
  align-items: center;

  border-radius: 12px;

  overflow: hidden;
`;

export const StyledTitle = styled.Text`
  margin-bottom: ${margin.base}px;

  font-size: 24px;
  line-height: 29px
  font-weight: ${props => props.fontWeight || 300};
  text-align: center;

  color: #FFFFFF;
`;

export const StyledPageContent = styled.View`
  width: 100%;
  height: 100%;
`;
