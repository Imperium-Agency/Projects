import React from 'react';
import {View, Text} from 'react-native';

import Button from '@/components/button';

import {
  StyledContainer,
  StyledImageBackground,
  StyledTitle,
} from './page-menu-subscription-styled';

import {useTranslation} from 'react-i18next';

const PageMenuSubscriptionView = ({onSubscribe}) => {
  const {t} = useTranslation('home');

  return (
    <StyledContainer>
      <StyledImageBackground
        source={require('./images/subscribe.jpg')}
        resizeMode="cover">
        <StyledTitle>
          <StyledTitle fontWeight="600">Pro</StyledTitle> Subscription
        </StyledTitle>

        <Button
          full
          size="small"
          title={t('text_subscribe')}
          onPress={onSubscribe}
          // onPress={() =>
          //   !isActiveSelect &&
          //   navigation.navigate('Subscription', {firstStart: false})
          // }
        />
      </StyledImageBackground>
    </StyledContainer>
  );
};

export default PageMenuSubscriptionView;
