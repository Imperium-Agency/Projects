import * as Animatable from 'react-native-animatable';

import {
  ActivityIndicator,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {createRef, useEffect} from 'react';
import {
  StyledContainer,
  StyledContent,
  StyledIcon,
  StyledLoader,
  StyledText,
  StyledTextLoader,
} from './button-styled';

import Icon from '../icon';
import PropTypes from 'prop-types';

const options = {
  big: {height: 65, borderRadius: 42},
  small: {height: 36, borderRadius: 8},
  base: {height: 50, borderRadius: 25},
};

const Button = ({
  title,
  icon,
  size,
  type,
  round,
  animated,
  full,
  backgroundColor,
  titleColor,
  loading,
  disabled,
  progress,
  styleContainer,
  styleText,

  onPress,
}) => {
  const containerRef = createRef();

  useEffect(() => {
    if (animated) {
      containerRef.current.transitionTo({backgroundColor});
    }
  }, [backgroundColor]);

  return (
    <StyledContainer
      as={TouchableOpacity}
      style={styleContainer}
      size={size}
      backgroundColor={backgroundColor}
      round={round}
      full={full}
      options={options}
      disabled={loading || disabled}
      onPress={onPress}
      activeOpacity={animated ? 1 : 0.2}>
      <Animatable.View ref={containerRef}>
        <StyledContent loading={loading}>
          <StyledText
            style={styleText}
            round={round}
            backgroundColor={backgroundColor}
            titleColor={titleColor}>
            {title}
          </StyledText>

          {icon && (
            <StyledIcon>
              <Icon name={icon} />
            </StyledIcon>
          )}
        </StyledContent>

        {loading && (
          <StyledLoader>
            {progress != null && (
              <StyledTextLoader
                round={round}
                backgroundColor={backgroundColor}
                titleColor={titleColor}>
                {progress}%
              </StyledTextLoader>
            )}

            <ActivityIndicator size="small" color={'#fff'} />
          </StyledLoader>
        )}
      </Animatable.View>
    </StyledContainer>
  );
};

Button.propTypes = {
  title: PropTypes.string,
  icon: PropTypes.string,
  progress: PropTypes.string,
  backgroundColor: PropTypes.string,
  titleColor: PropTypes.string,
  size: PropTypes.oneOf(['big', 'small', 'base']),
  type: PropTypes.oneOf(['solid', 'clear']),
  loading: PropTypes.bool,
  disabled: PropTypes.bool,
  animated: PropTypes.bool,
  full: PropTypes.bool,
  styleContainer: PropTypes.object,
  styleText: PropTypes.object,
  onPress: PropTypes.func,
};

Button.defaultProps = {
  size: 'base',
  type: 'solid',
  backgroundColor: '#EF550A',
  titleColor: '#fff',
  round: false,
  loading: false,
  disabled: false,
  progress: null,
  animated: false,
  full: false,
  styleContainer: () => {},
  styleText: () => {},
};

export default Button;
