import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  position: relative;
  height: ${(props) => props.options[props.size].height};
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding-horizontal: ${(props) => (props.size === 'big' ? 39 : 14)};
  background-color: ${(props) =>
    props.round ? 'transparent' : props.backgroundColor};
  border-radius: ${(props) => props.options[props.size].borderRadius};
  border-width: 2;
  border-color: ${(props) => props.backgroundColor};
`;

export const StyledContent = styled.View`
  height: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  opacity: ${(props) => (props.loading ? 0 : 1)};
`;

export const StyledLoader = styled.View`
  width: 100%;
  height: 100%;

  flex-direction: row;

  justify-content: center;
  align-items: center;

  position: absolute;
  z-index: 1;
`;

export const StyledIcon = styled.View`
  margin-left: 16px;
`;

export const StyledText = styled.Text`
  font-size: 16px;
  font-weight: 600;
  text-align: center;
  color: ${(props) => (props.round ? props.backgroundColor : props.titleColor)};
`;

export const StyledTextLoader = styled.Text`
  margin-right: 5px;
  font-size: 12px;
  color: ${(props) => (props.round ? props.backgroundColor : props.titleColor)};
`;
