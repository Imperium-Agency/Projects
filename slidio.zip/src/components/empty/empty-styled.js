import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  flex: 1;
  align-items: center;
  justify-content: center;
  padding: 0 40px;
`;

export const StyledTitle = styled.Text`
  margin-bottom: 12px;
  text-align: center;
  font-size: 24px;
  font-weight: 600;
`;

export const StyledSubtitle = styled.Text`
  margin-bottom: 20px;
  text-align: center;
  color: #383838;
`;

export const StyledButton = styled.View`
  padding: 0 30px;
`;
