import {StyleSheet, Text, View} from 'react-native';
import {
  StyledButton,
  StyledContainer,
  StyledSubtitle,
  StyledTitle,
} from './empty-styled';

import Button from 'src/components/button';
import React from 'react';
import {withTranslation} from 'react-i18next';

type Props = {
  icon: string,
  titleButton?: string,
  clickButton?: void => {},
  title: string,
  subTitle: string,
  avatarProps?: object,
};

const Empty = (props: Props) => {
  const {titleButton, clickButton, buttonProps, title, subTitle, t} = props;

  const buttonStyle =
    buttonProps && buttonProps.buttonStyle ? buttonProps.buttonStyle : {};
  const containerStyle =
    buttonProps && buttonProps.containerStyle ? buttonProps.containerStyle : {};

  return (
    <StyledContainer>
      <StyledTitle>{title}</StyledTitle>
      <StyledSubtitle>{subTitle}</StyledSubtitle>

      {titleButton && (
        <StyledButton
          as={Button}
          type="outline"
          {...buttonProps}
          title={titleButton}
          onPress={clickButton}
          styleContainer={[{minWidth: 160}, containerStyle && containerStyle]}
        />
      )}
    </StyledContainer>
  );
};

Empty.defaultProps = {};

export default withTranslation()(Empty);
