import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.View`
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  right: 0px;
  justify-content: center;
  align-items: center;

  background-color: rgba(0, 0, 0, 0.5);

  z-index: 9999;
`;

export const StyledText = styled.Text`
  margin-top: ${margin.small}px;

  font-size: 14px;
  color: #fff;
`;
