export {default} from './spinner-view';
