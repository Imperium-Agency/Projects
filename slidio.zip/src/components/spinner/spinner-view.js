import React from 'react';
import {ActivityIndicator} from 'react-native';

import {StyledContainer, StyledText} from './spinner-styled';

const Spinner = ({visible, textContent}) => {
  return (
    <>
      {visible && (
        <StyledContainer>
          <ActivityIndicator color="#fff" size="large" />

          <StyledText>{textContent}</StyledText>
        </StyledContainer>
      )}
    </>
  );
};

export default Spinner;
