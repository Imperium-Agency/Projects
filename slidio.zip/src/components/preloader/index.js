export {default} from './preloader-view';
