import styled from 'styled-components/native';

import {padding, margin} from '@theme/spacing';

export const StyledContainer = styled.View`
  height: 100%;

  background: rgba(245, 245, 245, 0.8);

  overflow: hidden;
`;

export const StyledImageContainer = styled.View`
  height: 100%;
`;

export const StyledImage = styled.Image`
  height: 100%;
`;

export const StyledLine = styled.View`
  height: 100%;
  width: 1px;

  background: #EEEEEE;
  

  shadow-color: #212121;
  shadow-offset: {width: 55px, height: 0px};
  shadow-opacity: 1;
  shadow-radius: 17px;

  elevation: 20;

  opacity: 0.75;

  
`;
