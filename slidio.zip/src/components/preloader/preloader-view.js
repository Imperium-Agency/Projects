import React, {useState, useEffect} from 'react';
import {View, Text, Animated, Dimensions, Image} from 'react-native';

import {
  StyledContainer,
  StyledLine,
  StyledImageContainer,
  StyledImage,
} from './preloader-styled';

const PreloaderView = ({style}) => {
  const [animateValue] = useState(new Animated.Value(0));
  const [containerSize, setContainerSize] = useState(0);

  useEffect(() => {
    runAnimation();
  }, []);

  const runAnimation = () => {
    animateValue.setValue(0);

    Animated.timing(animateValue, {
      toValue: 1,
      useNativeDriver: true,
      // duration: 1700,
      duration: 3500,
    }).start(runAnimation);
  };

  const translateX = animateValue.interpolate({
    inputRange: [0, 1],
    outputRange: [
      -Dimensions.get('window').width,
      Dimensions.get('window').width,
    ],
    // outputRange: [-containerSize * 1.2, containerSize * 1.2],
  });

  return (
    <StyledContainer
      style={style}
      onLayout={event => setContainerSize(event.nativeEvent.layout.width)}>
      <StyledImageContainer
        as={Animated.View}
        style={{
          transform: [{translateX}],
        }}>
        <StyledImage source={require('./images/shadow.png')} />
      </StyledImageContainer>
      {/* <StyledLine as={Animated.View} style={{transform: [{translateX}]}} /> */}
    </StyledContainer>
  );
};

export default PreloaderView;
