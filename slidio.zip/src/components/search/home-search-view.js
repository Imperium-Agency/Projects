import {Dimensions, Text, View} from 'react-native';
import React, {useMemo} from 'react';
import {margin, padding} from '@theme/spacing';

import Input from '@/components/input';
import {StyledContainer} from './home-search-styled';

const HomeCategoriesView = ({data, setInputRef, placholder, onChange}) => {
  return (
    <StyledContainer>
      <Input
        value={data}
        setInputRef={setInputRef}
        onChange={onChange}
        placholder={placholder}
      />
    </StyledContainer>
  );
};

export default HomeCategoriesView;
