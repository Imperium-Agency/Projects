import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  width: 100%;
`;

// padding: 0px ${ padding.large } px;
