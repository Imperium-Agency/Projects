import React, {useMemo} from 'react';

import HomeSearch from './home-search-view';

const HomeSearchContainer = (props) => {
  return <HomeSearch {...props} />;
};

export default HomeSearchContainer;
