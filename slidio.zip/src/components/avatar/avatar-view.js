import React from 'react';
import {View, Text, Image} from 'react-native';

import FastImage from 'react-native-fast-image';

import {StyledImage} from './avatar-styled';

const avatar = ({size, source}) => {
  // return <Image source={source} />;
  return (
    <StyledImage
      as={FastImage}
      source={source}
      size={size}
      resizeMode={FastImage.resizeMode.cover}
    />
  );
};

export default avatar;
