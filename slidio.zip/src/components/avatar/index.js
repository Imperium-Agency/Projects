export {default} from './avatar-view';
