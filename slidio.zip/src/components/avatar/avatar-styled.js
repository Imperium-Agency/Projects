import styled from 'styled-components/native';

export const StyledImage = styled.Image`
  width: ${props => props.size}px;
  height: ${props => props.size}px;

  border-radius: ${props => props.size / 2}px;
`;
