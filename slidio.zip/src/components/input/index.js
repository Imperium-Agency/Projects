export {default} from './input-view';
