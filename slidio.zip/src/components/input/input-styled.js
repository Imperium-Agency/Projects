import {margin, padding} from '@theme/spacing';

import styled from 'styled-components/native';

export const StyledContainer = styled.View`
  height: 40px;
  width: 100%;

  padding: 0 15px;

  flex-direction: row;
  align-items: center;

  border-radius: 8px;

  background-color: #e5e7ea;
`;

export const StyledInput = styled.View`
  height: 100%;
  width: 100%;

  color: #909396;
  font-size: 14px;
  line-height: 16px;

  border-radius: 8px;
`;

export const StyledIcon = styled.View`
  height: 22px;
  width: 22px;

  margin-right: 15px;
`;
