import {Dimensions, Platform, NativeModules} from 'react-native';

import DeviceInfo from 'react-native-device-info';

const Screen = Dimensions.get('window');
const ScreenWidth = Screen.width;
const ScreenHeight = Screen.height;
const isIOS = Platform.OS === 'ios';
const isTablet = DeviceInfo.isTablet();

const conditionalStyle = (condition, style) => (condition ? style : {});

const deviceLanguage = (Platform.OS === 'ios'
  ? NativeModules.SettingsManager.settings.AppleLocale ||
    NativeModules.SettingsManager.settings.AppleLanguages[0] //iOS 13
  : NativeModules.I18nManager.localeIdentifier
)
  .split('-')[0]
  .split('_')[0];

export {
  ScreenWidth,
  ScreenHeight,
  isIOS,
  isTablet,
  conditionalStyle,
  deviceLanguage,
};
