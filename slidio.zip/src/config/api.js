// export const API = 'https://slidio.azurewebsites.net';
export const API = 'https://api.unocreative.studio';
// https://slidio.azurewebsites.net/public/api

export default {
  API_ENDPOINT: API,
};
