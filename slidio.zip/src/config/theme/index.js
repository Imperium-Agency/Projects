import colors from './colors';
import spacing from './spacing';

export {colors, spacing};
