// Border radius
// export const borderRadius = {
//   base: 4,
//   small: 2,
//   large: 8,
//   big: 30,
// };

// // Line height
// export const lineHeight = {
//   base: 12,
//   small: 9,
//   large: 16,
//   big: 26,
// };

// Padding
export const padding = {
  extraSmall: 8,
  small: 12,
  base: 16,
  large: 24,
  big: 32,
};

// Margin
export const margin = {
  extraSmall: 8,
  small: 12,
  base: 16,

  large: 24,
  big: 32,
};

export default {
  // borderRadius,
  // lineHeight,
  padding,
  margin,
};
