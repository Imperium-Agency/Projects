export const red = '#FA7268';
export const blue = '#623BFF';

export default {red, blue};
