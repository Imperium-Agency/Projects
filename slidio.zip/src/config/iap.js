const PASSWORD = 'cb949e5d8324482b8da1f9ae2d5d5375';
const API_VALIDATE_RECEPT = 'https://subscribe.unocreative.studio';
const IS_DEV = true;

export {PASSWORD, API_VALIDATE_RECEPT, IS_DEV};

export const items = {
  monthly: 'monthly',
  yearly: 'yearly',
};

export const itemSubs = ['monthly', 'monthly_start', 'yearly', 'yearly_start'];

export const itemProds = ['prezentation'];
