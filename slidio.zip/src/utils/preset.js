import {Alert, Image, Permissions, Platform} from 'react-native';

import RNFS from 'react-native-fs';
import RNFetchBlob from 'rn-fetch-blob';
import Share from 'react-native-share';
import moment from 'moment';
import request from 'src/utils/request';

export const downloadPresetImage = async ({url, cb, onChangeProgress}) => {
  RNFetchBlob.config({})
    .fetch('GET', url)
    .progress({interval: 250}, (received, total) => {
      onChangeProgress(Math.round((received / total) * 100));
    })
    .then((resp) => {
      cb(resp.data);

      onChangeProgress(0);
    })
    .catch((err) => {
      cb();
      onChangeProgress(0);

      console.log('url', url);

      console.log(err);

      Alert.alert('', t('error:text_internet_connection').toUpperCase());
    });
};

export const sharePreset = async ({base64image, id, cb}) => {
  let shareOptions = {
    url: base64image,
  };

  Share.open(shareOptions)
    .then((res) => {})
    .catch((err) => {});

  sendDownload({id});
};

const sendDownload = async ({id}) => {
  console.log('sendDownload', id);

  request.post(`/download/collection/${id}`);
};
