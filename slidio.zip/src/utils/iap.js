import {Alert, Platform} from 'react-native';

import RNIap from 'react-native-iap';

export let subscriptions = [];

// export const items = Platform.select({
//   ios: {
//     Presetium_Annual: 'annual',
//     Presetium_Monthly: 'monthly',
//   },
//   android: {
//     presetium_12_months: 'annual',
//     presetium_liftime_access: 'monthly',
//   },
// });

export const items = Platform.select({
  ios: {
    annual: 'year',
    monthly: 'month',
  },
  android: {
    annual: 'powerpoints_12_months',
    monthly: 'powerpoints_liftime_access',
  },
});

export const itemSkus = Platform.select({
  ios: [],
  android: [],
});

export const itemSubs = Platform.select({
  ios: ['month', 'month_start', 'year', 'year_start'],
  android: ['powerpoints_12_months', 'powerpoints_12_months_start'],
});

export const itemProds = [
  'powerpoints_liftime_access',
  'powerpoints_liftime_access_start',
];

export const getItems = async (): void => {
  try {
    const products = await RNIap.getProducts(itemSkus);
    // const products = await RNIap.getSubscriptions(itemSkus);
    console.log('Products', products);
    // this.setState({productList: products});
  } catch (err) {
    console.warn(err.code, err.message);
  }
};

export const getSubscriptions = async (): void => {
  try {
    console.log('itemSubs', itemSubs);

    subscriptions = await RNIap.getSubscriptions(itemSubs);
    console.log('Subscriptions', subscriptions);

    // this.setState({productList: products});
  } catch (err) {
    console.warn(err.code, err.message);
  }
};

export const getAvailablePurchases = async (): void => {
  try {
    console.info(
      'Get available purchases (non-consumable or unconsumed consumable)',
    );
    const purchases = await RNIap.getAvailablePurchases();
    console.info('Available purchases :: ', purchases);

    // const receiptBody = {
    //   'receipt-data': purchases[0].transactionReceipt,
    //   password: PASSWORD,
    // };
    const result = await validateReceiptIos(purchases[0]);

    // if (result) {

    // }
    console.log();

    // purchases.map((item) => {

    // })
    // if (purchases && purchases.length > 0) {
    //   this.setState({
    //     availableItemsMessage: `Got ${purchases.length} items.`,
    //     receipt: purchases[0].transactionReceipt,
    //   });
    // }
  } catch (err) {
    console.warn(err.code, err.message);
    Alert.alert(err.message);
  }
};

export const getPurchaseHistory = async (): void => {
  try {
    const purchaseHistories = await RNIap.getPurchaseHistory();
    console.log('PurchaseHistory', purchaseHistories);
  } catch (err) {
    console.warn(err.code, err.message);
  }
};

export const requestPurchase = async (sku): void => {
  try {
    RNIap.requestPurchase(sku, false);
  } catch (err) {
    console.warn(err.code, err.message);
  }
};

export const requestSubscription = async (sku): void => {
  console.log(sku);

  try {
    RNIap.requestSubscription(sku, false);
  } catch (err) {
    Alert.alert(err.message);
  }
};
