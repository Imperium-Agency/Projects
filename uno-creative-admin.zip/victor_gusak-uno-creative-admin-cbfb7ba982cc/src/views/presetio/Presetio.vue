<template>
  <TheContent
    title="Presetio"
    :countTotalItems="countTotalItems"
    :countItems="countItems"
    :countSelectedItems="countSelectedItems"
    :activePage.sync="page"
    :pages="countPages"
    :pageSize.sync="pageSize"
  >
    <!-- <pre>{{activeItem}}</pre> -->

    <TableHeader slot="header">
      <CButton slot="btn" color="primary" @click="activeItem = null"
        >Add collection</CButton
      >
    </TableHeader>

    <CDataTable
      hover
      striped
      sorter
      table-filter
      :loading="loading"
      :items="data"
      :fields="fields"
      index-column
    >
      <template #description="data">
        <td>
          <div class="description">
            <span>{{ data.item.description.en }}</span>
          </div>
        </td>
      </template>

      <template #created_at="data">
        <td>
          <span>{{ getCreatedAt(data.item.created_at) }}</span>
        </td>
      </template>

      <template #actions="data">
        <td>
          <Actions
            @edit="activeItem = data.item"
            @delete="() => handlerDelete(data.item)"
          />
        </td>
      </template>
    </CDataTable>

    <template slot="modals">
      <ModalModificated
        :data="activeItem"
        :isShow="activeItem !== false"
        :addictionsData="addictionsData"
        :apiName="apiName"
        @close="activeItem = false"
        @submit="handlerSubmitModal"
      />
    </template>
  </TheContent>
</template>

<script>
import moment from "moment";

import TheContent from "@/containers/TheContent";

import MixinsScreen from "@/mixins/screen";

import Actions from "@/components/root/Actions";

import { axios, showNotification } from "@/utils/axios";

import ModalModificated from "./modals/ModalModificated";

export default {
  name: "Presetio",

  mixins: [MixinsScreen],

  components: {
    TheContent,

    Actions,

    ModalModificated
  },

  data: () => {
    return {
      apiName: "presetio",

      fields: [
        { key: "id", label: "Id" },
        { key: "name", label: "Title" },
        { key: "description_en", label: "Description" },
        { key: "count_download", label: "Count download" },

        { key: "created_at", label: "Created At" },
        { key: "actions", label: "Actions" }
      ]
    };
  },

  methods: {
    getBadge(status) {
      return status ? "success" : "danger";
    },

    getCreatedAt(date) {
      return moment(date)
        .subtract("hours", 3)
        .format("YYYY-MM-DD HH:mm:ss");
    }
  }
};
</script>
