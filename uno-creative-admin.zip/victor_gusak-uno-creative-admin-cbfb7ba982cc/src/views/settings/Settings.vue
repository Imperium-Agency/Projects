<template>
  <div class="settings">
    <label class="settings__item" v-if="data">
      <CSwitch
        :checked="data.maintenance_mode"
        value="#2F1FD3"
        shape="pill"
        color="#2F1FD3"
        @update:checked="handlerChange"
      />
      <span class="settings__text">Engineering Mode</span>
    </label>
  </div>
</template>

<script>
import MixinsScreen from "@/mixins/screen";

import { axios, showNotification } from "@/utils/axios";

export default {
  name: "setting",

  mixins: [MixinsScreen],

  data: () => ({
    apiName: "maintenance",
    prefetch: false
  }),

  created() {
    axios
      .get(`/admin_api/${this.apiName}/`)
      .then(response => {
        console.log(response.data);

        this.data = response.data;
      })
      .catch(error => {
        console.log(error);
      });
  },

  methods: {
    handlerChange(value) {
      let url = `/admin_api/${this.apiName}/`;

      console.log(value);

      axios
        .put(url, {
          maintenance_mode: value
          // maintenance_text: "string"
        })
        .then(response => {
          console.log(response.data);

          if (response.status === 200) {
            showNotification({
              type: "success",
              text: "Success. Save setting"
            });
          } else {
            showNotification({
              type: "danger",
              text: "Error! Save setting"
            });
          }
        })
        .catch(error => {
          console.log(error);
          console.log(error.response.data);
          showNotification({
            type: "danger",
            text: "Error! Save setting"
          });
        });
    }
  }
};
</script>

<style lang="scss" scoped>
.settings {
  padding: 1rem;

  &__item {
    display: flex;
    align-items: center;
  }

  &__text {
    margin-left: 1rem;
  }
}
</style>