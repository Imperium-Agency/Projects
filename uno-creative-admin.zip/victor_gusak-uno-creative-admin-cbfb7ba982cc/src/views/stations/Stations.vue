<template>
  <TheContent
    title="All operators"
    :countTotalItems="countTotalItems"
    :countItems="countItems"
    :countSelectedItems="countSelectedItems"
    :activePage.sync="page"
    :pages="countPages"
    :pageSize.sync="pageSize"
    :filters="filters"
    @filfer="handlerFilter"
  >
    <TableHeader
      slot="header"
      :isSelect="!!selected.length"
      :isSelectedAll="isSelectedAll"
      @choseAll="handlerChoseAll"
    >
      <CButton slot="btn" color="primary" @click="activeItem = null">Add operators</CButton>

      <template slot="action">
        <CDropdownItem @click.prevent="halderAction('changeStatus')">Change status</CDropdownItem>
      </template>
    </TableHeader>

    <CDataTable hover striped sorter :loading="loading" :items="data" :fields="fields" index-column>
      <template #check="data">
        <td>
          <CInputCheckbox
            :checked="checkValue(data.item.id)"
            @update:checked="(id) => handlerChose(data.item.id)"
          />
        </td>
      </template>

      <template #country="data">
        <td>
          <Country :flag="data.item.country.flag" :name="data.item.country.name"/>
        </td>
      </template>

      <template #actions="data">
        <td>
          <Actions @edit="activeItem = data.item" @delete="() => handlerDeleteUser(data.item)"/>
        </td>
      </template>
    </CDataTable>

    <template slot="modals">
      <MaintenanceModalsModificated
        :data="activeItem"
        :isShow="activeItem !== false"
        :addictionsData="addictionsData"
        :apiName="apiName"
        @close="activeItem = false"
        @submit="handlerSubmitModal"
      />
    </template>
  </TheContent>
</template>

<script>
import TheContent from "@/containers/TheContent";

import Actions from "@/components/root/Actions";
import Country from "@/components/root/Country";

import MaintenanceModalsModificated from "./modals/MaintenanceModalsModificated";

import MixinsScreen from "@/mixins/screen";

export default {
  name: "stations",

  mixins: [MixinsScreen],

  components: {
    TheContent,

    MaintenanceModalsModificated,

    Actions,
    Country
  },

  data: () => ({
    apiName: "maintenance",

    addictions: ["countries"],

    fields: [
      { key: "check", label: "", sorter: false },
      { key: "name", label: "Operator Name", _style: "min-width: 140px" },
      { key: "country", label: "Country" },
      { key: "actions", label: "Actions" }
    ],

    filters: {
      dataDefault: {
        id: null,
        country: []
      },

      items: {
        id: {
          type: "select",
          label: "Select id"
        },
        country: {
          type: "complete",
          label: "Select countries",
          apiName: "countries",
          size: "3"
        }
      }
    }
  })
};
</script>

<style lang="scss">
.operators {
  .table td {
    vertical-align: middle;
  }
}
</style>

<style lang="scss" scoped>
.operators {
  .actions {
    &__containter {
      width: 100%;

      display: flex;
    }

    &__button {
      flex: 1;

      &:first-child {
        margin-right: 1rem;
      }
    }
  }

  &__country {
    display: flex;
    align-items: center;
  }

  &__icon {
    margin: 0;
    margin-right: 0.8rem;
  }
}
</style>