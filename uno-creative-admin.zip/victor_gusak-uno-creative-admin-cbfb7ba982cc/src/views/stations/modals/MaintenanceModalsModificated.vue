<template>
  <Modal
    :show="isShow"
    :title="title"
    :errors="errors"
    @cansel="$emit('close')"
    @ok="handlerSubmit"
  >
    <div class="countries-modals-modificated" ref="formContainer">
      <CRow>
        <CCol sm="12">
          <CInput v-model="form.name" label="Country name" placeholder="Country name"/>
        </CCol>
      </CRow>

      <CRow>
        <CCol sm="12">
          <CInput v-model="form.code" label="Country code" placeholder="Country code"/>
        </CCol>
      </CRow>

      <CRow>
        <CCol sm="12">
          <div class="countries-modals-modificated__flag-select">
            <AppSlect v-model="form.flag" :options="flagsOptions" label="Country flag"/>

            <i
              :class="`countries-modals-modificated__flag flag-icon flag-icon-${form.flag} h5 flag__icon`"
              v-if="form.flag"
              title
              id
            ></i>
          </div>

          <!-- <CSelect v-model="form.flag" label="Country flag" :options="[{ value: 1, text: 'gg' }, { value: 2, text: 'gg1' }]"/> -->
        </CCol>
      </CRow>

      <CRow>
        <CCol sm="12">
          <CInput
            v-model="form.amount_limit"
            label="Country amount limit"
            placeholder="Country amount limit"
          />
        </CCol>
      </CRow>

      <CRow>
        <CCol sm="12">
          <AppSlect v-model="form.enabled" :options="enabledOptions" label="Status"/>
          <!-- <CSelect v-model="form.enabled" label="Status" :options="['Active', 'Inactive']"/> -->
        </CCol>
      </CRow>
    </div>
  </Modal>
</template>

<script>
import MixinsScreenModal from "@/mixins/screenModal";

import flags from "./flags";

export default {
  name: "NumberModalsModificated",

  mixins: [MixinsScreenModal],

  data: () => ({
    form: {
      name: null,
      code: null,
      flag: null,
      amount_limit: null,
      enabled: null
    },

    flagsOptions: flags,

    enabledOptions: [
      { value: true, label: "Active" },
      { value: false, label: "Inactive" }
    ]
  }),

  computed: {
    title() {
      if (this.isShow) {
        return this.data ? "Edit country" : "Add country";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.countries-modals-modificated {
  &__flag-select {
    display: flex;
    align-items: flex-end;
  }

  &__flag {
    margin-left: 15px;
    margin-bottom: 1rem;

    font-size: 1.85rem;
  }
}
</style>
