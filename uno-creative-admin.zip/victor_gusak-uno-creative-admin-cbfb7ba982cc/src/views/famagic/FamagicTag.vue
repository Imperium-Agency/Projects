<template>
  <TheContent
    title="Famagic Tag"
    :countTotalItems="countTotalItems"
    :countItems="countItems"
    :countSelectedItems="countSelectedItems"
    :activePage.sync="page"
    :pages="countPages"
    :pageSize.sync="pageSize"
  >
    <!-- <pre>{{data}}</pre> -->

    <TableHeader slot="header">
      <CButton slot="btn" color="primary" @click="activeItem = null"
        >Add tag</CButton
      >
    </TableHeader>

    <CDataTable
      hover
      striped
      sorter
      table-filter
      :loading="loading"
      :items="data"
      :fields="fields"
      index-column
    >
      <template #show="data">
        <td>
          <span>{{ data.item.show ? "Yes" : "No" }}</span>
        </td>
      </template>

      <template #created_at="data">
        <td>
          <span>{{ getCreatedAt(data.item.created_at) }}</span>
        </td>
      </template>

      <template #actions="data">
        <td>
          <Actions
            @edit="activeItem = data.item"
            @delete="() => handlerDelete(data.item)"
          />
        </td>
      </template>
    </CDataTable>

    <template slot="modals">
      <ModalModificated
        :data="activeItem"
        :isShow="activeItem !== false"
        :addictionsData="addictionsData"
        :apiName="apiName"
        :apiKey="apiKey"
        @close="activeItem = false"
        @submit="handlerSubmitModal"
      />
    </template>
  </TheContent>
</template>

<script>
import moment from "moment";

import TheContent from "@/containers/TheContent";

import MixinsScreen from "@/mixins/screen";

import Actions from "@/components/root/Actions";

import { axios, showNotification } from "@/utils/axios";

import ModalModificated from "./modals/tag/ModalModificated";

export default {
  name: "Filteroom",

  mixins: [MixinsScreen],

  components: {
    TheContent,

    Actions,

    ModalModificated
  },

  data: () => {
    return {
      apiName: "famagic",
      apiKey: "tag",

      fields: [
        { key: "id", label: "Id" },
        { key: "name", label: "Name" },
        { key: "created_at", label: "Created At" },
        { key: "actions", label: "Actions" }
      ]
    };
  },

  methods: {
    getBadge(status) {
      return status ? "success" : "danger";
    },

    getCreatedAt(date) {
      return moment(date)
        .subtract("hours", 3)
        .format("YYYY-MM-DD HH:mm:ss");
    }
  }
};
</script>
