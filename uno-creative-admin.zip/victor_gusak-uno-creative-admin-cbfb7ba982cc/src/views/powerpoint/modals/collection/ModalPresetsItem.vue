<template>
  <div class="modal-presets">
    <!-- <pre>{{form}}</pre> -->

    <i class="el-icon-close modal-presets__icon" @click="$emit('delete', index)"></i>

    <div style="display: flex">
      <div class="modal-presets__item" v-for="(value, key, index) of form" :key="index">
        <FileLoader
          v-if="renderItems.indexOf(key) != -1 && isShow"
          :value="form[key] && form[key].file"
          :name="key"
          :image="value && value.url ? value.url : value"
          :index="index"
          :isShow="isShow"
          @input="value => handleChangeFile(value, key)"
        />
      </div>
    </div>

    <CRow>
      <CCol sm="4">
        <CInput
          :value="form.order"
          @input="(value) => handleChangeOrder(value)"
          placeholder="Order"
        />
      </CCol>
    </CRow>

    <!-- <CInputCheckbox
      class="modal-presets__checkbox"
      label="Free"
      :checked="form.free"
      @update:checked="value => handleChangeFree(value)"
    />-->

    <ModalImageEnlargement
      v-if="showModalImageEnlargement"
      :image="selectedImage"
      @close="showModalImageEnlargement = false"
    />
  </div>
</template>

<script>
import FileLoader from "@/components/root/FileLoader";

import axios from "axios";

import ModalImageEnlargement from "@/components/modals/ModalImageEnlargement";

export default {
  name: "modal-presets",

  props: {
    data: {
      type: [Array, Object],
      default: () => []
    },

    index: {
      type: [String, Number],
      default: 0
    },

    isShow: {
      type: Boolean,
      default: true
    }
  },

  components: {
    FileLoader,

    ModalImageEnlargement
  },

  data: () => ({
    showModalImageEnlargement: false,
    selectedImage: null,

    renderItems: ["image"],

    form: {
      image: null,
      order: 0
      // preset: null,
      // free: false
    },

    imageResize: null,
    showModalResize: false

    // formChange: {
    //   file1: null,
    //   file2: null,
    //   file3: null,
    //   file4: null,
    //   file5: null
    // },
  }),

  watch: {
    // isShow(value) {
    //   if (!value) {
    //     this.form = {
    //       reference: null,
    //       image: null,
    //       preset: null
    //     };
    //   }
    // },

    data(value) {
      console.log("chanfeData", value);

      this.form = value;
    }
  },

  created() {
    this.form = this.data;
  },

  methods: {
    handleChangeFile(file, key) {
      console.log("handleChangeFile");

      if (!key) key = this.activeImage.key;

      this.form[key] = {
        type: "upload",
        file,
        url: URL.createObjectURL(file)
      };

      // this.form[key].image = URL.createObjectURL(file);

      this.$emit("change", this.form);
    },

    handleChangeFree(value) {
      this.form.free = value;

      this.$emit("change", this.form);
    },

    handleChangeOrder(value) {
      this.form.order = value;

      this.$emit("change", this.form);
    },

    handlerLoadFile() {
      var file = this.$refs.file.files[0];

      if (file) {
        console.log(file);

        this.handleChangeFile(file);

        // this.link = URL.createObjectURL(file);
        // this.$emit("input", file);
      }
    },

    handleUpdate({ id, index }) {
      this.activeImage = {
        key: `file${index + 1}`
      };

      this.$refs.file.click();
    },

    handleShowImage(image) {
      this.showModalImageEnlargement = true;
      this.selectedImage = image;
    }
  }
};
</script>

<style lang="scss" scoped>
.modal-presets {
  margin-top: 1rem;
  padding: 10px;

  display: flex;
  flex-direction: column;
  flex-wrap: wrap;

  position: relative;

  border: 1px solid #768192;

  &__icon {
    position: absolute;
    right: 10px;
    margin-top: 5px;

    cursor: pointer;
    transition: all 0.3s;

    &:hover {
      opacity: 0.7;
      transition: all 0.3s;
    }
  }

  &__checkbox {
    width: 100%;
  }
}
</style>
