import Router from "vue-router";
import Vue from "vue";

// Containers
const TheContainer = () => import("@/containers/TheContainer");

// Presetio
const Presetio = () => import("@/views/presetio/Presetio");

// Filteroom
const Filteroom = () => import("@/views/filteroom/Filteroom");

// Presetium
const Presetium = () => import("@/views/presetium/Presetium");

// Filteresco
const Filteresco = () => import("@/views/filteresco/Filteresco");

// Powerpoint
const PowerpointTag = () => import("@/views/powerpoint/PowerpointTag");
const PowerpointCollection = () =>
  import("@/views/powerpoint/PowerpointCollection");

// Instapano
const InstapanoTag = () => import("@/views/instapano/InstapanoTag");
const InstapanoCollection = () =>
  import("@/views/instapano/InstapanoCollection");

// Views - Pages
const Page404 = () => import("@/views/pages/Page404");
const Page500 = () => import("@/views/pages/Page500");
const Login = () => import("@/views/pages/Login");

Vue.use(Router);

export default new Router({
  mode: "hash", // https://router.vuejs.org/api/#mode
  linkActiveClass: "open active",
  scrollBehavior: () => ({ y: 0 }),
  routes: [
    {
      path: "/",
      redirect: "/presetio",
      name: "Home",
      component: TheContainer,
      children: [
        {
          path: "presetio",
          meta: { label: "Presetio" },
          component: Presetio
        },

        {
          path: "filteroom",
          meta: { label: "Filteroom" },
          component: Filteroom
        },

        {
          path: "presetium",
          meta: { label: "Presetium" },
          component: Presetium
        },

        {
          path: "filteresco",
          meta: { label: "Filteresco" },
          component: Filteresco
        },

        {
          path: "powerpoint/tag",
          meta: { label: "Powerpoint Tag" },
          component: PowerpointTag
        },
        {
          path: "powerpoint/collection",
          meta: { label: "Powerpoint Collection" },
          component: PowerpointCollection
        },

        {
          path: "instapano/tag",
          meta: { label: "Instapano Tag" },
          component: InstapanoTag
        },
        {
          path: "instapano/collection",
          meta: { label: "Instapano Collection" },
          component: InstapanoCollection
        }
      ]
    },
    {
      path: "/pages",
      redirect: "/pages/404",
      name: "Pages",
      component: {
        render(c) {
          return c("router-view");
        }
      },
      children: [
        {
          path: "404",
          name: "Page404",
          component: Page404
        },
        {
          path: "500",
          name: "Page500",
          component: Page500
        },
        {
          path: "login",
          name: "Login",
          component: Login
        }
        // {
        //   path: "register",
        //   name: "Register",
        //   component: Register
        // }
      ]
    }
  ]
});
