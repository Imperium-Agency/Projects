export const domen = "https://api.unocreative.studio/api/admin/";
// export const domen = "http://127.0.0.1:8000/api/admin/";
