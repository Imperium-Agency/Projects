const getFiltersUrl = filters => {
  let url = "";

  for (let key in this.filterData) {
    let items = this.filterData[key];

    if (items) {
      if (typeof items == "string") {
        if (key == "created_at") {
          url += `created_at_before=${items}&created_at_after=${items}&`;
        } else if (items) url += `${key}=${items}&`;
      } else if (items.length > 0) {
        let commaSeparated = this.commaSeparated[this.apiName];

        if (commaSeparated && commaSeparated.indexOf(key) != -1) {
          console.log(key);
          let param = `${key}=`;

          for (let item of items) {
            param += `${item},`;
          }

          url += param + "&";
        } else
          for (let item of items) {
            url += `${key}=${item}&`;
          }
      }
    }
  }

  return url;
};

export default getFiltersUrl;
