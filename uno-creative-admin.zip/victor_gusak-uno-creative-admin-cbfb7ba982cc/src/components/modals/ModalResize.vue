<template>
  <Modal style="z-index: 100;" :closing="false" @close="$emit('close')">
    <div class="app-modal-resize" :style="{'margin-top': !firstLoad ? '1rem' : '0'}">
      <div class="content">
        <section class="cropper-area">
          <div class="img-cropper">
            <vue-cropper ref="cropper" :src="image"/>
          </div>
          <div class="actions">
            <a href="#" role="button" @click.prevent="zoom(0.2)">Zoom In</a>
            <a href="#" role="button" @click.prevent="zoom(-0.2)">Zoom Out</a>
            <a href="#" role="button" @click.prevent="rotate(90)">Rotate +90deg</a>
            <a href="#" role="button" @click.prevent="rotate(-90)">Rotate -90deg</a>
            <a ref="flipX" href="#" role="button" @click.prevent="flipX">Flip X</a>
            <a ref="flipY" href="#" role="button" @click.prevent="flipY">Flip Y</a>
            <!-- <a href="#" role="button" @click.prevent="reset">Reset</a> -->
          </div>

          <div class="app-modal-resize__footer">
            <Button class="app-modal-resize__button" text="Save" @click="cropImage"/>

            <Button class="app-modal-resize__button" text="Reset" @click="reset"/>
          </div>
        </section>
      </div>
    </div>
  </Modal>
</template>

<script>
import Modal from "./Modal";
import Button from "@/components/root/Button";
import VueCropper from "vue-cropperjs";

import "cropperjs/dist/cropper.css";

import { mapGetters, mapActions, mapMutations } from "vuex";
import * as types from "@/store/mutation-types";

export default {
  components: {
    VueCropper,
    Modal,
    Button
  },

  props: {
    image: {
      type: String
    },
    name: {
      type: String
    }
  },

  data() {
    return {
      // imgSrc: "https://pixlr.com/images/best-photo-editor-cover.jpg",
      cropImg: "",
      data: null
    };
  },

  computed: {
    ...mapGetters({
      // image: "photo/link",
      // name: "photo/name",
      firstLoad: "photo/firstLoad"
    })
  },

  methods: {
    ...mapActions({
      // close: "photo/close",
      save: "photo/save"
    }),

    cropImage() {
      // get image data for post processing, e.g. upload or setting image src
      this.cropImg = this.$refs.cropper
        .getCroppedCanvas({
          width: 640,
          height: 360
        })
        .toDataURL();

      var block = this.cropImg.split(";");
      // Get the content type of the image
      var contentType = block[0].split(":")[1]; // In this case "image/gif"
      // get the real base64 content of the file
      var realData = block[1].split(",")[1]; // In this case "R0lGODlhPQBEAPeoAJosM...."

      // Convert it to a blob to upload
      // var blob = this.b64toBlob(realData, contentType);

      this.urltoFile(
        this.cropImg,
        this.name.split(".")[0] + ".jpeg",
        "image/jpeg"
      ).then(file => {
        console.log(file);
        console.log(URL.createObjectURL(file));

        // this.save({ file });
        console.log("changeFile");

        this.$emit("changeFile", file);
        this.$emit("close");
      });

      // console.log(blob);
    },

    urltoFile(url, filename, mimeType) {
      mimeType = mimeType || (url.match(/^data:([^;]+);/) || "")[1];
      return fetch(url)
        .then(function(res) {
          return res.arrayBuffer();
        })
        .then(function(buf) {
          return new File([buf], filename, { type: mimeType });
        });
    },

    flipX() {
      const dom = this.$refs.flipX;
      let scale = dom.getAttribute("data-scale");
      scale = scale ? -scale : -1;
      this.$refs.cropper.scaleX(scale);
      dom.setAttribute("data-scale", scale);
    },
    flipY() {
      const dom = this.$refs.flipY;
      let scale = dom.getAttribute("data-scale");
      scale = scale ? -scale : -1;
      this.$refs.cropper.scaleY(scale);
      dom.setAttribute("data-scale", scale);
    },

    move(offsetX, offsetY) {
      this.$refs.cropper.move(offsetX, offsetY);
    },
    reset() {
      this.$refs.cropper.reset();
      // this.$emit("close");
    },
    rotate(deg) {
      this.$refs.cropper.rotate(deg);
    },

    showFileChooser() {
      this.$refs.input.click();
    },
    zoom(percent) {
      this.$refs.cropper.relativeZoom(percent);
    }
  }
};
</script>

<style lang="scss" scoped>
.app-modal-resize {
  // margin-top: 1rem;
  // position: absolute;

  // background-color: #fff;

  &__footer {
    margin-top: 2rem;
    display: flex;
    justify-content: center;

    z-index: 10;
  }

  &__button {
    margin: 0 1rem;
    // flex: 1;
    min-width: 30%;
  }

  .content {
    display: flex;
    justify-content: space-between;
  }

  .actions {
    margin-top: 1.5rem;
  }
  .actions a {
    display: inline-block;
    padding: 5px 15px;
    background: rgba(236, 0, 140, 0.6);
    color: white;
    text-decoration: none;
    border-radius: 3px;
    margin-right: 1rem;
    margin-bottom: 1rem;
  }
}
</style>