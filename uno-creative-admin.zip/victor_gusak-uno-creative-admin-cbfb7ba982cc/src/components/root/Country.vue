<template>
  <p class="country">
    <i :class="`flag-icon flag-icon-${flag} h5 country__icon`" title id></i>
    {{name}}
  </p>
</template>

<script>
export default {
  name: "Country",

  props: {
    flag: {
      type: String,
      default: null
    },

    name: {
      type: String,
      default: null
    }
  }
};
</script>


<style lang="scss" scoped>
.country {
  display: flex;
  align-items: center;

  &__icon {
    margin: 0;
    margin-right: 0.8rem;
  }
}
</style>