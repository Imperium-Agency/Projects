<template>
  <div class="multiselect-wraper">
    <p v-if="label" class="multiselect-wraper__label">{{ label }}</p>

    <multiselect
      v-model="localValue"
      :options="options"
      :multiple="true"
      :placeholder="placeholder"
      :show-labels="false"
    ></multiselect>
  </div>
</template>

<script>
import multiselect from "vue-multiselect";

import MixinVModel from "@/mixins/MixinVModel";

export default {
  name: "Multiselect",

  mixins: [MixinVModel],

  components: {
    multiselect
  },

  props: {
    options: {
      type: Array,
      default: () => []
    },

    label: {
      type: String,
      default: null
    },

    placeholder: {
      type: String,
      default: null
    }
  }
};
</script>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<style lang="scss">
.multiselect-wraper {
  .multiselect {
    font-size: 0.875rem;

    &__tags {
      // min-height: 35px;
      min-height: calc(1.5em + 0.75rem + 2px);
      // height: 35px;

      padding: 5.5px 40px 0 8px;

      // display: flex;
      // align-items: center;

      border-color: #d8dbe0;

      // overflow: hidden;
    }

    &__placeholder {
      margin-bottom: 0;
      padding-top: 0;

      font-size: 0.875rem;
      color: #768192;
    }

    &__select {
      height: 35px;
    }

    &__input {
      height: 35px;

      margin: 0;

      font-size: 0.875rem;

      overflow: hidden;
    }

    &__option * {
      font-size: 0.875rem;
    }

    &__single {
      margin-bottom: 0;

      color: #788191;
      font-size: 0.875rem;
    }

    &__tags {
      // height: 35px;

      // overflow: hidden;
    }

    &__tags-wrap {
      // display: flex;

      // overflow: hidden;
    }

    &__tag {
      margin-bottom: 0;
    }
  }

  &__label {
    display: inline-block;
    margin-bottom: 0.5rem;
  }
}
</style>
