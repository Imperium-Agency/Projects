<template>
  <div class="tabel">
    <div class="tabel__item">
      <p
        class="tabel__text"
        v-for="(item, index) in data.headers"
        :key="index"
        :style="styleText(index, data.headers.length)"
      >{{item}}</p>
    </div>

    <div class="tabel__line"></div>

    <div class="tabel__item" v-for="(items, itemsIndex) in data.items" :key="itemsIndex">
      <p
        class="tabel__text"
        v-for="(item, index) in items"
        :key="index"
        :style="styleText(index, items.length)"
      >{{item}}</p>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    data: {
      type: Object,
      default: false
    }
  },

  data: () => ({}),

  methods: {
    styleText(index, length) {
      let isEnd = length - 1 == index;

      if (index > 0) {
        if (isEnd) return { textAlign: isEnd ? "right" : "center" };
        else
          return {
            textAlign: isEnd ? "right" : "right",
            marginRight: "2.2rem"
          };
      }
    }
  }
};
</script>

<style lang="scss" scoped >
.tabel {
  &__item {
    padding: 0.4rem 0;

    display: flex;
    justify-content: space-between;

    &:not(:last-child) {
      border: 1px solid #313138;
    }

    &:first-child {
      border: none;
    }
  }

  &__line {
    margin-bottom: 0.1rem;

    height: 1px;
    background-image: linear-gradient(90deg, #a300df 0%, #eb008b 100%);
  }

  &__text {
    font-size: 0.87rem;
    color: #ffffff;

    flex: 1;
  }
}
</style>
