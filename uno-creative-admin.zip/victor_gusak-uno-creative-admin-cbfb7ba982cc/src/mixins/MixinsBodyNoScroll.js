export const MIXINS_BODY_NO_SCROLL = {
  data: () => ({
    _scrollTop: 0
  }),

  methods: {
    hideScroll() {
      this._scrollTop = window.pageYOffset; // запоминаем текущую прокрутку сверху

      document.body.style.position = "fixed";
      // document.body.style.position = "fixed";

      if (document.body.offsetHeight > document.documentElement.clientHeight)
        document.body.style.overflowY = "scroll";

      document.body.style.top = -this._scrollTop + "px";
    },

    showScroll() {
      document.body.style.position = "";
      document.body.style.overflowY = "";
      document.body.style.right = "";
      document.body.style.width = "";
      document.body.style.height = "";
      document.body.style.top = "";

      window.scroll(0, this._scrollTop);
    }
  }
};
