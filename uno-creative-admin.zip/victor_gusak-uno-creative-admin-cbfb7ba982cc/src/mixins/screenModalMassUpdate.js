import Modal from "@/components/root/Modal";

import { axios, showNotification } from "../utils/axios";

import getFiltersUrl from "@/utils/filters";

export default {
  components: {
    Modal
  },

  props: {
    selectedItems: {
      type: Array,
      default: () => []
    },

    isShow: {
      type: Boolean,
      default: false
    },

    apiName: {
      type: String
    },

    filtersStr: {
      type: String,
      default: ""
    }
  },

  data: () => ({
    errors: null
  }),

  computed: {
    submitData() {
      if (!this.isAllUpdate) {
        return this.selectedItems.map(item => ({
          id: item,
          ...this.form
        }));
      } else {
        return this.form;
      }
    },

    isAllUpdate() {
      return !this.selectedItems.length;
    }
  },

  watch: {
    isShow(next) {
      if (next) {
        this.error = null;
      }
    }
  },

  methods: {
    handlerSubmit() {
      // console.log(getFiltersUrl(this.filters));

      let url = `/admin_api/${this.apiName}/mass_update/?${this.filtersStr}`;

      let loader = this.$loading.show({
        container: this.$refs.formContainer,
        canCancel: false
      });

      axios[this.isAllUpdate ? "put" : "patch"](url, this.form)
        .then(response => {
          showNotification({
            type: "success",
            text: "Success. Mass update"
          });

          loader.hide();

          this.$emit("close");
          this.$emit("submit");
        })
        .catch(error => {
          this.errors = error.response.data;
          console.log(error.response.data);

          showNotification({
            type: "danger",
            text: "Error! Mass update"
          });

          loader.hide();
        });
    }
  }
};
